/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;

/**
 * The {@ code CipherProviderTest} class is a unit test for {@link CipherProvider}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@DisplayName("Cipher Provider Test Case")
@Tags({@Tag("cipher"), @Tag("provider")})
class CipherProviderTest {

    @Test
    @Tags({@Tag("cipher"), @Tag("provider")})
    @DisplayName("Cipher Provider Test")
    void testKnown() {
        testCipher("blowfish", "super secret key");
        testCipher("loopback");
    }

    @Test
    @Tags({@Tag("cipher"), @Tag("provider"), @Tag("null")})
    @DisplayName("Cipher Provider Test Null Algorithm")
    void testNull() {
        final NullPointerException ex = assertThrows(NullPointerException.class, () ->
            CipherProvider.of(null));

        assertEquals("A non-null algorithm name is required", ex.getMessage());
    }

    @Test
    @Tags({@Tag("cipher"), @Tag("provider"), @Tag("unsupported")})
    @DisplayName("Cipher Provider Test Unsupported Algorithm")
    void testUnsupported() {
        final UnsupportedCipherAlgorithmException ex = assertThrows(UnsupportedCipherAlgorithmException.class, () ->
            CipherProvider.of("unsupported"));

        assertEquals("unsupported", ex.getAlgorithm());
        assertEquals("The given algorithm 'unsupported' is not supported by known cipher providers", ex.getMessage());
    }

    private void testCipher(final String algorithm, final Object... arguments) {
        final CipherProvider provider = assertDoesNotThrow(() -> CipherProvider.of(algorithm));

        assertNotNull(provider);
        assertNotNull(assertDoesNotThrow(() -> provider.newCipher(arguments)));
    }

}