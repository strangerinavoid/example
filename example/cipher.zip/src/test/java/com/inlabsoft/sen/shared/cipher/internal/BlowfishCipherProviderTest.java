/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher.internal;

import static java.util.Base64.getEncoder;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.security.NoSuchAlgorithmException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.junit.jupiter.api.Test;

import com.inlabsoft.sen.shared.cipher.Cipher;
import com.inlabsoft.sen.shared.cipher.CipherProvider;

/**
 * The {@code BlowfishCipherProviderTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BlowfishCipherProviderTest {

    private static final class CipherKeyUtils {

        private static final String ALGORITHM = "Blowfish";
        private static final int DEFAULT_KEY_SIZE = 128;

        public static byte[] generateKey(final int keySize) throws NoSuchAlgorithmException {
            final KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);

            keyGenerator.init(keySize);

            final SecretKey key = keyGenerator.generateKey();

            return getEncoder().encode(key.getEncoded());
        }

    }

    @Test
    void testCipher() throws NoSuchAlgorithmException {
        final byte[] key = CipherKeyUtils.generateKey(CipherKeyUtils.DEFAULT_KEY_SIZE);
        final CipherProvider provider = assertDoesNotThrow(() -> CipherProvider.of(CipherKeyUtils.ALGORITHM));

        assertNotNull(provider);

        final Cipher cipher = assertDoesNotThrow(() -> provider.newCipher(key));

        assertNotNull(cipher);

        final String password = "secret";
        final byte[] data = assertDoesNotThrow(() -> cipher.encrypt(password.getBytes()));

        assertNotNull(data);
        assertTrue(data.length > password.length());

        final byte[] pass = assertDoesNotThrow(() -> cipher.unencrypt(data));

        assertNotNull(pass);
        assertEquals(password, new String(pass));
    }

}