/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */

import com.inlabsoft.sen.shared.cipher.CipherProvider;
import com.inlabsoft.sen.shared.cipher.internal.BlowfishCipherProvider;
import com.inlabsoft.sen.shared.cipher.internal.LoopbackCipherProvider;

module sen.shared.cipher {

    exports com.inlabsoft.sen.shared.cipher;

    requires transitive sen.shared.core;
    requires transitive sen.shared.logging;

    provides CipherProvider
        with BlowfishCipherProvider, LoopbackCipherProvider;

        uses CipherProvider;

}