/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher;

/**
 * The {@code Cipher} is interface defines the functionality of a cryptographic cipher for encryption and decryption.
 * <p>
 * In order to create a Cipher object, the application asks for the appropriate Cipher's provider via
 * {@code CipherProvider#of(String)} with the name of the required of a cryptographic algorithm (e.g., <i>AES</i> or
 * <i>Blowfish</i>) and then calls the Cipher's provider {@code CipherProvider#newCipher(Object...)} method, and passes
 * required arguments (optional).
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface Cipher {

    /**
     * Performs encryption operation (depending on how this cipher was initialized).
     * <p>
     * The bytes in the {@code data} buffer are processed, and the result is returned as array of bytes.
     * <p>
     * If {@code data} has a length of zero, this method returns {@code null}.
     *
     * @param   data the data to encrypt.
     * @return  the new buffer with the result of encryption, or {@code null} if the underlying cipher is a block
     *          cipher and the input data is too short to result in a new block.
     * @throws  IllegalStateException if this cipher is in a wrong state (e.g., has not been initialized)
     *
     * @see     #unencrypt(byte[])
     */
    byte[] encrypt(byte[] data);

    /**
     * Performs decryption operation (depending on how this cipher was initialized).
     * <p>
     * The bytes in the {@code data} buffer are processed, and the result is returned as array of bytes.
     * <p>
     * If {@code data} has a length of zero, this method returns {@code null}.
     *
     * @param   data the data to decrypt.
     * @return  the new buffer with the result of decryption, or {@code null} if the underlying cipher is a block
     *          cipher and the input data is too short to result in a new block.
     * @throws  IllegalStateException if this cipher is in a wrong state (e.g., has not been initialized)
     *
     * @see     #encrypt(byte[])
     */
    byte[] unencrypt(byte[] data);

}