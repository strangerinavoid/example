/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher;

import java.util.Formatter;
import java.util.Objects;

import com.inlabsoft.sen.shared.error.ComponentException;

/**
 * The {@code CipherException} indicates a common exception inside cipher logic.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public class CipherException extends ComponentException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = 3598616266987739101L;

    /**
     * Creates an instance of class {@code CipherException}.
     *
     * @param  message the detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
    public CipherException(final String message) {
        super(message);
    }

    /**
     * Creates an instance of class {@code CipherException} with the specified detail message. The cause is not
     * initialized, and may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   message the detail message. The detail message is saved for later retrieval by the {@link #getMessage()}
     *          method.
     * @param   arguments an arguments referenced by the format specifiers in the message string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The number of arguments is variable
     *          and may be zero. The maximum number of arguments is limited by the maximum dimension of a Java array as
     *          defined by <cite>The Java&trade; Virtual Machine Specification</cite>. The behavior on a {@code null}
     *          argument depends on the {@link Formatter} conversion.
     */
    public CipherException(final String message, final Object... arguments) {
        super(message, arguments);
    }

    /**
     * Creates an instance of class {@code CipherException}.
     *
     * @param   message the detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     * @param   cause the cause (which is saved for later retrieval by the {@link #getCause()} method). (A {@code null}
     *          value is permitted, and indicates that the cause is nonexistent or unknown.)
     * @param   arguments an arguments referenced by the format specifiers in the message string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The number of arguments is variable
     *          and may be zero. The maximum number of arguments is limited by the maximum dimension of a Java array as
     *          defined by <cite>The Java&trade; Virtual Machine Specification</cite>. The behavior on a {@code null}
     *          argument depends on the {@link Formatter} conversion.
     */
    public CipherException(final String message, final Throwable cause, final Object... arguments) {
        super(message, cause, arguments);
    }

    /**
     * Constructs a new {@link CipherException} with the specified cause and a detail message of {@code (cause ==
     * null ? null : cause.toString())} (which typically contains the class and detail message of
     * {@code cause}). This constructor is useful for exceptions that are little more than wrappers for other
     * throwables.
     *
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the {@link #getCause()}
     *          method. A {@code null} value is permitted, and indicates that the cause is nonexistent or unknown.
     */
    public CipherException(final Throwable cause) {
        super(Objects.requireNonNull(cause, "Cannot create CipherException with null cause").getMessage(), cause);
    }

}