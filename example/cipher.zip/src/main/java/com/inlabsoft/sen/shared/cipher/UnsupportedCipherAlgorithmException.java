/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher;

import static java.util.Objects.requireNonNull;

/**
 * The {@code UnsupportedCipherAlgorithmException} indicates that a given algorithm is not supported by known
 * {@link CipherProvider providers}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public class UnsupportedCipherAlgorithmException extends CipherException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -6636852728570112155L;

    /**
     * An instance of unsupported algorithm.
     */
    private final String algorithm;

    /**
     * Constructs a new {@code UnsupportedCipherAlgorithmException} with the specified message.
     *
     * @param   message the message to use for this exception, may be {@code null}.
     */
    public UnsupportedCipherAlgorithmException(final String message, final String algorithm) {
        this(message, algorithm, null);
    }

    /**
     * Constructs a new {@code UnsupportedCipherAlgorithmException} with the specified message and cause.
     *
     * @param   message the message to use for this exception, may be {@code null}.
     * @param   cause the cause of the exception, may be {@code null}.
     */
    public UnsupportedCipherAlgorithmException(final String message, final String algorithm, final Throwable cause) {
        super(message, cause, algorithm);

        this.algorithm = requireNonNull(algorithm, "A non-null algorithm name is required");
    }

    /**
     * Returns an instance of unsupported algorithm.
     */
    public String getAlgorithm() {
        return this.algorithm;
    }

}