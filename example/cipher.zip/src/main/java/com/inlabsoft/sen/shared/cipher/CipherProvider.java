/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher;

import java.util.ServiceLoader;

/**
 * The {@code CipherProvider} interface defines a factory class that used to create instances of {@link Cipher}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface CipherProvider {

    /**
     * Lookups for an instance of the cipher provider with given algorithm name.
     *
     * @param   algorithm the name of the cipher algorithm.
     * @return  an instance of the cipher provider.
     */
    static CipherProvider of(final String algorithm) {
        final ServiceLoader<CipherProvider> loader = ServiceLoader.load(CipherProvider.class);

        // looking for the first available cipher provider
        for (final CipherProvider provider : loader) {
            if (provider.isSupported(algorithm)) {
                return provider;
            }
        }

        throw new UnsupportedCipherAlgorithmException(
            "The given algorithm '%s' is not supported by known cipher providers", algorithm);
    }

    /**
     * Tests if the given algorithm is supported.
     *
     * @param   algorithm the algorithm to support.
     * @return  {@code true} if given algorithm is supported; otherwise returns {@code false}.
     */
    boolean isSupported(final String algorithm);

    /**
     * Creates an instance of the {@link Cipher} with given arguments.
     *
     * @param   arguments the set of values that required for the proper initialization.
     * @return  an instance of the {@link Cipher}.
     */
    Cipher newCipher(final Object... arguments);

}