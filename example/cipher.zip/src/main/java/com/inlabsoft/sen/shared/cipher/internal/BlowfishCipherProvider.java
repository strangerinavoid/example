/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher.internal;

import static java.lang.String.valueOf;
import static java.util.Arrays.copyOf;
import static java.util.Base64.getDecoder;
import static java.util.Base64.getEncoder;
import static java.util.Objects.requireNonNull;

import static javax.crypto.Cipher.DECRYPT_MODE;
import static javax.crypto.Cipher.ENCRYPT_MODE;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import com.inlabsoft.sen.shared.cipher.CipherException;
import com.inlabsoft.sen.shared.cipher.CipherProvider;

/**
 * The {@code BlowfishCipherProvider} class is a {@link CipherProvider} implementation that creates instances of
 * {@link com.inlabsoft.sen.shared.cipher.Cipher}, based on symmetric-key block cipher <b>Blowfish</b>.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class BlowfishCipherProvider implements CipherProvider {

    /**
     * The {@code BlowfishCipher} class is a {@link com.inlabsoft.sen.shared.cipher.Cipher} implementation that uses
     * symmetric-key block cipher <b>Blowfish</b> to encrypt and decrypt given data.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private static final class BlowfishCipher implements com.inlabsoft.sen.shared.cipher.Cipher {

        private static byte[] decrypt(final byte[] key, final byte[] data) {
            try {
                return newCipher(DECRYPT_MODE, key).doFinal(getDecoder().decode(data));
            } catch (IllegalBlockSizeException |
                    BadPaddingException |
                    NoSuchAlgorithmException |
                    NoSuchPaddingException |
                    InvalidKeyException e) {
               throw new CipherException(
                   "An unexpected error occurred while trying to decrypt data with '%s' cipher: %s", e,
                   ALGORITHM, e.getMessage());
           }
        }

        private static byte[] encrypt(final byte[] key, final byte[] data) {
            try {
                return getEncoder().encode(newCipher(ENCRYPT_MODE, key).doFinal(data));
            } catch (IllegalBlockSizeException |
                     BadPaddingException |
                     NoSuchAlgorithmException |
                     NoSuchPaddingException |
                     InvalidKeyException e) {
                throw new CipherException(
                    "An unexpected error occurred while trying to encrypt data with '%s' cipher: %s", e,
                    ALGORITHM, e.getMessage());
            }
        }

        private static Cipher newCipher(final int opmode, final byte[] key)
                throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
            final Cipher instance = Cipher.getInstance(ALGORITHM);

            instance.init(opmode, new SecretKeySpec(getDecoder().decode(key), ALGORITHM));
            return instance;
        }

        private final byte[] key;

        /**
         * Creates an instance of class {@code BlowfishCipher}.
         *
         * @param   key a secret key that used to {@link #encrypt(byte[])} or {@link #unencrypt(byte[])} data.
         */
        private BlowfishCipher(final byte[] key) {
            this.key = copyOf(key, key.length);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public byte[] encrypt(final byte[] data) {
            return encrypt(this.key, data);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public byte[] unencrypt(final byte[] data) {
            return decrypt(this.key, data);
        }

    }

    private static final String ALGORITHM = "Blowfish";

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSupported(final String algorithm) {
        return ALGORITHM.equalsIgnoreCase(algorithm);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public com.inlabsoft.sen.shared.cipher.Cipher newCipher(final Object... arguments) {
        for (final Object key : requireNonNull(arguments, "A secret key argument is expected")) {
            if (null == key) {
                continue;
            }
            return new BlowfishCipher(key instanceof byte[] ? (byte[])key : valueOf(key).getBytes());
        }

        throw new CipherException("Cannot create cipher with null key");
    }

}