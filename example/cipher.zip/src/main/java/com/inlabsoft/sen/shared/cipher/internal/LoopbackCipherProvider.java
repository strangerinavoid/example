/*
 * InLab Software Product
 *
 * Copyright (c) 2020, InLab Software, LLC. All rights reserved.
 * Use is subject to license terms.
 *
 * http://www.inlabsoft.com/products/product/license
 */
package com.inlabsoft.sen.shared.cipher.internal;

import com.inlabsoft.sen.shared.cipher.Cipher;
import com.inlabsoft.sen.shared.cipher.CipherProvider;

/**
 * The {@code LoopbackCipherProvider} is a {@link CipherProvider} implementation that creates instances of
 * {@link Cipher} that do nothing with the data, but returns data as it is.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class LoopbackCipherProvider implements CipherProvider {

    /**
     * The {@code LoopbackCipher} class is a {@link Cipher} implementation that returns given data as it is.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private static final class LoopbackCipher implements Cipher {

        /**
         * Creates an instance of class {@code LoopbackCipher}.
         */
        private LoopbackCipher() {}

        /**
         * {@inheritDoc}
         */
        @Override
        public byte[] encrypt(final byte[] data) {
            return data;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public byte[] unencrypt(final byte[] data) {
            return data;
        }

    }

    private static final String ALGORITHM = "Loopback";

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSupported(final String algorithm) {
        return ALGORITHM.equalsIgnoreCase(algorithm);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Cipher newCipher(final Object... arguments) {
        return new LoopbackCipher();
    }

}