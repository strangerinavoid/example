package com.example.microservice.Service2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
