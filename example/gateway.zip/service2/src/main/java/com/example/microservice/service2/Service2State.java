package com.example.microservice.service2;

import static java.util.Objects.requireNonNullElse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromValue;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.HandlerFunction;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import reactor.core.publisher.Mono;

/**
 * The {@code Service2State} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Component
public class Service2State implements HandlerFunction<ServerResponse> {

    @Override
    public Mono<ServerResponse> handle(final ServerRequest request) {
        final var value = request.headers().firstHeader("x-auth");

        return ServerResponse.ok()
            .contentType(APPLICATION_JSON)
            .header("x-auth", "x-response")
            .header("x-service", "service2")
            .body(fromValue(requireNonNullElse(value, "THE AUTHENTICATION IS MISSING")));
    }

}