package com.example.microservice.service2;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

/**
 * The {@code Service2Router} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Configuration
public class Service2Router {

      @Bean
      public RouterFunction<ServerResponse> route(final Service2State state, final Service2Token token) {
          return RouterFunctions
              .route(GET("/api/service2/state")
              .and(accept(APPLICATION_JSON)), state)
              .andRoute(GET("/api/service2/token"), token);
      }

}