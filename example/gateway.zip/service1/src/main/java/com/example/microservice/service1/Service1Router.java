package com.example.microservice.service1;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

/**
 * The {@code Service1Router} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Configuration
public class Service1Router {

      @Bean
      public RouterFunction<ServerResponse> route(final Service1State state, final Service1Token token) {
          return RouterFunctions
              .route(GET("/api/service1/state")
              .and(accept(APPLICATION_JSON)), state)
              .andRoute(GET("/api/service1/token"), token);
      }

}