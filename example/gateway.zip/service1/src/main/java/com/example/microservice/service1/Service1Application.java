package com.example.microservice.service1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Service1Application {

	public static void main(final String[] args) {
		SpringApplication.run(Service1Application.class, args);
	}

}