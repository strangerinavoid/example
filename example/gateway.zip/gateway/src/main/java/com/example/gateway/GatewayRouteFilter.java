package com.example.gateway;

import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

/**
 * The {@code GatewayRouteFilter} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Component
@RefreshScope
public class GatewayRouteFilter implements GatewayFilter {

    private final GatewayRouteValidator validator;

    @Autowired
    protected GatewayRouteFilter(final GatewayRouteValidator validator) {
        this.validator = validator;
    }

    @Override
    public Mono<Void> filter(final ServerWebExchange exchange, final GatewayFilterChain chain) {
        final var request = exchange.getRequest();

        if (this.validator.test(request)) {
            if (isAuthMissing(request)) {
                return onError(exchange, "Authorization header is missing in request", UNAUTHORIZED);
            }

            final var token = getTokenHeader(request);

            if (!"VALID".equals(token)) {
                return onError(exchange, "Authorization header is invalid", UNAVAILABLE_FOR_LEGAL_REASONS);
            }
            populateRequestWithHeaders(request);
        }
        return chain.filter(exchange);
    }

    private Object getTokenHeader(final ServerHttpRequest request) {
        return request.getHeaders().getOrEmpty("x-token").get(0);
    }

    private boolean isAuthMissing(final ServerHttpRequest request) {
        return !request.getHeaders().containsKey("x-auth");
    }

    private Mono<Void> onError(final ServerWebExchange exchange, final String message, final HttpStatus status) {
        final var response = exchange.getResponse();

        response.setStatusCode(status);
        response.getHeaders().set("x-error", message);
        return response.setComplete();
    }

    private void populateRequestWithHeaders(final ServerHttpRequest request) {
        request.mutate()
            .header("x-token", "token")
            .build();
    }

}