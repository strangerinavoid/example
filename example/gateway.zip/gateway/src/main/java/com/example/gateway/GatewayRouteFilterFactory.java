package com.example.gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

/**
 * The {@code GatewayRouteFilterFactory} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Component
public class GatewayRouteFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private final GatewayRouteFilter filter;

    @Autowired
    protected GatewayRouteFilterFactory(final GatewayRouteFilter filter) {
        this.filter = filter;
    }

    @Override
    public GatewayFilter apply(final Object config) {
        return this.filter;
    }

}