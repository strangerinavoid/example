package com.example.gateway;

import java.util.List;
import java.util.function.Predicate;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

/**
 * The {@code GatewayRouteValidator} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Component
public class GatewayRouteValidator implements Predicate<ServerHttpRequest> {

    public static final List<String> OPEN_ENDPOINTS = List.of("/state");

    @Override
    public boolean test(final ServerHttpRequest t) {
        return OPEN_ENDPOINTS.stream().noneMatch(t.getURI().getPath()::endsWith);
    }

}