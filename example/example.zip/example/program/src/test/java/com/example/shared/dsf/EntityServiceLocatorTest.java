package com.example.shared.dsf;

import static java.util.stream.Collectors.joining;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static com.example.shared.core.type.Type.asType;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.dsf.data.ExampleEntity;
import com.example.shared.dsf.data.ExampleEntityServiceImpl;

/**
 * The {@code EntityServiceLocatorTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class EntityServiceLocatorTest {

    private static final class EntityServiceLocatorMock implements EntityServiceLocator {

        private final AtomicBoolean closed = new AtomicBoolean();

        private final Map<String, EntityService<?>> services;

        /**
         * Creates an instance of class {@code EntityServiceLocatorMock}.
         */
        private EntityServiceLocatorMock(final Map<String, EntityService<?>> services) {
            this.services = services;
        }

        @Override
        public void close() {
            if (this.closed.compareAndSet(false, true)) {
                // do close operations
                this.services.clear();
            }
        }

        @Override
        public <S extends EntityService<E>, E extends Entity<E>> S lookup(final Class<E> entityClass)
                throws EntityServiceLookupException {
            checkForClosed();

            return asType(this.services.get(entityClass.getName()));
        }

        @Override
        public <S extends EntityService<E>, E extends Entity<E>> S lookup(final EntityName name)
                throws EntityServiceLookupException {
            checkForClosed();

            return asType(this.services.get(name.getComponents().stream().collect(joining("."))));
        }

        private void checkForClosed() {
            if (this.closed.compareAndSet(false, false)) {
                return;
            }

             throw new EntityServiceLookupException("Unable to lookup for an entity service using closed service "
                + "locator");
        }

    }

    static EntityServiceLocator mockBy(final Map<String, EntityService<?>> services) {
        return new EntityServiceLocatorMock(Map.copyOf(services));
    }

    private EntityServiceLocator locator;

    @BeforeEach
    void setUp() {
        this.locator = mockBy(Map.of(ExampleEntity.class.getName(), new ExampleEntityServiceImpl()));
    }

    @Test
    void testLookupClass() {
        final var service = assertDoesNotThrow(() -> this.locator.lookup(ExampleEntity.class));

        assertNotNull(service);
    }

    @Test
    void testLookupEntityName() {
        final var name = EntityNameTest.mockBy("test:" + ExampleEntity.class.getName());
        final var service = assertDoesNotThrow(() -> this.locator.lookup(name));

        assertNotNull(service);
    }

}