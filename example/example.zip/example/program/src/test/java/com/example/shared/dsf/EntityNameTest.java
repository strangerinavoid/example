package com.example.shared.dsf;

import static java.lang.String.join;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.joining;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The {@code EntityNameTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class EntityNameTest {

    private static final class EntityNameMock implements EntityName {

        private final String namespace;
        private final List<String> components;

        EntityNameMock(final String namespace, final List<String> components) {
            this.namespace = namespace;
            this.components = List.copyOf(components);
        }

        @Override
        public List<String> getComponents() {
            return this.components;
        }

        @Override
        public String getEntity() {
            return this.components.get(this.components.size() - 1);
        }

        @Override
        public String getName() {
            return join(":", this.namespace, this.components.stream().collect(joining("/")));
        }

        @Override
        public String getNamespace() {
            return this.namespace;
        }

    }

    private static final String EXAMPLE_NAME = "jndi:sid/common/com.example.shared.sid.Entity";

    static EntityName mockBy(final String name) {
        final var parts = requireNonNull(name).split("[:\\s]+");
        final var namespace = parts[0];
        final var components = Stream.of(parts[1].split("\\/")).toList();

        return new EntityNameMock(namespace, components);
    }

    private EntityName name;

    @BeforeEach
    void setUp() {
        this.name = mockBy(EXAMPLE_NAME);
    }

    @Test
    void testCompareTo() {
        assertEquals(-1, mockBy("jndi:sid/common/com.example.shared.sid.Entit").compareTo(this.name));
        assertEquals( 0, mockBy(EXAMPLE_NAME).compareTo(this.name));
        assertEquals(+1, mockBy("jndi:sid/common/com.example.shared.sid.EntityA").compareTo(this.name));
    }

    @Test
    void testGetComponents() {
        assertEquals(List.of("sid", "common", "com.example.shared.sid.Entity"), this.name.getComponents());
    }

    @Test
    void testGetEntity() {
        assertEquals("com.example.shared.sid.Entity", this.name.getEntity());
    }

    @Test
    void testGetName() {
        assertEquals(EXAMPLE_NAME, this.name.getName());
    }

    @Test
    void testGetNamespace() {
        assertEquals("jndi", this.name.getNamespace());
    }

}