package com.example.shared.dsf.data;

import static java.util.Objects.requireNonNull;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.example.shared.dsf.Attribute;
import com.example.shared.dsf.AttributeAccessException;
import com.example.shared.dsf.EntityKey;
import com.example.shared.dsf.EntityName;

/**
 * The {@code ExampleEntityImpl} is a mock implementation of the {@link ExampleEntity} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class ExampleEntityImpl implements ExampleEntity {

    private final EntityKey<ExampleEntity> key;

    public ExampleEntityImpl() {
        this(null);
    }

    public ExampleEntityImpl(final EntityKey<ExampleEntity> key) {
        this.key = key;
    }

    @Override
    public Map<String, Object> getAllPopulatedAttributes() {
        return null;
    }

    @Override
    public String[] getAttributeNames() {
        return null;
    }

    @Override
    public <E> E getAttributeValue(final String attributeName) {
        return null;
    }

    @Override
    public Map<String, Object> getAttributeValues(final String[] attributeNames) {
        return null;
    }

    @Override
    public Class<ExampleEntityImpl> getEntityClass() {
        return ExampleEntityImpl.class;
    }

    @Override
    public EntityKey<ExampleEntity> getEntityKey() throws AttributeAccessException {
        return this.key;
    }

    @Override
    public EntityName getEntityName() {
        return new EntityName() {

            @Override
            public List<String> getComponents() {
                return List.of(getEntity().split("\\."));
            }

            @Override
            public String getEntity() {
                return ExampleEntity.class.getName();
            }

            @Override
            public String getName() {
                return "jndi:sid/common/" + getEntity();
            }

            @Override
            public String getNamespace() {
                return "jndi";
            }
        };
    }

    @Override
    public String[] getPopulatedAttributeNames() {
        return null;
    }

    @Override
    public boolean isFullyPopulated() {
        return false;
    }

    @Override
    public boolean isPopulated(final String attributeName) {
        return false;
    }

    @Override
    public void populateAllAttributes() {

    }

    @Override
    public void populateAttribute(final String attributeName) {

    }

    @Override
    public void setAttributeValue(final String attributeName, final Object value) {

    }

    @Override
    public void setAttributeValues(final Map<String, Object> attributeNamesAndValuePairs) {

    }

    @Override
    public void setEntityKey(final EntityKey<ExampleEntity> key) throws AttributeAccessException {
        if (this.key == key) {
            return;
        }
        this.key.setKey(requireNonNull(key).getKey());
    }

    @Override
    public Stream<Attribute<?>> stream() {
        return Stream.of();
    }

    @Override
    public void unpopulateAllAttributes() {

    }

    @Override
    public void unpopulateAttribute(final String attributeName) {

    }

}