package com.example.shared.dsf.data;

import com.example.shared.dsf.Entity;

/**
 * The {@code ExampleEntity} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface ExampleEntity extends Entity<ExampleEntity> {}