package com.example.shared.dsf;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.example.shared.core.type.Type.asType;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.dsf.data.ExampleEntity;
import com.example.shared.dsf.data.ExampleEntityServiceImpl;

/**
 * The {@code EntityServiceManagerTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class EntityServiceManagerTest {

    private static final class EntityServiceManagerMock implements EntityServiceManager {

        private final Map<String, EntityServiceLocator> locators;

        /**
         * Creates an instance of class {@code EntityServiceManagerMock}.
         */
        public EntityServiceManagerMock(final Map<String, EntityServiceLocator> locators) {
            this.locators = Map.copyOf(locators);
        }

        @Override
        public <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(final Class<E> entityClass)
                throws EntityServiceLookupException {
            return asType(this.locators.values().stream()
                .map(l -> l.lookup(entityClass))
                .filter(Objects::nonNull)
                .findFirst());
        }

        @Override
        public <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(final EntityName name)
                throws EntityServiceLookupException {
            return Optional.ofNullable(this.locators.get(name.getNamespace()))
                .map(l -> l.lookup(name));
        }

        @Override
        public <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(final String name)
                throws EntityServiceLookupException {
            return this.lookup(EntityNameTest.mockBy(name));
        }

    }

    private EntityServiceManager manager;

    @BeforeEach
    void setUp() {
        final Map<String, EntityService<?>> services =
            Map.of(ExampleEntity.class.getName(), new ExampleEntityServiceImpl());
        final var locators = Map.of("test", EntityServiceLocatorTest.mockBy(services),
            "jndi", EntityServiceLocatorTest.mockBy(Map.of()));

        this.manager = new EntityServiceManagerMock(locators);
    }

    @Test
    void testLookupClass() {
        final var service = assertDoesNotThrow(() -> this.manager.lookup(ExampleEntity.class));

        assertNotNull(service);
        assertTrue(service.isPresent());
        assertTrue(service.get() instanceof ExampleEntityServiceImpl);
    }

    @Test
    void testLookupEntityName() {
        final var service = assertDoesNotThrow(() ->
            this.manager.lookup(EntityNameTest.mockBy("test:" + ExampleEntity.class.getName())));

        assertNotNull(service);
        assertTrue(service.isPresent());
        assertTrue(service.get() instanceof ExampleEntityServiceImpl);
    }

    @Test
    void testLookupString() {
        final var service = assertDoesNotThrow(() -> this.manager.lookup("test:" + ExampleEntity.class.getName()));

        assertNotNull(service);
        assertTrue(service.isPresent());
        assertTrue(service.get() instanceof ExampleEntityServiceImpl);
    }

}