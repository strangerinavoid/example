package com.example.shared.dsf.key;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.dsf.Entity;

/**
 * The {@code LongEntityKeyTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LongEntityKeyTest {

    private interface MockEntity extends Entity<MockEntity> {}

    private LongEntityKey<MockEntity> key;

    @BeforeEach
    void setUp() {
        this.key = assertDoesNotThrow(() -> new LongEntityKey<>(mock(MockEntity.class), "id"));
    }

    @Test
    void testConvert() {
        final var v = assertDoesNotThrow(() -> this.key.convert("100"));

        assertEquals(100L, v);
    }

    @Test
    void testConvertNullValue() {
        final var v = assertDoesNotThrow(() -> this.key.convert(null));

        assertNull(v);
    }

    @Test
    void testConvertWrongValue() {
        final var ex = assertThrows(NumberFormatException.class, () -> this.key.convert("ABC"));

        assertEquals("For input string: \"ABC\"", ex.getMessage());
    }

}