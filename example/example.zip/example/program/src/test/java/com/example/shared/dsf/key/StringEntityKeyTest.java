package com.example.shared.dsf.key;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.dsf.Entity;

/**
 * The {@code StringEntityKeyTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class StringEntityKeyTest {

    private interface MockEntity extends Entity<MockEntity> {}

    private StringEntityKey<MockEntity> key;

    @BeforeEach
    void setUp() {
        this.key = assertDoesNotThrow(() -> new StringEntityKey<>(mock(MockEntity.class), "id"));
    }

    @Test
    void testConvert() {
        final var v = assertDoesNotThrow(() -> this.key.convert("hello"));

        assertEquals("hello", v);
    }

    @Test
    void testConvertNullValue() {
        final var v = assertDoesNotThrow(() -> this.key.convert(null));

        assertNull(v);
    }

}