package com.example.shared.dsf.key;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.dsf.Entity;

/**
 * The {@code UuidEntityKeyTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class UuidEntityKeyTest {

    private interface MockEntity extends Entity<MockEntity> {}

    private UuidEntityKey<MockEntity> key;

    @BeforeEach
    void setUp() {
        this.key = assertDoesNotThrow(() -> new UuidEntityKey<>(mock(MockEntity.class), "id"));
    }

    @Test
    void testConvert() {
        final var u = UUID.randomUUID();
        final var v = assertDoesNotThrow(() -> this.key.convert(u.toString()));

        assertEquals(u, v);
    }

    @Test
    void testConvertNullValue() {
        final var v = assertDoesNotThrow(() -> this.key.convert(null));

        assertNull(v);
    }

    @Test
    void testConvertWrongValue() {
        final var ex = assertThrows(IllegalArgumentException.class, () -> this.key.convert("ABC"));

        assertEquals("Invalid UUID string: ABC", ex.getMessage());
    }

}