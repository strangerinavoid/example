package com.example.shared.dsf.data;

import com.example.shared.dsf.EntityService;

/**
 * The {@code ExampleEntityService} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface ExampleEntityService extends EntityService<ExampleEntity> {}