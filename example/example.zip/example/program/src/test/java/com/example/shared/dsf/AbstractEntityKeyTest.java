package com.example.shared.dsf;

import static java.util.Objects.hash;
import static java.util.Optional.empty;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import static com.example.shared.core.type.Type.asType;
import static com.example.shared.utils.Strings.EMPTY_STRING;

import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.core.type.Type;

/**
 * The {@code AbstractEntityKeyTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class AbstractEntityKeyTest {

    private static final class ExtraMockEntityKey extends MockEntityKey {

        public ExtraMockEntityKey(final MockEntity entity) {
            super("id", entity);
        }

    }

    private interface MockEntity extends Entity<MockEntity> {}

    private static class MockEntityKey extends AbstractEntityKey<Boolean, MockEntityKey, MockEntity> {

        private static final Type<Boolean> TYPE = Type.of(Boolean.class);

        public MockEntityKey(final MockEntity entity) {
            super(entity, IDENTIFIER, TYPE);
        }

        public MockEntityKey(final String component, final MockEntity entity) {
            super(entity, component, TYPE);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        protected Boolean convert(final String key) {
            return TYPE.as(key);
        }

    }

    private static final String IDENTIFIER = "identifier";

    private MockEntityKey key;

    @BeforeEach
    void setUp() {
        this.key = assertDoesNotThrow(() -> new MockEntityKey(mock(MockEntity.class)));
    }

    @Test
    void testClear() {
        assertEquals(EMPTY_STRING, this.key.getKey());
        assertEquals(Set.of(empty()), this.key.getComponents(IDENTIFIER, "fake", "name"));
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.clear());
        assertEquals(EMPTY_STRING, this.key.getKey());
    }

    @Test
    void testCompareTo() {
        assertEquals( 0, this.key.compareTo(this.key));

        final var k1 = new MockEntityKey(mock(MockEntity.class));
        final var k2 = new MockEntityKey(mock(MockEntity.class));
        final var k3 = new MockEntityKey(mock(MockEntity.class));
        final var k4 = new MockEntityKey(mock(MockEntity.class));

        k1.setKey("false");
        k2.setKey("true");
        k3.setKey("true");

        assertEquals(-1, k1.compareTo(k2));
        assertEquals( 1, k2.compareTo(k1));
        assertEquals( 0, k2.compareTo(k3));
        assertEquals( 0, k3.compareTo(k2));
        assertEquals( 1, k3.compareTo(k1));
        assertEquals(-1, this.key.compareTo(k1));
        assertEquals(-1, this.key.compareTo(k2));
        assertEquals( 0, this.key.compareTo(k4));
        assertEquals( 1, k1.compareTo(this.key));
        assertEquals( 1, k2.compareTo(this.key));
        assertEquals( 0, k4.compareTo(this.key));
    }

    @Test
    void testCompareToNull() {
        final var ex = assertThrows(NullPointerException.class, () -> this.key.compareTo(null));

        assertEquals("Unable to compare entity key with null value", ex.getMessage());
    }

    @Test
    void testCompareToWithAnotherClass() {
        final var k = new ExtraMockEntityKey(mock(MockEntity.class));
        final var ex = assertThrows(IncomparableKeyException.class, () -> this.key.compareTo(k));

        assertEquals("An original key [identifier=null] cannot be compared with specified one [id=null]",
            ex.getMessage());
    }

    @Test
    void testCompareToWithAnotherComponent() {
        final var k = new MockEntityKey("id", mock(MockEntity.class));
        final var ex = assertThrows(IncomparableKeyException.class, () -> this.key.compareTo(k));

        assertEquals("An original key [identifier=null] cannot be compared with specified one [id=null]",
            ex.getMessage());
    }

    @Test
    void testCompareToWrongValue() {
        final EntityKey<MockEntity> k1 = asType(mock(AbstractEntityKey.class));
        final var ex1 = assertThrows(IncomparableKeyException.class, () ->
            this.key.compareTo(k1));

        assertEquals("An original key [identifier=null] cannot be compared with specified one Mock for "
            + "AbstractEntityKey, hashCode: " + k1.hashCode(), ex1.getMessage());

        final EntityKey<MockEntity> k2 = asType(mock(EntityKey.class));
        final var ex2 = assertThrows(IncomparableKeyException.class, () ->
            this.key.compareTo(k2));

        assertEquals("An original key [identifier=null] cannot be compared with specified one Mock for "
            + "EntityKey, hashCode: " + k2.hashCode(), ex2.getMessage());
    }

    @Test
    void testEquals() {
        assertEquals(this.key, this.key);

        final var m1 = mock(MockEntity.class);
        final var m2 = mock(MockEntity.class);

        final var k1 = new MockEntityKey(m1);
        final var k2 = new MockEntityKey(m2);
        final var k3 = new MockEntityKey(m2);
        final var k4 = new MockEntityKey(null);

        k1.setKey("false");
        k2.setKey("true");
        k3.setKey("true");

        assertEquals(k1, k1);
        assertEquals(k2, k3);
        assertEquals(k3, k2);
        assertEquals(k4, k4);
        assertNotEquals(k1, k2);
        assertNotEquals(k3, k1);
        assertNotEquals(k1, k4);
        assertNotEquals(k4, k1);
    }

    @Test
    void testEqualsWithAnotherClass() {
        assertEquals(this.key, this.key);

        final var k = new ExtraMockEntityKey(mock(MockEntity.class));

        k.setKey("false");

        assertEquals(k, k);
        assertNotEquals(this.key, k);
        assertNotEquals(k, this.key);
    }

    @Test
    void testEqualsWithAnotherComponent() {
        assertEquals(this.key, this.key);

        final var k = new MockEntityKey("id", mock(MockEntity.class));

        k.setKey("false");

        assertEquals(k, k);
        assertNotEquals(this.key, k);
        assertNotEquals(k, this.key);
    }

    @Test
    void testEqualsWithNull() {
        final MockEntityKey k = null;

        assertNotEquals(this.key, k);
    }

    @Test
    void testEqualsWithNullEntity() {
        assertEquals(this.key, this.key);

        final var k = new MockEntityKey(null);

        k.setKey("false");
        this.key.setKey("false");

        assertEquals(k, k);
        assertNotEquals(this.key, k);
        assertNotEquals(k, this.key);

        this.key.compareTo(k);
    }

    @Test
    void testEqualsWithWrongValue() {
        assertNotEquals(this.key, new Object());
    }

    @Test
    void testGetComponent() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals(true, this.key.getComponent(IDENTIFIER));
    }

    @Test
    void testGetComponentNames() {
        assertEquals(Set.of(IDENTIFIER), this.key.getComponentNames());
    }

    @Test
    void testGetComponents() {
        assertEquals(Set.of(empty()), this.key.getComponents());
        assertEquals(Set.of(empty()), this.key.getComponents(null, "fake", IDENTIFIER, IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals(Set.of(Optional.of(true)), this.key.getComponents());
    }

    @Test
    void testGetComponentsWithNullNames() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.getComponents((String[])null));

        assertEquals("Unsupported one or more component(s) 'null' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testGetComponentsWithWrongNames() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.getComponents(null, "unknown", "unidentified"));

        assertEquals("Unsupported one or more component(s) '[null, unknown, unidentified]' for the entity key with "
            + "declared component(s) 'identifier'", ex.getMessage());
    }

    @Test
    void testGetComponentWithNullName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () -> this.key.getComponent(null));

        assertEquals("Unsupported one or more component(s) 'null' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testGetComponentWithWrongName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.getComponent("unknown"));

        assertEquals("Unsupported one or more component(s) 'unknown' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testGetKey() {
        assertEquals(EMPTY_STRING, this.key.getKey());
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals("true", this.key.getKey());
    }

    @Test
    void testHasComponent() {
        assertFalse(this.key.hasComponent(null));
        assertFalse(this.key.hasComponent("undefined"));
        assertTrue(this.key.hasComponent(IDENTIFIER));
    }

    @Test
    void testHashCode() {
        assertEquals(hash(IDENTIFIER, EMPTY_STRING), this.key.hashCode());
        assertDoesNotThrow(() -> this.key.setKey("false"));
        assertEquals(hash(IDENTIFIER, "false"), this.key.hashCode());
    }

    @Test
    void testIsComplex() {
        assertFalse(this.key.isComplex());
    }

    @Test
    void testIsEmpty() {
        assertTrue(this.key.isEmpty());
        assertDoesNotThrow(() -> this.key.setKey("false"));
        assertFalse(this.key.isEmpty());
    }

    @Test
    void testRemoveComponent() {
        assertNull(this.key.removeComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals(true, this.key.removeComponent(IDENTIFIER));
    }

    @Test
    void testRemoveComponents() {
        assertEquals(Set.of(empty()), this.key.removeComponents());
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals(Set.of(Optional.of(true)), this.key.removeComponents(null, IDENTIFIER, "unknown"));
    }

    @Test
    void testRemoveComponentsWithNullNames() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.removeComponents((String[])null));

        assertEquals("Unsupported one or more component(s) 'null' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testRemoveComponentsWithWrongNames() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.removeComponents(null, "unknown", "unidentified"));

        assertEquals("Unsupported one or more component(s) '[null, unknown, unidentified]' for the entity key with "
            + "declared component(s) 'identifier'", ex.getMessage());
    }

    @Test
    void testRemoveComponentWithNullName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () -> this.key.removeComponent(null));

        assertEquals("Unsupported one or more component(s) 'null' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testRemoveComponentWithWrongName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.removeComponent("unknown"));

        assertEquals("Unsupported one or more component(s) 'unknown' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testSetComponent() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals(true, this.key.getComponent(IDENTIFIER));
    }

    @Test
    void testSetComponentWithNullName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.setComponent(null, null));

        assertEquals("Unsupported one or more component(s) 'null' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testSetComponentWithNullValue() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, null));
        assertNull(this.key.getComponent(IDENTIFIER));
    }

    @Test
    void testSetComponentWithObjectValue() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, new Object()));
        assertEquals(false, this.key.getComponent(IDENTIFIER));
    }

    @Test
    void testSetComponentWithWrongName() {
        final var ex = assertThrows(UnsupportedEntityKeyComponentException.class, () ->
            this.key.setComponent("unknown", null));

        assertEquals("Unsupported one or more component(s) 'unknown' for the entity key with declared component(s) "
            + "'identifier'", ex.getMessage());
    }

    @Test
    void testSetKey() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setKey("false"));
        assertEquals(false, this.key.getComponent(IDENTIFIER));
    }

    @Test
    void testSetKeyWithNull() {
        assertNull(this.key.getComponent(IDENTIFIER));
        assertDoesNotThrow(() -> this.key.setKey(null));
        assertNull(this.key.getComponent(IDENTIFIER)); // see the convert method of mock entity key above
    }

    @Test
    void testToString() {
        assertEquals("[identifier=null]", this.key.toString());
        assertDoesNotThrow(() -> this.key.setComponent(IDENTIFIER, true));
        assertEquals("[identifier=true]", this.key.toString());
    }

}