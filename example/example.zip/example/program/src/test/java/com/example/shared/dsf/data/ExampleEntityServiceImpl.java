package com.example.shared.dsf.data;

import static java.lang.String.valueOf;

import java.util.List;
import java.util.stream.Stream;

import com.example.shared.dsf.EntityException;
import com.example.shared.dsf.EntityKey;
import com.example.shared.dsf.EntityName;
import com.example.shared.dsf.EntityService;
import com.example.shared.dsf.key.LongEntityKey;

/**
 * The {@code ExampleEntityServiceImpl} is a mock implementation of the {@link ExampleEntityService} interface.
 *
 * @author Andrey OCHIROV
 * @version 1.0
 */
public class ExampleEntityServiceImpl implements ExampleEntityService {

    @Override
    public void createEntitiesByKeys(final EntityKey<ExampleEntity>[] keys, final ExampleEntity[] entities,
            final String... attributes) throws EntityException {
    }

    @Override
    public ExampleEntity[] createEntitiesByValues(final ExampleEntity[] entities, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public ExampleEntity createEntityByValue(final ExampleEntity entity, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public Stream<ExampleEntity> find(final String name) throws EntityException {
        return null;
    }

    @Override
    public Stream<ExampleEntity> getEntitiesByKeys(final EntityKey<ExampleEntity>[] keys, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public Stream<ExampleEntity> getEntitiesByTemplate(final ExampleEntity template, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public ExampleEntity getEntityByKey(final EntityKey<ExampleEntity> key, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public Class<ExampleEntity> getEntityClass() {
        return null;
    }

    @Override
    public Class<?> getEntityInterface() {
        return null;
    }

    @Override
    public EntityName getEntityName() {
        return new EntityName() {

            @Override
            public List<String> getComponents() {
                return List.of(getEntityType().split("\\."));
            }

            @Override
            public String getEntity() {
                return getEntityType();
            }

            @Override
            public String getName() {
                return "jndi:sid/common/" + getEntityType();
            }

            @Override
            public String getNamespace() {
                return "jndi";
            }
        };
    }

    @Override
    public EntityService<ExampleEntity> getEntityServiceReference() {
        return this;
    }

    @Override
    public String getEntityType() {
        return ExampleEntity.class.getName();
    }

    @Override
    public ExampleEntity makeEntity() {
        return new ExampleEntityImpl();
    }

    @Override
    public ExampleEntity makeEntityByEntityKey(final EntityKey<ExampleEntity> key) {
        return new ExampleEntityImpl(key);
    }

    @Override
    public ExampleEntity makeEntityByEntityKeyObject(final Object obj) {
        return null;
    }

    @Override
    public EntityKey<ExampleEntity> makeEntityKey() {
        return new LongEntityKey<ExampleEntity>(null, "id");
    }

    @Override
    public EntityKey<ExampleEntity> makeEntityKeyByObject(final Object obj) {
        final var key = new LongEntityKey<ExampleEntity>(null, "id");

        key.setKey(valueOf(obj));
        return key;
    }

    @Override
    public ExampleEntity makeEntityWithDefaults() {
        return makeEntity();
    }

    @Override
    public void removeEntitiesByKeys(final EntityKey<ExampleEntity>[] keys) throws EntityException {

    }

    @Override
    public void removeEntityByKey(final EntityKey<ExampleEntity> key) throws EntityException {

    }

    @Override
    public void setEntitiesByKeys(final EntityKey<ExampleEntity>[] keys, final ExampleEntity[] entities,
        final String... attributes) throws EntityException {

    }

    @Override
    public ExampleEntity[] setEntitiesByValues(final ExampleEntity[] entities, final String... attributes)
            throws EntityException {
        return null;
    }

    @Override
    public ExampleEntity setEntityByValue(final ExampleEntity entity, final String... attributes)
            throws EntityException {
        return null;
    }

}