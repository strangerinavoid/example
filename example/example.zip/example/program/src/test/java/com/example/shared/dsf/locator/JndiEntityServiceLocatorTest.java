package com.example.shared.dsf.locator;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junitpioneer.jupiter.SetSystemProperty;

import com.example.shared.dsf.EntityName;
import com.example.shared.dsf.data.ExampleEntity;
import com.example.shared.dsf.data.ExampleEntityServiceImpl;

/**
 * The {@code JndiEntityServiceLocatorTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@SetSystemProperty(key = Context.INITIAL_CONTEXT_FACTORY, value = "com.example.shared.naming.FlatContextFactory")
class JndiEntityServiceLocatorTest {

    @BeforeAll
    static void setUpAll() throws NamingException {
        final var context = new InitialContext();

        context.bind(ExampleEntity.class.getName(), new ExampleEntityServiceImpl());
    }

    private JndiEntityServiceLocator locator;

    @BeforeEach
    void setUp() {
        this.locator = assertDoesNotThrow(JndiEntityServiceLocator::new);
    }

    @Test
    void testLookupEntityClass() {
        assertNotNull(assertDoesNotThrow(() -> this.locator.lookup(ExampleEntity.class)));
    }

    @Test
    void testLookupEntityName() {
        final var name = new EntityName() {

            @Override
            public List<String> getComponents() {
                return List.of(getEntity().split("\\."));
            }

            @Override
            public String getEntity() {
                return ExampleEntity.class.getName();
            }

            @Override
            public String getName() {
                return "jndi:sid/common/" + getEntity();
            }

            @Override
            public String getNamespace() {
                return "jndi";
            }

        };
        assertNotNull(assertDoesNotThrow(() -> this.locator.lookup(name)));
    }

}