import com.example.program.example.ExampleEntry;
import com.example.shared.boot.BootEntry;
import com.example.shared.core.type.TypeService;
import com.example.shared.dsf.EntityServiceLocator;
import com.example.shared.dsf.locator.JndiEntityServiceLocator;

module example.program.example {

	 exports com.example.program.example;

	   opens com.example.program.example to spring.core;

	requires example.shared.boot;
	requires example.shared.core;
	requires example.shared.logging;
	requires example.shared.naming;
	requires example.shared.type;
	requires example.shared.utils;

	requires transitive java.naming;

		uses BootEntry;

	provides BootEntry
		with ExampleEntry;

	    uses EntityServiceLocator;

	provides EntityServiceLocator
	    with JndiEntityServiceLocator;

	    uses TypeService;

	requires spring.beans;
	requires spring.boot;
	requires spring.boot.autoconfigure;
	requires spring.context;
	requires spring.core;
	requires spring.webflux;

	requires reactor.core;

}