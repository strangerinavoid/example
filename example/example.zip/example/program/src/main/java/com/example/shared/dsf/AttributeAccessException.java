package com.example.shared.dsf;

/**
 * The {@code AttributeAccessException} class is an entity exception that is thrown when a user tries to access or
 * manipulate an attribute when no such attribute is available.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public class AttributeAccessException extends EntityException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = 236931144628301355L;

    /**
     * Constructs a new attribute access exception with the default message key and specified cause.
     *
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the
     *          {@link Throwable#getCause()} method). A {@code null} value is permitted, and
     *          indicates that the cause is nonexistent or unknown.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public AttributeAccessException(final String message, final Object... arguments) {
        super(message, arguments);
    }

    /**
     * Constructs a new attribute access exception with the specified message key, parameters and
     * cause.
     * <p>
     * Note that the detail message associated with {@code cause} is <i>not</i> automatically
     * incorporated in this attribute access exception's detail message.
     *
     * @param   key the message key.
     * @param   params the message parameters.
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the
     *          {@link Throwable#getCause()} method). A {@code null} value is permitted, and
     *          indicates that the cause is nonexistent or unknown.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public AttributeAccessException(final String message, final Throwable cause, final Object... arguments) {
        super(message, cause, arguments);
    }

}