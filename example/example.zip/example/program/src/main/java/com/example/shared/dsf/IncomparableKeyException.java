package com.example.shared.dsf;

import static java.util.Objects.requireNonNull;

import static com.example.shared.core.type.Type.asType;

/**
 * The {@code IncomparableKeyException} class is an entity exception that thrown when user trying to compare
 * incomparable entity keys.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityKey
 */
public final class IncomparableKeyException extends EntityException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -5260183163053198324L;

    /**
     * The key to compare with.
     */
    private final EntityKey<?> comparedKey;

    /**
     * The original key.
     */
    private final EntityKey<?> key;

    /**
     * Constructs a new incomparable key exception with specified entity keys. The cause is not initialized, and may
     * subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   key the original key of the entity.
     * @param   comparedKey the key to compare with.
     * @throws  NullPointerException in case of {@code null} message.
     */
    public IncomparableKeyException(final EntityKey<?> key, final EntityKey<?> comparedKey) {
        super("An original key %s cannot be compared with specified one %s", key, comparedKey);

        this.key = requireNonNull(key);
        this.comparedKey = requireNonNull(comparedKey);
    }

    /**
     * Gets the key to compare with.
     *
     * @return  a key to compare.
     */
    public <E extends Entity<E>> EntityKey<E> getComparedKey() {
        return asType(this.comparedKey);
    }

    /**
     * Gets original key.
     *
     * @return  an original key to compare.
     */
    public <E extends Entity<E>> EntityKey<E> getKey() {
        return asType(this.key);
    }

}