package com.example.shared.dsf;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toUnmodifiableMap;
import static java.util.stream.Collectors.toUnmodifiableSet;

import static com.example.shared.utils.Annotations.isAnnotationPresent;
import static com.example.shared.utils.Reflections.isGetter;
import static com.example.shared.utils.Reflections.isSetter;
import static com.example.shared.utils.Reflections.propertyName;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Stream;

import com.example.shared.dsf.annotation.PrimaryKey;
import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerFactory;

/**
 * The {@code EntityHelper} class is a helper class that contains some static methods that used by abstract
 * implementations of basic entity interfaces such as {@link Entity}, {@link EntityKey} and {@link EntityService}.
 * <p>
 * Methods of this class is used to optimize work with meta information and to provide fast operations for entity
 * services.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class EntityHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityHelper.class);

    /**
     * The class that used as default implementation of the interface {@link EntityKey}. This class
     * used when entity key class for specified type/types not found.
     * <p>
     * This class also can be specified in the configuration. If configuration not available or
     * invalid will be used {@link ObjectEntityKey} class.
     */
    private static Class<?> defaultEntityKeyClass;

    /**
     * The cache map for entities attributes. Used for quick search of attributes in the entity.
     */
    private static final Map<Class<?>, Map<String, AttributeAccessor>> entityAttributes =
        new ConcurrentHashMap<>();

    /**
     * The cache map for interfaces that implemented by entity. Used for quick search of interfaces
     * of the entity.
     */
    private static final Map<Class<?>, List<Class<?>>> entityInterfaces = new ConcurrentHashMap<>();

    /**
     * The cache map for entity key classes. Used for quick access to entity key class for
     * corresponding entity.
     */
    private static final Map<Class<?>, Class<?>> entityKeyClasses = new ConcurrentHashMap<>();

    /**
     * The cache map for entity key components for corresponding entity.
     */
    private static final Map<Class<?>, Set<String>> entityKeyComponents = new ConcurrentHashMap<>();

    /**
     * The cache map for mapping entity to interfaces. Used for quick access to entity interface by
     * implementation class.
     */
    private static final Map<Class<?>, Class<?>> entityMapping = new ConcurrentHashMap<>();

    /**
     * The cache map for mapping type class and entity key implementation class. Used to identify which entity key
     * implementation class must be used for data type of primary key attribute.
     */
    private static final Map<Class<?>, Class<EntityKey<?>>> typeEntityKeyClasses = new ConcurrentHashMap<>();

    /**
     * TODO
     *
     * @param   rootEntity
     * @param   path
     * @return
     */
    public static <T extends Entity<T>> T getAttributeByPath(final Entity<?> rootEntity, final String path) {
        final Deque<String> pathStack = parsePath(path);

        return getObjectByPath(rootEntity, pathStack).getAttributeValue(pathStack.pop());
    }

    /**
     * Returns map of entity attributes for entity specified by class.
     * <p>
     * If some attributes defined in the implementation class (attribute can be defined by setter
     * and getter methods) they will be ignored cause only attributes, defined in the interfaces
     * that extends interface {@link Entity} will be used. In other words, in situation where we
     * have
     * <pre>
     * public interface MyEntity extends Entity&lt;MyEntity&gt; {
     *
     *     public long getId();
     *
     *     public void setId(long id);
     *
     * }
     *
     * public interface MyEntityAttribute {
     *
     *     public Object getAttribute();
     *
     *     public void setAttribute(Object object);
     *
     * }
     *
     * public class MyEntityImpl extends AbstractEntity<MyEntityImpl, MyEntity>
     *     implements MyEntity, MyEntityAttribute {
     *
     *     ...
     *
     * }</pre>
     * the result of method execution {@code getAttributes} will be map with only one
     * attribute - {@code id}. Cause interface {@code MyEntityAttribute} not extends
     * {@link Entity}.
     * <p>
     * If entity implementation class extends from another entity, for example
     * <pre>
     * public interface MyAdvancedEntity extends MyEntity {
     *
     *     public String getName();
     *
     *     public void setName(String name);
     *
     * }
     *
     * public class MyAdvancedEntityImpl extends MyEntityImpl
     *     implements MyAdvancedEntity {
     *
     *     ...
     *
     * }</pre>
     * the result of method execution {@code getAttributes} will be map with two attributes -
     * {@code id} and {@code name}. Cause class {@code MyAdvancedEntityImpl}
     * implements two interfaces {@code MyEntity} (through parent class
     * {@code MyEntityImpl}) and {@code MyAdvancedEntity} (directly).
     * <p>
     * If specified class is not an entity at all, will be thrown an {@link EntityException}.
     *
     * @param   entity the implementation class of the entity. Not an interface.
     * @return  map of entity attributes where as keys used names of attributes.
     */
    public static Map<String, AttributeAccessor> getAttributes(final Class<?> entity) {
        // cannot find entity attributes for class that is not an entity, so we must here throw an exception
        if (entity == null || !Entity.class.isAssignableFrom(entity)) {
            throw new EntityException("entity.notEntity",
                entity == null ? null : entity.getName());
        }

        return entityAttributes.computeIfAbsent(entity, k ->
            getInterfaces(entity).stream()
                .map(Class::getDeclaredMethods)
                .flatMap(Stream::of)
                .filter(m -> isGetter(m) || isSetter(m))
                .map(m -> Map.entry(m, propertyName(m)))
                .filter(e -> nonNull(e.getValue()))
                .collect(groupingBy(Entry::getValue,
                    toUnmodifiableMap(e -> isGetter(e.getKey()) ? FALSE : TRUE, Entry::getKey)))
                .entrySet()
                .stream()
                .map(e -> new AttributeAccessor(e.getKey(), e.getValue().get(FALSE), e.getValue().get(TRUE)))
                .collect(toUnmodifiableMap(AttributeAccessor::getName, Function.identity())));
    }

    /**
     * Returns default entity key implementation class. This class used to create entity key
     * instances by entity services.
     */
    public static Class<?> getDefaultKeyClass() {
        return defaultEntityKeyClass;
    }

    /**
     * Returns entity interface that implemented by specified class. An entity implementation can
     * implement only one entity interface. If specified class not implements an entity interface
     * directly but extends from implementation will be used interface from one of parent classes.
     * In other words, in situation where we have
     * <pre>
     * public interface MyEntity extends Entity&lt;MyEntity&gt; {
     *
     *     public long getId();
     *
     *     public void setId(long id);
     *
     * }
     *
     * public class MyEntityImpl extends AbstractEntity<MyEntityImpl, MyEntity>
     *     implements MyEntity {
     *
     *     ...
     *
     * }
     *
     * public class MyChildEntityImpl extends MyEntityImpl {
     *
     *     ...
     *
     * }</pre>
     * the result of method execution {@code getInterface} with argument
     * {@code MyEntityImpl.class} or {@code MyChildEntityImpl.class} will be class
     * {@code MyEntity}.
     * <p>
     * Abstract implementation of the entity service ({@link AbstractEntityService}) requires from
     * developers to implement only one entity interface in the entity implementation. If by some
     * reason class must implements more than one entity interface, developers must overwrite
     * corresponding logic in the {@link AbstractEntityService} in their service classes and do not
     * use this method.
     * <p>
     * If specified class is not an entity at all, will be thrown an {@link EntityException}.
     * <p>
     * If class implements more than one entity interface will be thrown an {@link EntityException}.
     *
     * @param   entity the implementation class of the entity. Not an interface.
     * @return  the entity interface class that implemented by specified class.
     */
    public static Class<?> getInterface(final Class<?> entity) {
        Class<?> entityInterface = entityMapping.get(entity);

        if (entityInterface != null) {
            return entityInterface;
        }

        // we should scan all class hierarchy to find real
        // entity interface
        for (Class<?> c = entity; c != null && entityInterface == null; c = c.getSuperclass()) {
            for (final Class<?> interfaceClass : c.getInterfaces()) {
                if (Entity.class.isAssignableFrom(interfaceClass)
                        && Entity.class != interfaceClass) {
                    if (entityInterface != null) {
                        throw new EntityException("entity.multiEntity",
                            c.getName());
                    }
                    entityInterface = interfaceClass;
                    // for proxy objects this validation is not actual cause proxy objects are
                    // implements all entity interfaces
                    if (Proxy.class.isAssignableFrom(entity)) {
                        break;
                    }
                }
            }
        }

        if (entityInterface == null) {
            throw new EntityException("entity.notEntity",
                entity.getName());
        }
        // adding into mapping information about mapping entity implementation to entity
        if (!Proxy.class.isAssignableFrom(entity)) {
            synchronized (entityMapping) {
                entityMapping.put(entity, entityInterface);
            }
        }
        return entityInterface;
    }

    /**
     * Returns all entity interfaces that implemented by specified class, include all entity
     * interfaces that implemented by parent classes.
     *
     * @param   entity the implementation class of the entity. Not an interface.
     * @return  a collection of entity interfaces that implemented by specified class.
     *
     * @see     #getInterface(Class)
     */
    public static List<Class<?>> getInterfaces(final Class<?> entity) {
        return entityInterfaces.computeIfAbsent(entity, k -> {
            final Set<Class<?>> interfaces = new LinkedHashSet<>();

            for (Class<?> clazz = entity; clazz != null; clazz = clazz.getSuperclass()) {
                interfaces.addAll(getInterfaces0(clazz));
            }
            return List.copyOf(interfaces);
        });
    }

    /**
     *
     * @param   entity
     * @return
     */
    public static Class<?> getKeyClass(final Class<?> entity) {
        Class<?> key = entityKeyClasses.get(entity);

        if (key != null) {
            return key;
        }
        final Set<Class<?>> components = new LinkedHashSet<>();

        for (Class<?> clazz = entity; clazz != null && components.isEmpty();
                clazz = clazz.getSuperclass()) {
            components.addAll(getKeyClasses0(clazz));
        }
        // detecting kind of entity key
        if (components.size() == 1) {
            // this is a single component key
            key = typeEntityKeyClasses.get(components.iterator().next());
        } else if (components.size() > 1) {
            // this is a complex (multicomponent) key in future versions must be upgraded
            key = defaultEntityKeyClass;
        }
        // if we not found key for such entity we'll just use default entity key class
        if (key == null) {
            key = defaultEntityKeyClass;
        }
        // adding into entity key components cache information for new entity;
        synchronized (entityKeyComponents) {
            entityKeyClasses.put(entity, key);
        }
        return key;
    }

    /**
     *
     * @param   entity
     * @return
     */
    public static Set<String> getKeyComponents(final Class<?> entity) {
        Set<String> components = entityKeyComponents.get(entity);

        if (components != null) {
            return components;
        }
        components = new LinkedHashSet<>();

        for (Class<?> clazz = entity; clazz != null && components.isEmpty();
                clazz = clazz.getSuperclass()) {
            components.addAll(getKeyComponents0(clazz));
        }

        // adding into entity key components cache information for new entity;
        synchronized (entityKeyComponents) {
            entityKeyComponents.put(entity, Collections.unmodifiableSet(components));
        }
        return entityKeyComponents.get(entity);
    }

    /**
     * TODO
     *
     * @param   rootEntity
     * @param   path
     * @param   value
     */
    public static void setAttributeByPath(final Entity<?> rootEntity, final String path, final Object value) {
        final Deque<String> pathStack = parsePath(path);

        if (pathStack.isEmpty()) {
            return;
        }
        getObjectByPath(rootEntity, pathStack).setAttributeValue(pathStack.pop(), value);
    }

    /**
     * FIXME add support for the index property of the primary key
     *
     * @param   clazz
     * @return
     */
    private static Set<Class<?>> getInterfaces0(final Class<?> clazz) {
        return getInterfaces1(clazz, isEntity(clazz, false))
            .collect(toUnmodifiableSet());
    }

    /**
     * TODO
     *
     * @param   clazz
     * @param   includeAll
     * @return
     */
    private static Stream<Class<?>> getInterfaces1(final Class<?> clazz, final boolean includeAll) {
        return Stream.of(clazz.getInterfaces())
            .filter(i -> isEntity(i, includeAll))
            .flatMap(i -> Stream.concat(Stream.of(i), getInterfaces1(i, includeAll)));
    }

    /**
     * TODO
     *
     * @param   clazz
     * @return
     */
    private static Set<Class<?>> getKeyClasses0(final Class<?> clazz) {
        return getKeyClasses1(clazz, isAnnotationPresent(clazz,
            com.example.shared.dsf.annotation.Entity.class));
    }

    /**
     * FIXME add support for the index property of the primary key
     *
     * @param   clazz
     * @return
     */
    private static Set<Class<?>> getKeyClasses1(final Class<?> clazz, final boolean includeAll) {
        final Set<Class<?>> keys = new LinkedHashSet<>();

        for (final Class<?> i : clazz.getInterfaces()) {
            if (notEntity(i, includeAll)) {
                continue;
            }

            for (final Method m : i.getDeclaredMethods()) {
                if (isAnnotationPresent(m, PrimaryKey.class)
                        && (m.getName().startsWith("set") && m.getParameterTypes().length == 1
                            || (m.getName().startsWith("is") || m.getName().startsWith("get"))
                        && m.getParameterTypes().length == 0)
                        && (Modifier.PUBLIC & m.getModifiers()) != 0
                        && (Modifier.STATIC & m.getModifiers()) == 0) {
                    try {
                        // detecting information about key structure
                        final Class<?> type = m.getParameterTypes().length == 1
                            ? m.getParameterTypes()[0] : m.getReturnType();

                        // remember key component class
                        keys.add(type);
                    } catch (final Exception e) {
                        LOGGER.error("helper.wrongMethod",
                            PrimaryKey.class.getSimpleName(), i.getName(), m.getName());
                    }
                }
            }
            keys.addAll(getKeyClasses0(i));
        }
        return keys;
    }

    /**
     * TODO
     *
     * @param   clazz
     * @return
     */
    private static Set<String> getKeyComponents0(final Class<?> clazz) {
        return getKeyComponents1(clazz, isAnnotationPresent(clazz,
            com.example.shared.dsf.annotation.Entity.class));
    }

    /**
     * FIXME add support for the index property of the primary key
     *
     * @param   clazz
     * @return
     */
    private static Set<String> getKeyComponents1(final Class<?> clazz, final boolean includeAll) {
        final Set<String> keys = new LinkedHashSet<>();

        for (final Class<?> i : clazz.getInterfaces()) {
            if (notEntity(i, includeAll)) {
                continue;
            }

            for (final Method m : i.getDeclaredMethods()) {
                if (isAnnotationPresent(m, PrimaryKey.class)
                        && (m.getName().startsWith("set") && m.getParameterTypes().length == 1
                            || (m.getName().startsWith("is") || m.getName().startsWith("get"))
                        && m.getParameterTypes().length == 0)
                        && (Modifier.PUBLIC & m.getModifiers()) != 0
                        && (Modifier.STATIC & m.getModifiers()) == 0) {
                    try {
                        final int position = m.getName().startsWith("is") ? 2 : 3;
                        // extracting primary key attribute name and saving it to meta information
                        // about entity
                        keys.add(m.getName().substring(position, position + 1).toLowerCase()
                            + m.getName().substring(position + 1));
                    } catch (final Exception e) {
                        LOGGER.error("helper.wrongMethod",
                            PrimaryKey.class.getSimpleName(), i.getName(), m.getName());
                    }
                }
            }
            keys.addAll(getKeyComponents0(i));
        }
        return keys;
    }

    /**
     * TODO
     *
     * @param   entity
     * @param   path
     * @return
     */
    private static Entity<?> getObjectByPath(final Entity<?> entity, final Deque<String> path) {
        if (path.size() <= 1) {
            return entity;
        }
        return getObjectByPath((Entity<?>)entity.getAttributeValue(path.pop()), path);
    }

    private static boolean isEntity(final Class<?> clazz, final boolean includeAll) {
        return Entity.class != clazz && Entity.class.isAssignableFrom(clazz)
            && (includeAll || isAnnotationPresent(clazz, com.example.shared.dsf.annotation.Entity.class));
    }

    /**
     * TODO
     *
     * @param   clazz
     * @return
     */
    private static boolean notEntity(final Class<?> clazz, final boolean includeAll) {
        return Entity.class == clazz || !Entity.class.isAssignableFrom(clazz)
            && !(isAnnotationPresent(clazz,
                com.example.shared.dsf.annotation.Entity.class) || includeAll);
    }

    /**
     * TODO
     *
     * @param   path
     * @return
     */
    private static Deque<String> parsePath(final String path) {
        final String[] p = path.split("\\.");

        if (p.length == 0) {
            // TODO Throw here special exception
            return null;
        }

        final Deque<String> pathStack = new LinkedList<>();

        for (int i = p.length - 1; i >= 0; i--) {
            pathStack.push(p[i]);
        }
        return pathStack;
    }

}