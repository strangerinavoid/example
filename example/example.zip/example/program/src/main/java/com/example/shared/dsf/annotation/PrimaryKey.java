package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import com.example.shared.dsf.Entity;

/**
 * The {@code PrimaryKey} annotation is a marker that used to specify attribute of the {@link Entity} that is a part of
 * primary key. In other words all attributes marked as {@code PrimaryKey} are meta information for correct entity's
 * primary key construction.
 * <p>
 * The contract of this annotation and {@link Entity} interface is that only attributes in the interface will used to
 * construct primary key and only from such interfaces that directly implemented by entity class. In other words, if
 * class {@code PersonEntityImpl} implements interface {@code PersonEntity} and extends from class
 * {@code PartyEntityImpl} that implements interface {@code Party} then only attributes from interface
 * {@code PersonEntity} will be used to build primary key for {@code PersonEntity} entity. But here is the one
 * exception: if interface {@code PersonEntity} does not declares any primary key attribute such attributes will be
 * searched in the {@code PartyEntity} interface. Such contract present to give ability to children classes to
 * overwrite configuration of the primary key if it needed and also to inherit primary key from parent interfaces.
 * <p>
 * In case when class directly implements several entity interfaces all attributes from such interfaces marked as
 * primary key will used to construct primary for such entity.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Target({METHOD})
@Retention(RUNTIME)
public @interface PrimaryKey {

    /**
     * The attribute index in the primary key if it required. This is an optional property and may be used only if
     * order of complex key values is important. By default index is less than zero and real index will be used as
     * index of attribute in the interface accessed through Java Reflection.
     */
    int value() default -1;

}