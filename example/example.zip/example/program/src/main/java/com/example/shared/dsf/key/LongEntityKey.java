package com.example.shared.dsf.key;

import com.example.shared.core.type.Type;
import com.example.shared.dsf.AbstractEntityKey;
import com.example.shared.dsf.Entity;

/**
 * The {@code LongEntityKey} class is a single value entity key that used {@link Long} value in key.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     AbstractEntityKey
 */
public final class LongEntityKey<E extends Entity<E>> extends AbstractEntityKey<Long, LongEntityKey<E>, E> {

    /**
     * The type that used to convert {@link String} values to a {@link Long} values.
     */
    private static final Type<Long> TYPE = Type.of(Long.class);

    /**
     * Creates an instance of class {@code LongEntityKey}.
     */
    public LongEntityKey(final E entity, final String componentName) {
        super(entity, componentName, TYPE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Long convert(final String key) {
        return TYPE.as(key);
    }

}