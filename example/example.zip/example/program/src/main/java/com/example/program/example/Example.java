package com.example.program.example;

import com.example.shared.boot.Boot;

public final class Example {

	public static void main(final String[] args) {
		final var boot = Boot.newBuilder()
			.name("Example")
			.entry(ExampleEntry.class)
			.build();

		boot.run(args).exit();
	}

}