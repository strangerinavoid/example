package com.example.shared.dsf;

/**
 * The {@code UnsupportedEntityKeyComponentException} class is an entity exception that thrown when user trying to
 * access unsupported entity key component.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class UnsupportedEntityKeyComponentException extends EntityException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -792605386875897840L;

    /**
     * Constructs a new unsupported entity key component exception with the specified parameters. The cause is not
     * initialized, and may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   params the message parameters.
     */
    public UnsupportedEntityKeyComponentException(final Object... arguments) {
        super("Unsupported one or more component(s) '%s' for the entity key with declared component(s) '%s'",
            arguments);
    }

}