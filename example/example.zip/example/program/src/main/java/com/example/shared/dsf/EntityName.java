package com.example.shared.dsf;

import java.util.List;

/**
 * The {@code EntityName} class is a distinguish composite entity name that used to access to {@link EntityService} of
 * such {@link Entity}.
 * <p>
 * The entity name consist of {@code namespace}, {@code components} and {@code entity name}. The {@code namespace} used
 * by {@link EntityServiceManager} to find correct {@link EntityServiceLocator} for such name; {@code components} and
 * {@code entity name} used by {@link EntityServiceLocator} to find corresponding {@link EntityService}.
 * <p>
 * The entity name can be represented as {@link String}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityServiceManager
 */
public interface EntityName extends Comparable<EntityName> {

    /**
     * Compares two entity names lexicographically.
     * <p>
     * The comparison is based on the UNICODE value of each character in the names, represented as strings. The
     * character sequence represented by this {@link EntityName} object is compared lexicographically to the character
     * sequence represented by the argument entity name.
     * <p>
     * The result is a negative integer if this {@link EntityName} object lexicographically precedes the argument entity
     * name. The result is a positive integer if this {@link EntityName} object lexicographically follows the argument
     * entity name. The result is {@code zero} if the names are equal; {@code compareTo} returns {@code 0} exactly when
     * the {@link #equals(Object)} method would return {@code true}.
     * <p>
     * For more detail description of lexicographic ordering see documentation to {@link String#compareTo(String)}
     * method.
     *
     * @param   o the {@link EntityName} to be compared.
     * @return  the value {@code 0} if the argument entity name is equal to this entity name; a value less than
     *          {@code 0} if this entity name is lexicographically less than the entity name argument; and a value
     *          greater than {@code 0} if this entity name is lexicographically greater than the entity name argument.
     *
     * @see     String#compareTo(String)
     */
    @Override
    default int compareTo(final EntityName o) {
        return getName().compareTo(o.getName());
    }

    /**
     * Returns string components of this entity name.
     */
    List<String> getComponents();

    /**
     * Returns name of the entity without any name space and components.
     */
    String getEntity();

    /**
     * Returns full string representation of this entity name.
     */
    String getName();

    /**
     * Returns name space for this entity name.
     */
    String getNamespace();

    /**
     * Returns human-readable string representation of this {@link EntityName}.
     * <p>
     * This string is not only a human-readable string, it also can be used as full entity name string to constructor
     * {@link #EntityName(String)} of the entity name class.
     */
    @Override
    String toString();

}