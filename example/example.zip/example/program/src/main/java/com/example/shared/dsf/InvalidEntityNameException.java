package com.example.shared.dsf;

/**
 * The {@code InvalidEntityNameException} class is an entity exception 
 * that thrown when user trying to create entity name with invalid arguments.
 *
 * @author  Andrey Ochirov
 * @version 1.0
 * 
 * @see     EntityName
 */
public class InvalidEntityNameException extends EntityException {

    private static final long serialVersionUID = 2183447827629713151L;

    /**
     * Constructs a new invalid entity name exception with the specified 
     * message key and parameters. The cause is not initialized, and may 
     * subsequently be initialized by a call to {@link #initCause(Throwable)}.
     * 
     * @param   key the message key.
     * @param   params the message parameters.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public InvalidEntityNameException(String key, Object[] params) {
        super(key, params, null);
    }

    /**
     * Constructs a new invalid entity name exception with the specified 
     * message key, parameters and cause.
     * <p>
     * Note that the detail message associated with {@code cause} is
     * <i>not</i> automatically incorporated in this invalid entity name 
     * exception's detail message.
     *
     * @param   key the message key.
     * @param   params the message parameters.
     * @param   cause the exception cause. The exception cause is saved for
     *          later retrieval by the {@link Throwable#getCause()} method). A 
     *          {@code null} value is permitted, and indicates that the 
     *          cause is nonexistent or unknown.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public InvalidEntityNameException(String key, Object[] params, 
            Throwable cause) {
        super(key, params, cause);
    }

}
