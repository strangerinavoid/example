package com.example.shared.dsf;

import java.lang.reflect.Method;

public record AbstractAttribute<T>(Method getter, Method setter) implements Attribute<T> {

	
	
	@Override
	public T get() throws AttributeAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<?> type() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void set(T value) {
		// TODO Auto-generated method stub
		
	}

}
