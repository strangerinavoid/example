package com.example.shared.dsf;

import java.io.Closeable;

/**
 * The {@code EntityServiceLocator} interface is a definition of the locator to {@link EntityService}.
 * <p>
 * Implementations of the {@code EntityServiceLocator} used to provide access to implementations of the
 * {@code EntityService} through different protocols and API.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityService
 * @see     EntityServiceManager
 */
public interface EntityServiceLocator extends Closeable {

    /**
     * Returns an instance of the {@link EntityService}. In case when specified entity class is invalid, method throws
     * {@link EntityServiceLookupException}.
     *
     * @param   entityClass the entity interface class of the {@link EntityService}.
     * @return  an instance of the {@link EntityService}.
     * @throws  NullPointerException in case of {@code null} entity class.
     * @throws  EntityServiceLookupException in case of invalid entity class or absent {@link EntityService}.
     */
    <S extends EntityService<E>, E extends Entity<E>> S lookup(Class<E> entityClass)
            throws EntityServiceLookupException;

    /**
     * Returns an instance of the {@link EntityService}. In case when specified name invalid name, method throws
     * {@link EntityServiceLookupException}.
     *
     * @param   name the full name of the {@link EntityService}.
     * @return  an instance of the {@link EntityService}.
     * @throws  NullPointerException in case of {@code null} entity name.
     * @throws  EntityServiceLookupException in case of invalid name or absent {@link EntityService}.
     */
    <S extends EntityService<E>, E extends Entity<E>> S lookup(EntityName name) throws EntityServiceLookupException;

}