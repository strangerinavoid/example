package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import static com.example.shared.dsf.annotation.ServiceType.NONE;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import com.example.shared.dsf.Entity;
import com.example.shared.dsf.EntityService;

/**
 * The {@code Service} annotation is a marker that used to specify meta information about {@link EntityService}
 * implementation. Such information used to use correct {@link Entity} implementation and entity wrapping method (see
 * {@link SessionType}).
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityService
 */
@Target({TYPE})
@Retention(RUNTIME)
public @interface Service {

    /**
     * The class that implements an entity interface.
     */
    Class<?> entity();

    /**
     * The optional list of interfaces that can be used as filter of interfaces that must be included or excluded from
     * entity proxy object. By default is empty and not used.
     */
    Class<?>[] interfaces() default {};

    /**
     * The type of the entity instances creation. This is optional value and by default means that all implemented
     * interfaces will be represented by entity proxy object.
     *
     * @see     SessionType
     */
    ServiceType type() default NONE;

}