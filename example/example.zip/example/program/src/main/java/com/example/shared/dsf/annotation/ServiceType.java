package com.example.shared.dsf.annotation;

import com.example.shared.dsf.Entity;

/**
 * The {@code ServiceType} enumeration specifies {@link Entity} wrapping types. The next types are available:<br/>
 * <pre>
 * ALL     - entity service implementation creates proxy object for any corresponding entity instance with all
 *           interfaces that implemented by entity implementation;
 * EXCLUDE - entity service implementation creates proxy object for any corresponding entity instance with all
 *           interfaces that implemented by entity implementation exclude interfaces that specified in the annotation
 *           {@link Service#interfaces()} for entity service implementation;
 * INCLUDE - entity service implementation creates proxy object for any corresponding entity instance with only such
 *           interfaces that specified in the annotation {@link Service#interfaces()} for entity service implementation;
 * STRICT  - entity service implementation creates proxy object for any corresponding entity instance with only
 *           corresponding entity interface;
 * NONE    - entity service does not creates any proxy object and returns real entity implementation as is. This means
 *           that entity implementation must implements all contracts that declared for any entity implementation.</pre>
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Service
 */
public enum ServiceType {

    /**
     * Entity service implementation creates proxy object for any corresponding entity instance with all interfaces
     * that implemented by entity implementation.
     */
    ALL(0, "All"),

    /**
     * Entity service implementation creates proxy object for any corresponding entity instance with all interfaces
     * that implemented by entity implementation exclude interfaces that specified in the annotation
     * {@link Service#interfaces()} for entity service implementation.
     */
    EXCLUDE(1, "Exclusive"),

    /**
     * Entity service implementation creates proxy object for any corresponding entity instance with only such
     * interfaces that specified in the annotation {@link Service#interfaces()} for entity service implementation.
     */
    INCLUDE(2, "Inclusive"),

    /**
     * Entity service implementation creates proxy object for any corresponding entity instance with only corresponding
     * entity interface.
     */
    STRICT(3, "Strict"),

    /**
     * Entity service does not creates any proxy object and returns real entity implementation as is. This means that
     * entity implementation must implements all contracts that declared for any entity implementation.
     */
    NONE(4, "None");

    /**
     * Returns an instance of the {@code ServiceType} by specified digital code.
     *
     * @param   code a code of the instance of {@code ServiceType}.
     * @return  an instance of {@code ServiceType} if specified code is valid; otherwise throws
     *          {@link IllegalArgumentException}.
     */
    public static ServiceType valueOf(final Integer code) {
        for (final ServiceType type : ServiceType.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        // bad value
        throw new IllegalArgumentException("Invalid value \""
            + code
            + "\" was specified as service type.");
    }

    /**
     * The digital code of this enumeration value.
     */
    private final Integer code;

    /**
     * The type for this enumeration value.
     */
    private final String type;

    /**
     * Creates an instance of class {@code ServiceType}.
     */
    ServiceType(final Integer code, final String type) {
        this.code = code;
        this.type = type;
    }

    /**
     * Returns digital code for this enumeration value.
     */
    public Integer code() {
        return this.code;
    }

    /**
     * Returns a human-readable string representation of this enumeration value.
     */
    @Override
    public String toString() {
        return this.type;
    }

    /**
     * Returns name for this enumeration value in the localizer.
     */
    public String type() {
        return this.type;
    }

}