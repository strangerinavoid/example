package com.example.program.example;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.shared.boot.BootEntry;

@SpringBootApplication
public class ExampleEntry implements BootEntry {

	private final AtomicBoolean closed = new AtomicBoolean();

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getExitCode() {
		return 0;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Closeable run(final String... args) {
        return () -> {
            try (final var context = SpringApplication.run(getClass(), args)) {
                while (context.isActive()) {
                    Thread.yield();
                }
            } finally {
                close();
            }
        };
	}

	/**
	 * Marks this entry as closed and returns confirmation result.
	 */
	protected boolean close() {
		return this.closed.compareAndSet(false, true);
	}

}