package com.example.shared.dsf;

import java.util.stream.Stream;

/**
 * The {@code EntityService} interface represents base entity service and every entity service interface must derive
 * from the following base service interface. The base Entity Service interface provides a common set of operations
 * shared by all the Entity Services. The implementation of the {@code EntityService} operations are mandatory.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Entity
 */
public interface EntityService<E extends Entity<E>> {

    /**
     * Creates entities in the persistence with given keys.
     *
     * @param   keys a keys for entities to be created.
     * @param   entities an entities to be created.
     */
    void createEntitiesByKeys(EntityKey<E>[] keys, E[] entities, String... attributes) throws EntityException;

    /**
     * Creates an entities with given values.
     *
     * @param   entities an entities to be created.
     * @return  an array of created entities. Never returns {@code null}.
     */
    E[] createEntitiesByValues(E[] entities, String... attributes) throws EntityException;

    /**
     * Creates an entity with given values.
     *
     * @param   entity an entity to be created.
     * @return  a created entity. Never returns {@code null}.
     */
    E createEntityByValue(E entity, String... attributes) throws EntityException;

    /**
     * The method finds all entities by finder with specified name registered in this entity service.
     *
     * @param   name the name of the {@link EntityFinder} that must be used to find entities.
     * @return  an entity iterator with all founded entities. Never returns {@code null}.
     *
     * @see     #findByQuery(String, EntityQuery)
     */
    Stream<E> find(String name) throws EntityException;

    /**
     * Returns entities which keys matches given in array (i. e. one entity per key if exists).
     *
     * @param   keys the keys of entities to get.
     * @param   attributes the names of entity attributes that must be populated by this entity service. The names of
     *          attributes can be specified for any attribute even if it attribute nested to entity through some other
     *          entity(ies), like in such case:
     *          <pre>get...(..., "type", "name.firstName", "name.lastName", "document.number", "user.name.fisrtName");</pre>
     *          <p>
     *          It must be clearly that entity service must anyway populate all entity keys for any of specified
     *          entities. If names of entity attributes wasn't specified the list of populated attributes depends on
     *          entity service implementation.
     *          <p>
     *          <strong>NOTE: The entity service implementation can ignore names of entity attributes.</strong>
     * @return  an entity iterator with keys matсh given. Never returns {@code null}.
     */
    Stream<E> getEntitiesByKeys(EntityKey<E>[] keys, String... attributes) throws EntityException;

    /**
     * Retrieves all entities which conforms given template (i.e. fields are equivalent).
     *
     * @param   template the template entity.
     * @param   attributes the names of entity attributes that must be populated by this entity service. The names of
     *          attributes can be specified for any attribute even if it attribute nested to entity through some other
     *          entity(ies), like in such case:
     *          <pre>get...(..., "type", "name.firstName", "name.lastName", "document.number", "user.name.fisrtName");</pre>
     *          <p>
     *          It must be clearly that entity service must anyway populate all entity keys for any of specified
     *          entities. If names of entity attributes wasn't specified the list of populated attributes depends on
     *          entity service implementation.
     *          <p>
     *          <strong>NOTE: The entity service implementation can ignore names of entity attributes.</strong>
     * @return  an entity iterator of matches entities. Never returns {@code null}.
     */
    Stream<E> getEntitiesByTemplate(E template, String... attributes) throws EntityException;

    /**
     * Returns an entity which key matches given.
     *
     * @param   key the key of required entity.
     * @param   attributes the names of entity attributes that must be populated by this entity service. The names of
     *          attributes can be specified for any attribute even if it attribute nested to entity through some other
     *          entity(ies), like in such case:
     *          <pre>get...(..., "type", "name.firstName", "name.lastName",
     *          "document.number", "user.name.fisrtName");</pre>
     *          <p>
     *          It must be clearly that entity service must anyway populate all entity keys for any of specified
     *          entities. If names of entity attributes wasn't specified the list of populated attributes depends on
     *          entity service implementation.
     *          <p>
     *          <strong>NOTE: The entity service implementation can ignore names of entity attributes.</strong>
     * @return  an entity if any; otherwise method returns {@code null}.
     */
    E getEntityByKey(EntityKey<E> key, String... attributes) throws EntityException;

    /**
     * Returns entity implementation class supported by this entity service that specified by {link {@link Service}
     * annotation.
     */
    Class<E> getEntityClass();

    /**
     * Returns entity interface supported by this entity service. Never returns {@code null}.
     */
    Class<?> getEntityInterface();

    /**
     * Returns entity name that unambiguously points to this service and all entities that produced by this entity
     * service.
     */
    EntityName getEntityName();

    /**
     * Returns an instance of the entity service implementation.
     */
    EntityService<E> getEntityServiceReference();

    /**
     * Returns entity type supported by this entity service. Never returns {@code null}.
     */
    String getEntityType();

    /**
     * Manufacture an empty entity of corresponding type.
     *
     * @return  entity of corresponding type. Never return {@code null}.
     */
    E makeEntity();

    /**
     * Manufacture an empty entity of corresponding type with only initialized entity key and corresponding entity key
     * attributes.
     *
     * @return  entity of corresponding type. Never return {@code null}.
     */
    E makeEntityByEntityKey(EntityKey<E> key);

    /**
     * Manufacture an empty entity of corresponding type with only initialized entity key and corresponding entity key
     * attributes by specified entity key object representation.
     *
     * @return  entity of corresponding type. Never return {@code null}.
     */
    E makeEntityByEntityKeyObject(Object obj);

    /**
     * Manufacture a key for entity.
     *
     * @return  a newly created empty key of the appropriate type.
     */
    EntityKey<E> makeEntityKey();

    /**
     * Manufacture a key for entity from specified object. By default this is a serialized state of the key.
     *
     * @return  a newly created entity key of the appropriate type.
     */
    EntityKey<E> makeEntityKeyByObject(Object obj);

    /**
     * Manufacture an entity of corresponding type with default values.
     *
     * @return  entity of corresponding type. Never return {@code null}.
     */
    E makeEntityWithDefaults();

    /**
     * Removes entities with given keys.
     *
     * @param   keys an entity keys to remove.
     */
    void removeEntitiesByKeys(EntityKey<E>[] keys) throws EntityException;

    /**
     * Removes entity matches the key.
     *
     * @param   key the key of the entity to remove.
     */
    void removeEntityByKey(EntityKey<E> key) throws EntityException;

    /**
     * Update entities with given keys with values from entities.
     *
     * @param   keys an entity keys to update.
     * @param   entities a new entities to update.
     */
    void setEntitiesByKeys(EntityKey<E>[] keys, E[] entities, String... attributes) throws EntityException;

    /**
     * Update specified entities in storage.
     *
     * @param   entities an entities to update.
     * @return  an array of modified entities. Never returns {@code null}.
     */
    E[] setEntitiesByValues(E[] entities, String... attributes) throws EntityException;

    /**
     * Update specified entity in storage.
     *
     * @param   entity an entity to update.
     * @return  a modified entity. Never returns {@code null}.
     */
    E setEntityByValue(E entity, String... attributes) throws EntityException;

}