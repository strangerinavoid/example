package com.example.shared.dsf;

import java.util.concurrent.atomic.AtomicBoolean;

import com.example.shared.logging.LogAware;

/**
 * The {@code AbstractEntityServiceLocator} class is a base class for all {@code entity service locators} and provide
 * some default logic for managing locators.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public abstract class AbstractEntityServiceLocator implements EntityServiceLocator, LogAware {

    private final AtomicBoolean closed = new AtomicBoolean();

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() {
        if (this.closed.compareAndSet(false, true)) {
            onClose();
        }
    }

    /**
     *
     */
    protected void checkForClosed() {
        if (this.closed.compareAndSet(false, false)) {
            return;
        }
        throw new EntityServiceLookupException("Unable to lookup for an entity service using closed service locator");
    }

    /**
     *
     */
    protected abstract void onClose();

}