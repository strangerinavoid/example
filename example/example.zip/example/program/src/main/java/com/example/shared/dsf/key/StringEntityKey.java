package com.example.shared.dsf.key;

import com.example.shared.core.type.Type;
import com.example.shared.dsf.AbstractEntityKey;
import com.example.shared.dsf.Entity;

/**
 * The {@code StringEntityKey} class is a single value entity key that used {@link String} value in key.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     AbstractEntityKey
 */
public final class StringEntityKey<E extends Entity<E>> extends AbstractEntityKey<String, StringEntityKey<E>, E> {

    /**
     * Creates an instance of class {@code StringEntityKey}.
     */
    public StringEntityKey(final E entity, final String componentName) {
        super(entity, componentName, Type.of(String.class)); // the type cannot be null
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String convert(final String key) {
        return key; // a special case where no need to convert string to string
    }

}