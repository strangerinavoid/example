package com.example.shared.dsf;

import static java.lang.String.valueOf;
import static java.util.Objects.hash;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElse;
import static java.util.Optional.ofNullable;
import static java.util.stream.Stream.of;

import static com.example.shared.core.type.Type.asType;
import static com.example.shared.utils.Objects.classOf;
import static com.example.shared.utils.Strings.EMPTY_STRING;
import static com.example.shared.utils.Strings.trim;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

import com.example.shared.core.type.Type;

/**
 * The {@code AbstractEntityKey} class is a base class for single implementations of the {@link EntityKey} interface.
 * It implements common methods and helps to final implementations.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public abstract class AbstractEntityKey<V extends Comparable<V>, T extends AbstractEntityKey<V, T, E>,
        E extends Entity<E>> implements EntityKey<E> {

    /**
     * The component name.
     */
    private final String component;

    /**
     * An entity that bounded to this key.
     */
    private final E entity;

    /**
     * A string representation of the key. Such representation needed for valid key transmission.
     */
    private final AtomicReference<String> key;

    /**
     * The key type.
     */
    private final Type<V> type;

    /**
     * The key value.
     */
    private final AtomicReference<V> value;

    /**
     * Creates an instance of class {@code AbstractEntityKey}.
     */
    protected AbstractEntityKey(final E entity, final String component, final Type<V> type) {
        this.entity = entity; // can be null (unattached key)
        this.component = requireNonNull(trim(component), "Unable to use null component name");
        this.key = new AtomicReference<>(EMPTY_STRING);
        this.type = requireNonNull(type, "Unable to use null type");
        this.value = new AtomicReference<>();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        this.value.updateAndGet(v -> {
            if (nonNull(this.entity)) {
                this.entity.unpopulateAttribute(this.component);
            }

            this.key.set(EMPTY_STRING);
            return null;
        });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(final EntityKey<E> o) {
        if (this == o) {
            return 0;
        }

        if (requireNonNull(o, "Unable to compare entity key with null value") instanceof
                final AbstractEntityKey<?, ?, ?> k && getClass() == k.getClass()
                    && this.component.equals(k.component)) {
            final V thisValue = this.value.get();
            final V otherValue = asType(k.value.get());

            if (null == thisValue && null == otherValue || Objects.equals(thisValue, otherValue)) {
                return 0;
            }
            if (null == thisValue) {
                return -1;
            }
            if (null == otherValue) {
                return 1;
            }
            return thisValue.compareTo(otherValue);
        }
        // cannot compare two keys and due this reason throwing corresponding exception
        throw new IncomparableKeyException(this, o);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object o) {
        return this == o || o instanceof final AbstractEntityKey<?, ?, ?> k && getClass() == o.getClass()
            && Objects.equals(this.component, k.component)
            && Objects.equals(this.key.get(), k.key.get())
            && Objects.equals(classOf(this.entity), classOf(k.entity));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <C> C getComponent(final String name) {
        if (this.component.equals(name)) {
            return asType(this.value.get());
        }
        throw new UnsupportedEntityKeyComponentException(name, this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<String> getComponentNames() {
        return Set.of(this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<Optional<Object>> getComponents(final String... names) {
        if (nonNull(names) && (0 == names.length || of(names).anyMatch(this.component::equals))) {
            return Set.of(ofNullable(this.value.get()));
        }
        throw new UnsupportedEntityKeyComponentException(Arrays.toString(names), this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getKey() {
        return this.key.get();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasComponent(final String name) {
        return this.component.equals(name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return hash(this.component, this.key.get());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isComplex() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return EMPTY_STRING.equals(this.key.get());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <C> C removeComponent(final String name) {
        if (this.component.equals(name)) {
            return asType(this.value.getAndUpdate(v -> {
                this.key.set(EMPTY_STRING);
                return null;
            }));
        }
        throw new UnsupportedEntityKeyComponentException(name, this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<Optional<Object>> removeComponents(final String... names) {
        if (nonNull(names) && (0 == names.length || of(names).anyMatch(this.component::equals))) {
            return Set.of(ofNullable(removeComponent(this.component)));
        }
        throw new UnsupportedEntityKeyComponentException(Arrays.toString(names), this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setComponent(final String name, final Object value) {
        if (this.component.equals(name)) {
            this.value.getAndUpdate(v -> {
                final V o = this.type.as(value);

                if (nonNull(this.entity)) {
                    this.entity.setAttributeValue(name, o);
                }
                // because this is a simple type like number or string here no problem with to string transformation
                this.key.set(valueOf(requireNonNullElse(o, EMPTY_STRING)));
                return o;
            });
            return;
        }
        throw new UnsupportedEntityKeyComponentException(name, this.component);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setKey(final String key) {
        this.value.getAndUpdate(v -> {
            if (nonNull(this.entity)) {
                this.entity.setAttributeValue(this.component, this.value.get());
            }
            return convert(this.key.updateAndGet(k -> key));
        });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return new StringBuilder("[")
            .append(this.component)
            .append("=")
            .append(this.value.get())
            .append("]")
            .toString();
    }

    /**
     * Converts string key value to key value with concrete type.
     *
     * @param   key the string value for this entity key.
     * @return  returns converted value with corresponding type.
     */
    protected abstract V convert(String key);

}