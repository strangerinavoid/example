package com.example.shared.dsf;

import static java.util.Objects.requireNonNull;

/**
 * The {@code UnsupportedAttributeException} class is an entity exception that thrown when user trying to operate with
 * unsupported attribute.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     AttributeAccessException
 */
public final class UnsupportedAttributeException extends AttributeAccessException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -370361559501923919L;

    /**
     * Constructs a new unsupported attribute exception with specified attribute name. The cause is not initialized,
     * and may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   name the name of entity attribute.
     * @throws  NullPointerException in case of {@code null} attribute name.
     */
    public UnsupportedAttributeException(final String name) {
        super("Attribute %s is not exists and cannot be accessed", requireNonNull(name));
    }

}