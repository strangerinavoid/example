package com.example.shared.dsf;

/**
 * The {@code EntityServiceLookupException} class is an entity exception that thrown in case of error when looking up
 * for an {@link EntitySession}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public class EntityServiceLookupException extends EntityException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = 8355513219104528794L;

    /**
     * Constructs a new entity session lookup exception with the specified message key and parameters. The cause is not
     * initialized, and may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   key the message key.
     * @param   arguments the message parameters.
     * @throws  NullPointerException in case of {@code null} message.
     */
    public EntityServiceLookupException(final String key, final Object... arguments) {
        super(key, arguments);
    }

    /**
     * Constructs a new entity session lookup exception with the specified message key, parameters and cause.
     * <p>
     * Note that the detail message associated with {@code cause} is <i>not</i> automatically incorporated in this
     * entity session lookup exception's detail message.
     *
     * @param   key the message key.
     * @param   arguments the message parameters.
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the
     *          {@link Throwable#getCause()} method). A {@code null} value is permitted, and indicates that the cause
     *          is nonexistent or unknown.
     * @throws  NullPointerException in case of {@code null} message.
     */
    public EntityServiceLookupException(final String key, final Throwable cause, final Object... arguments) {
        super(key, arguments, cause);
    }

}