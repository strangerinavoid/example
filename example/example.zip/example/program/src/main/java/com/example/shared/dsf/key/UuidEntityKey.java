package com.example.shared.dsf.key;

import java.util.UUID;

import com.example.shared.core.type.Type;
import com.example.shared.dsf.AbstractEntityKey;
import com.example.shared.dsf.Entity;

/**
 * The {@code UuidEntityKey} class is a single value entity key that used {@link UUID} value in key.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     AbstractEntityKey
 */
public final class UuidEntityKey<E extends Entity<E>> extends AbstractEntityKey<UUID, UuidEntityKey<E>, E> {

    /**
     * The type that used to convert {@link String} values to a {@link UUID} values.
     */
    private static final Type<UUID> TYPE = Type.of(UUID.class);

    /**
     * Creates an instance of class {@code UuidEntityKey}.
     */
    public UuidEntityKey(final E entity, final String componentName) {
        super(entity, componentName, TYPE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected UUID convert(final String key) {
        return TYPE.as(key);
    }

}