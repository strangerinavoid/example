package com.example.shared.dsf;

/**
 * The {@code Entity} interface is the definition of the Entity, where Entity represents a business object from business
 * requirement for an application.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface Entity<E extends Entity<E>> extends AttributeAccessible {

    /**
     * Returns implementation class of this entity.
     * <p>
     * Never returns {@code null}.
     */
    Class<? extends E> getEntityClass();

    /**
     * Gets the key for this object. The key is unique over all objects. Method never returns {@code null}. For newly
     * created entities method will return empty key (see for details {@link EntityKey#isEmpty()}).
     *
     * @return  the key for this value object.
     *
     * @see     #setEntityKey(EntityKey)
     * @see     EntityKey
     */
    EntityKey<E> getEntityKey() throws AttributeAccessException;

    /**
     * Gets the name of this entity which can be used in the {@link EntityServiceManager} to find {@link EntitySession}
     * for this entity.
     *
     * @return  an entity name. Never returns {@code null}.
     *
     * @see     #setEntityName(EntityName)
     * @see     EntityName
     */
    EntityName getEntityName();

    /**
     * Sets a new key for this entity.
     * <p>
     * May be used when there is a need to search for an specific entity using this value as a template.
     *
     * @param   key the new value for the key.
     * @throws  AttributeAccessException when the given key is not of correct type. Typically, entity key instantiated
     *          by corresponding {@link EntitySession}.
     *
     * @see     #getEntityKey()
     * @see     EntityKey
     */
    void setEntityKey(EntityKey<E> key) throws AttributeAccessException;

}