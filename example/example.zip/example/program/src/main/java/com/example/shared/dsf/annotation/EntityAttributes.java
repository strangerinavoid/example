package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * The {@code EntityAttributes} annotation allows to set default value for entity attribute.
 * <pre>
 * public class ResourceEntityImpl {
 *     ...
 *
 *     &#64;EntityAttribute(valueType = ResourceTypeEntity.class, defaultValue = "1")
 *     public ResourceTypeEntity getType() {
 *         ...
 *     }
 *
 * }
 *
 * &#64;EntityAttributes({
 *    &#64;EntityAttribute(attributeName = "type", valueType = ResourceTypeEntity.class, defaultValue = "2"),
 *    &#64;EntityAttribute(attributeName = "name", defaultValue = "hub")
 * })
 * public class HubEntity extends ResourceEntityImpl {
 *     ...
 *
 *     public String getName() {
 *         ...
 *     }
 *
 * }
 * </pre>
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityAttribute
 */
@Target({TYPE})
@Retention(RUNTIME)
public @interface EntityAttributes {

    /**
     * An array of {@link EntityAttribute} annotations if such annotations should be applied to the class in more than
     * one annotation.
     */
    public EntityAttribute[] value() default {};

}