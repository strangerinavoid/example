package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.METHOD;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@code Indirect} annotation is a marker that used to specify attribute of the {@link Entity} that points on
 * another {@link Entity} and requires property initialization through indirect call. In other words such attribute
 * will be populated in case when accessing it transparently for application code.
 * <p>
 * The handler of {@code Indirect} annotation will work with only annotated attribute of {@link Entity} type. Also
 * annotated attribute must be populated and contain entity with only populated entity key. Otherwise this annotation
 * will be ignored.
 * <p>
 * Only applicable to interfaces that extended from {@link Entity}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Target({METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Indirect {

    /**
     * Alternate entity type. Used to replace attribute type in case when another type needed.
     * <p>
     * See example below:
     * <p>
     * <pre>
     *    &#064;Indirect(PassportEntity.class)
     *    private DocumentEntity document;
     * </pre>
     */
    Class<?> entity() default Entity.class;

}