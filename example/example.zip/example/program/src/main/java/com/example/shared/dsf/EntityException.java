package com.example.shared.dsf;

import java.util.Locale;

import com.example.shared.error.ServerException;

/**
 * The {@code EntityException} class is a common exception class for all exceptions assigned with entities.
 *
 * @author  Andrey Ochirov
 * @version 1.0
 */
public class EntityException extends ServerException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -5405243067810768799L;

    /**
     * Constructs a new entity exception with the specified detail message. The cause is not initialized, and may
     * subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   message the detail localizable message. The detail message is saved for later retrieval by the
     *          {@link #getMessage(Locale)}, {@link Throwable#getMessage()} or {@link Throwable#getLocalizedMessage()}
     *          methods with default locale. Also localized message can be generated in the methods
     *          {@link #toString(Locale)} and {@link #toString()} with default locale.
     * @throws  NullPointerException in case of {@code null} message.
     */
    public EntityException(final String message, final Object... arguments) {
        super(message, arguments);
    }

    /**
     * Constructs a new entity exception with specified detail localizable message and cause.
     * <p>
     * Note that the detail message associated with {@code cause} is <i>not</i> automatically
     * incorporated in this entity exception's detail message.
     *
     * @param   message the detail localizable message. The detail message is saved for later
     *          retrieval by the {@link #getMessage(Locale)}, {@link Throwable#getMessage()} or
     *          {@link Throwable#getLocalizedMessage()} methods with default locale. Also localized
     *          message can be generated in the methods {@link #toString(Locale)} and
     *          {@link #toString()} with default locale.
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the
     *          {@link Throwable#getCause()} method). A {@code null} value is permitted, and
     *          indicates that the cause is nonexistent or unknown.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public EntityException(final String message, final Throwable cause, final Object... arguments) {
        super(message, cause, arguments);
    }

}