package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * The {@code Entity} annotation is a marker that used to specify non-entity interface as {@link Entity} compatible to
 * include all attributes from such interface as entity attributes.
 * <p>
 * This annotation can be applied to entity implementation class or to any interface that implemented by entity
 * implementation class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Target({TYPE})
@Retention(RUNTIME)
public @interface Entity {}