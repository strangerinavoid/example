package com.example.shared.dsf;

import java.util.Collection;
import java.util.Optional;

/**
 * The {@code EntityKey} interface represents a unique identifier of the {@link Entity}. It specifies multicomponent
 * key for the {@link Entity} and can hold one or more properties that uniquely identifying the {@link Entity}.
 * <p>
 * A count of components of the key affects on key's complexity. If key has more than one component such key is complex
 * ({@link #isComplex()}). A set of components for a key must be specified once and in the key creation time. This
 * means that structure of the key cannot be changed during runtime and must be a part of entity structure. In other
 * words a set of key's components must be specified in the entity's design time.
 * <p>
 * The {@code EntityKey} provides ability to work with key's components. But implementation must guarantee that set of
 * key's components cannot be changed during runtime. So such methods {@link #removeComponent(String)} cannot remove
 * specified key's component, it only clears value from component. This means that addressing to unspecified key's
 * component will prevent to {@link IllegalArgumentException}. To avoid this should be used {@link #getComponentNames()}
 * method.
 * <p>
 * The {@code EntityKey} gives a two work modes - work with packed value of key and work with key's components. It is
 * necessary to know, that every implementation should synchronize packed value of key with its unpacked part -
 * components. When with packed key happens changes, it must unpacks into components. Also, if changes happens with
 * components - they should be packed into the key. So, packed and unpacked parts of {@code EntityKey} are two sides of
 * one thing for every time.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Entity
 */
public interface EntityKey<E extends Entity<E>> extends Comparable<EntityKey<E>> {

    /**
     * Clears key to empty state, when no any key components can't be found.
     * <p>
     * This method not affect to {@link #getComponentNames()} method. It only clear values from this key.
     */
    void clear();

    /**
     * Gets the value of specified key's components.
     *
     * @param   name the name of key's component.
     * @return  the value of key's component.
     * @throws  IllegalArgumentException in case of component name not supported by this key.
     *
     * @see     #setComponent(String, Object)
     */
    <C> C getComponent(String name);

    /**
     * Gets the names of key's components.
     *
     * @return the array of key's components. Never returns {@code null}.
     */
    Collection<String> getComponentNames();

    /**
     * Gets the values of specified key's components.
     *
     * @param   names the array of names of key's components.
     * @return  the array of values of key's components. Never returns {@code null}.
     * @throws  UnsupportedEntityKeyComponentException in case of one or more component names not supported by this key.
     */
    Collection<Optional<Object>> getComponents(String... names);

    /**
     * Returns packed version this key.
     *
     * @return  packed version of this key.
     *
     * @see     #setKey(String)
     */
    String getKey();

    /**
     * Tests if the specified name is a name of one of this key's components.
     *
     * @param   name a possible component name.
     * @return  {@code true} if and only if the specified string is a name of this key's component, as determined by
     *          the {@code equals} method; {@code false} otherwise.
     */
    boolean hasComponent(String name);

    /**
     * Tests this key on complexity.
     *
     * @return  the flag of key's complexity. If key has more than one component, method returns {@code true}, otherwise
     *          it returns {@code false}.
     */
    boolean isComplex();

    /**
     * Tests this key on emptiness.
     *
     * @return  the flag of key's emptiness. If key has no one component, method returns {@code true}, otherwise it
     *          returns {@code false}.
     */
    boolean isEmpty();

    /**
     * Removes from this key specified component.
     *
     * @param   name the name of key's component to remove.
     * @return  value of the component, that was removed from this key.
     * @throws  NullPointerException if {@code null} component name specified.
     * @throws  IllegalArgumentException in case of component name that not supported by this key.
     */
    <C> C removeComponent(String name);

    /**
     * Removes from this key specified components.
     *
     * @param   names the array of names of key's components to remove.
     * @return  the array of values of the components, that was removed from this key. Never returns {@code null}.
     * @throws  NullPointerException if {@code null} component name specified or one of specified names is {@code null}.
     * @throws  IllegalArgumentException in case of one or more component names not supported by
     *          this key.
     */
    Collection<Optional<Object>> removeComponents(String... names);

    /**
     * Sets a component of this key by specified {@code name} with specified {@code value}.
     * <p>
     * The value of key's component can be retrieved by calling the {@link #getComponent(String)} method.
     *
     * @param   name the name of key's component.
     * @param   value the key's component value.
     * @throws  NullPointerException if {@code null} component name specified.
     * @throws  IllegalArgumentException in case of component name that not supported by this key.
     *
     * @see     #getComponent(String)
     */
    void setComponent(String name, Object value);

    /**
     * Sets the packed value of key.
     *
     * @param   key the packed value of key.
     * @throws  IllegalArgumentException in case of invalid string representation of the key or if specified key
     *          contains one or more unsupported component names.
     *
     * @see     #setKey(String)
     */
    void setKey(String key);

    /**
     * Returns a human-readable string representation of this {@code EntityKey} object in the form of a set of
     * components, enclosed in braces and separated by the ASCII characters "{@code ,&nbsp;}" (comma and space). Each
     * component is rendered as the component name, an equals sign {@code =}, and the associated value, where the
     * {@code toString} method is used to convert the component name and component value to strings.
     * <p>
     * Overrides to {@link Object#toString()} method.
     *
     * @return  a human-readable string representation of this key.
     */
    @Override
    String toString();

}