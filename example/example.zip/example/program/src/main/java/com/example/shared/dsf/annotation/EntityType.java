package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.SOURCE;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * The {@code EntityType} annotation TODO write comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Retention(SOURCE)
@Target(TYPE)
public @interface EntityType {}