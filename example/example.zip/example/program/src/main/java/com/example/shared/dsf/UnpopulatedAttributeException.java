package com.example.shared.dsf;

import static java.util.Objects.requireNonNull;

/**
 * The {@code UnpopulatedAttributeException} class is an entity exception that thrown when user trying to operate with
 * unpopulated attribute.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     AttributeAccessException
 */
public final class UnpopulatedAttributeException extends AttributeAccessException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = 3741346895054497054L;

    /**
     * Constructs a new unpopulated attribute exception with specified attribute name. The cause is not initialized,
     * and may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   name the name of entity attribute.
     * @throws  NullPointerException in case of {@code null} attribute name.
     */
    public UnpopulatedAttributeException(final String name) {
        super("Attribute %s is unpopulated and cannot be accessed. Before accessing attribute you must ensure that it "
            + "is populated by \"isPopulated(String)\" method", requireNonNull(name));
    }

}