package com.example.shared.dsf.annotation;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * The {@code EntityAttribute} annotation allows to set default value for entity attribute
 * <pre>
 * public class ResourceEntityImpl {
 *     ...
 *
 *     @EntityAttribute(valueType = ResourceTypeEntity.class, defaultValue = "1")
 *     public ResourceTypeEntity getType() {
 *         ...
 *     }
 *
 * }
 *
 * @EntityAttribute(attributeName = "type", valueType = ResourceTypeEntity.class, defaultValue = "2")
 * public class HubEntity extends ResourceEntityImpl {
 *     ...
 *
 *     @EntityAttribute(defaultValue = "hub")
 *     public String getName() {
 *         ...
 *     }
 *
 * }
 * </pre>
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@Target({METHOD, TYPE})
@Retention(RUNTIME)
public @interface EntityAttribute {

    /**
     * Specifies name of the attribute when annotation applied to class.
     */
    String attributeName() default "";

    /**
     * Sets default value to the annotated attribute.
     */
    String defaultValue() default "";

    /**
     * Tells is annotated attribute should be populated or not. In other words, if set to {@code true} then annotated
     * attribute will be populated; otherwise not.
     */
    boolean populate() default true;

    /**
     * Specifies type for the attribute by class value.
     */
    Class<?> valueType() default void.class;

}