package com.example.shared.dsf;

import static com.example.shared.core.type.Type.asType;

import java.lang.reflect.Method;

import com.example.shared.core.type.Type;

/**
 * The {@code AttributeAccessor} class is a representation of attribute of the {@link AttributeAccessible}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
final class AttributeAccessor {

    /**
     * Returns attribute type in terms of {@code Java Language}.
     */
    static Class<?> detectType(final Method getter, final Method setter) {
        if (getter == null) {
            return setter == null ? null : setter.getParameterTypes()[0];
        }
        return getter.getReturnType();
    }

    /**
     * The attribute getter method. Can be {@code null}; in such case attribute will be a write only attribute.
     */
    private final Method getter;

    /**
     * The attribute name that defined in the {@link Entity} through declaration of {@code getter} and/or {@code setter}
     * methods. Cannot be {@code null}.
     */
    private final String name;

    /**
     * The attribute setter method. Can be {@code null}; in such case attribute will be a read only attribute.
     */
    private final Method setter;

    /**
     * The {@link Type} of this entity attribute.
     */
    private final Type<?> type;
    private final Class<?> typeClass;

    /**
     * Creates an instance of class {@code AttributeAccessor} with specified name and access methods. Name cannot be
     * {@code null}.
     */
    AttributeAccessor(final String name, final Method getter, final Method setter) {
        this.name = name;
        this.getter = getter;
        this.setter = setter;
        this.typeClass = detectType(getter, setter);
        this.type = Type.of(this.typeClass);
    }

    /**
     * Method returns an attribute value from specified instance of {@link Entity}.
     *
     * @param   entity an instance of the {@link Entity}.
     * @throws  AttributeAccessException in case of any error while accessing attribute value.
     *
     * @see     #set(Entity, Object)
     */
    public <T, E extends AttributeAccessible> T get(final E entity) throws AttributeAccessException {
        try {
            if (this.getter == null) {
                throw new AttributeAccessException("Unable to access the attribute '%s'", this.name);
            }
            return asType(this.getter.invoke(entity));
        } catch (final Exception e) {
            throw new AttributeAccessException(e.getMessage(), e);
        }
    }

    /**
     * Returns a getter method for this attribute of the {@link Entity}.
     */
    public Method getGetter() {
        return this.getter;
    }

    /**
     * Returns an attribute name of the {@link Entity}.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Returns a setter method for this attribute of the {@link Entity}.
     */
    public Method getSetter() {
        return this.setter;
    }

    /**
     * Returns attribute type in terms of {@code Java Language}.
     */
    public Class<?> getType() {
    	return this.typeClass;
    }

    /**
     * Method sets value to an attribute from specified instance of {@link Entity}.
     *
     * @param   entity an instance of the {@link Entity}.
     * @param   value a value to assign to attribute.
     * @throws  AttributeAccessException in case of any error while setting attribute value.
     *
     * @see     #get(Entity)
     */
    public <E extends AttributeAccessible> void set(final E entity, final Object value) {
        try {
            if (this.setter == null) {
                throw new AttributeAccessException("Unable to modify readonly attribute '%s'", this.name);
            }
            this.setter.invoke(entity, this.type == null ? value : this.type.as(value));
        } catch (final Exception e) {
            throw new AttributeAccessException(e.getMessage(), e);
        }
    }

    /**
     * Returns a human-readable string representation of this attribute of the {@link Entity}.
     */
    @Override
    public String toString() {
        return this.name
            + " of type "
            + getType().getSimpleName();
    }

}