package com.example.shared.dsf;

/**
 * The {@code InvalidEntityKeyException} class is an entity exception that thrown when user trying to create invalid
 * entity key (with empty or {@code null} entity key components).
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class InvalidEntityKeyException extends EntityException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -2851614386288629133L;

    /**
     * Constructs a new invalid entity key exception. The cause is not initialized, and may subsequently be initialized
     * by a call to {@link #initCause(Throwable)}.
     *
     * @throws  NullPointerException in case of {@code null} message.
     */
    public InvalidEntityKeyException() {
        super("Unable to create invalid entity key. An entity key requires at least one component name and cannot "
            + "contains null or empty values.");
    }

}