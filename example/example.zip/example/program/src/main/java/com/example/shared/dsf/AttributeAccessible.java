package com.example.shared.dsf;

import java.util.Map;
import java.util.stream.Stream;

/**
 * The {@code AttributeAccessible} is an interface that declares an attribute access through attribute name. In other
 * words a map-like attribute access to attributes of the implementation.
 * <p>
 * Every class that represents {@code AttributeAccessible} interface must provide several ways to access attributes:
 * <ul>
 * <li>Attributes can be accessed through standard JavaBeans get/set (is/set) methods.</li>
 * <li>Attributes can be accessed through the generic methods:
 * <ul>
 * <li>{@link #getAttributeValue(String)}</li>
 * <li>{@link #setAttributeValue(String, Object)}</li>
 * </ul>
 * </li>
 * </ul>
 * A client needs to know which attributes exist in order to provide correct attribute names. It can get this
 * information with a call to {@link #getAttributeNames()}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface AttributeAccessible {

    /**
     * Gets all populated attribute values. If no attributes are populated an empty {@link Map} is returned.
     *
     * @return  a map of all populated attributes ([name,value] pair). Never returns {@code null}.
     */
    Map<String, Object> getAllPopulatedAttributes();

    /**
     * Gets all attribute names, which are available in this value object.
     * <p>
     * The returned names may be used as arguments to the generic methods:
     * <ul>
     * <li>{@link #getAttributeValue(String)}</li>
     * <li>{@link #setAttributeValue(String, Object)}</li>
     * </ul>
     * <p>
     * This method may be used by generic clients to obtain information on the attributes. It does not say anything
     * about the state of an attribute, i.e. if it is populated or not.
     *
     * @return  an array containing all attribute names in no particular order. Never returns {@code null}.
     */
    String[] getAttributeNames();

    /**
     * Gets the value of the specified attribute.
     *
     * @param   attributeName the attribute's name.
     * @return  the attribute's value. Primitive types are wrapped in their respective classes. Never returns
     *          {@code null}.
     * @throws  AttributeAccessException in case when specified attribute name points on unavailable or unpopulated
     *          attribute.
     *
     * @see     #setAttributeValue(String, Object)
     */
    <E> E getAttributeValue(String attributeName);

    /**
     * Gets multiple attribute values given an array of attribute names.
     *
     * @param   attributeNames an array containing attribute names in no particular order.
     * @return  a map of specified attributes ([name,value] pair). This method returns map only if specified attributes
     *          are available and populated. If specified {@code null} or empty array method returns empty map. Never
     *          returns {@code null}.
     * @throws  AttributeAccessException in case when specified attribute names contains points on one or more
     *          unavailable or unpopulated attributes.
     *
     * @see     #setAttributeValues(Map)
     */
    Map<String, Object> getAttributeValues(String[] attributeNames);

    /**
     * Gets the names of all populated attributes.
     * <p>
     * Although an attribute is populated, it can be {@code null}.
     *
     * @return  names of all populated attributes. When no attributes are populated an <b>empty array</b> is returned.
     *          It is required to return a subset of the array returned by {@link #getAttributeNames()}. Never returns
     *          {@code null}.
     */
    String[] getPopulatedAttributeNames();

    /**
     * Tests if all attributes in this value object are populated.
     *
     * @return  {@code true}, if all attributes are populated, {@code false} otherwise.
     *
     * @see     #isPopulated(String attribute)
     */
    boolean isFullyPopulated();

    /**
     * Checks if a specific attribute is populated.
     *
     * @param   attributeName the name of the attribute which is to be checked for population.
     * @return  {@code true}, if this attribute is populated, {@code false} otherwise.
     *
     * @see     #isFullyPopulated()
     */
    boolean isPopulated(String attributeName);

    /**
     * Marks all the attributes as populated.
     *
     * @see     #populateAttribute(String)
     * @see     #unpopulateAllAttributes()
     */
    void populateAllAttributes();

    /**
     * Marks a single attribute as populated. After this call {@link #getAttributeValue(String)}
     * must return attribute value which by default is {@code null}.
     *
     * @param   attributeName the name of the attribute to be populated.
     *
     * @see     #populateAllAttributes()
     * @see     #unpopulateAttribute(String)
     */
    void populateAttribute(String attributeName);

    /**
     * Assign a new value to an attribute.
     *
     * @param   attributeName the attribute's name which shall be changed.
     * @param   value the attribute's new value. This can either be:
     *          <ul>
     *          <li>An object of the type associated with {@code attributeName}</li>
     *          <li>A wrapper object for a primitive type, e.g. an {@code Integer} wrapping an
     *          {@code int}</li>
     *          </ul>
     *
     * @see     #getAttributeValue(String)
     */
    void setAttributeValue(String attributeName, Object value);

    /**
     * Sets multiple attribute values.
     *
     * @param   attributeNamesAndValuePairs is a map which contains an attribute values with
     *          attribute name as a key.
     *
     * @see     #getAttributeValues(String[])
     */
    void setAttributeValues(Map<String, Object> attributeNamesAndValuePairs);

    /**
     *
     * @return
     */
    Stream<Attribute<?>> stream();

    /**
     * Reset all the attributes to unpopulated.
     *
     * @see     #populateAllAttributes()
     * @see     #unpopulateAttribute(String)
     */
    void unpopulateAllAttributes();

    /**
     * Marks a single attribute as unpopulated. After this call {@link #getAttributeValue(String)}
     * must raise the {@link AttributeAccessException}.
     * <p>
     * All unpopulated attributes must be nullified.
     *
     * @param   attributeName the name of the attribute to be unpopulated.
     *
     * @see     #populateAttribute(String)
     * @see     #unpopulateAllAttributes()
     */
    void unpopulateAttribute(String attributeName);

}