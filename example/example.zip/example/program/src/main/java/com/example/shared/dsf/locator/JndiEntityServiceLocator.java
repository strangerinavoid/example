package com.example.shared.dsf.locator;

import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.joining;

import static com.example.shared.core.type.Type.asType;

import java.util.concurrent.Callable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.example.shared.dsf.AbstractEntityServiceLocator;
import com.example.shared.dsf.Entity;
import com.example.shared.dsf.EntityException;
import com.example.shared.dsf.EntityName;
import com.example.shared.dsf.EntityService;
import com.example.shared.dsf.EntityServiceLookupException;

/**
 * The {@code JndiEntityServiceLocator} class is a JNDI locator that looking up for instances of {@link EntityService}
 * in the {@link Context}.
 * <p>
 * The {@code JndiEntityServiceLocator} class should be used in such applications that works as enterprise applications
 * with the access to local services through {@link Context}.
 * <p>
 * As class that gets connection to a local {@link Context}, {@code JndiEntityServiceLocator} does not requires
 * a connection attributes in it's configuration. A default connection configuration will be used in order to get a
 * {@link Context}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Context
 * @see     InitialContext
 */
public final class JndiEntityServiceLocator extends AbstractEntityServiceLocator {

    static Context newContext(final Callable<Context> action) {
        try {
            return action.call();
        } catch (final Exception e) {
            throw new EntityException("Unable to obtain Initial Context due an unexpected exception", e);
        }
    }

    private final Context context;

    /**
     * Creates an instance of class {@code JndiEntityServiceLocator}.
     */
    public JndiEntityServiceLocator() {
        this.context = newContext(InitialContext::new);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <S extends EntityService<E>, E extends Entity<E>> S lookup(final Class<E> entityClass)
            throws EntityServiceLookupException {
        checkForClosed();

        return lookupInContext(requireNonNull(entityClass, "Unable to use null entity class").getName());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <S extends EntityService<E>, E extends Entity<E>> S lookup(final EntityName name)
            throws EntityServiceLookupException {
        checkForClosed();

        return lookupInContext(requireNonNull(name, "Unable to use null entity name")
            .getComponents().stream().collect(joining(".")));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onClose() {
        // do nothing...
    }

    private <S extends EntityService<E>, E extends Entity<E>> S lookupInContext(final String name) {
        try {
            return asType(this.context.lookup(name));
        } catch (final NamingException e) {
            throw new EntityServiceLookupException("Failed to lookup for an entity service with the name `%s` due an "
                + "unexpected exception: %s", e, name, e.getMessage());
        }
    }

}