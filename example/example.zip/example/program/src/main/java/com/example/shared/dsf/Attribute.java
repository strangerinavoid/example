package com.example.shared.dsf;

/**
 * The {@code Attribute} class is a representation of attribute of the {@link Entity}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface Attribute<T> {

    /**
     * Method returns an attribute value from specified instance of {@link Entity}.
     *
     * @param   entity an instance of the {@link Entity}.
     *
     * @throws  AttributeAccessException in case of any error while accessing attribute value.
     *
     * @see     #set(Entity, Object)
     */
    T get() throws AttributeAccessException;

    /**
     * Returns an attribute name of the {@link Entity}.
     */
    String name();

    /**
     * Method sets value to an attribute from specified instance of {@link Entity}.
     *
     * @param   entity an instance of the {@link Entity}.
     * @param   value a value to assign to attribute.
     *
     * @throws  AttributeAccessException in case of any error while setting attribute value.
     *
     * @see     #get(Entity)
     */
    void set(T value);

    /**
     * Returns attribute type in terms of {@code Java Language}.
     */
    Class<?> type();

}