package com.example.shared.dsf;

import java.util.Optional;

/**
 * The {@code EntityServiceManager} interface defines a manager that responsible for accessing {@link EntityService}
 * and plays role as an single access point per application to internal and external services.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     EntityService
 */
public interface EntityServiceManager {

    /**
     * Gets an instance of the {@link EntityService}. In case when specified entity class is invalid, method throws
     * {@link EntityServiceLookupException}.
     *
     * @param   entityClass the entity interface class of the {@link EntityService}.
     * @return  an instance of the {@link EntityService}.
     * @throws  NullPointerException in case of {@code null} entity class.
     * @throws  EntityServiceLookupException in case of invalid entity class or missing {@link EntityService}.
     */
    <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(Class<E> entityClass)
        throws EntityServiceLookupException;

    /**
     * Gets an instance of the {@link EntityService}. In case when specified name invalid name, method throws
     * {@link EntityServiceLookupException}.
     *
     * @param   name the full name of the {@link EntityService}.
     * @return  an instance of the {@link EntityService}.
     * @throws  NullPointerException in case of {@code null} entity name.
     * @throws  EntityServiceLookupException in case of invalid name or a {@link EntityService}.
     */
    <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(EntityName name)
        throws EntityServiceLookupException;

    /**
     * Gets an instance of the {@link EntityService}. In case when specified name invalid name, method throws
     * {@link EntityServiceLookupException}.
     *
     * @param   name a string representation of the full name of the {@link EntityService}.
     * @return  an instance of the {@link EntityService}.
     * @throws  NullPointerException in case of {@code null} entity name.
     * @throws  EntityServiceLookupException in case of invalid name or missing {@link EntityService}.
     */
    <S extends EntityService<E>, E extends Entity<E>> Optional<S> lookup(String name)
        throws EntityServiceLookupException;

}