package com.example.shared.logging.internal.jdk;

import static java.lang.Byte.MAX_VALUE;
import static java.lang.System.Logger.Level.INFO;
import static java.util.regex.Pattern.compile;
import static java.util.stream.Collectors.joining;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.example.shared.core.property.Property;
import com.example.shared.logging.InternalLog;
import com.example.shared.logging.Logger;

/**
 * The {@code LoggerJdkStatic} is a miscellaneous class with {@code JDK} {@link System.Logger} and {@code JUL} specific
 * constants and static initialization method {@link #init()}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
final class LoggerJdkStatic {

    static final String LOG_FORMAT = "java.util.logging.SimpleFormatter.format";
    static final String LOG_FORMAT_ENV = "JDK_LOGGER_FORMAT";
    static final String LOG_FORMAT_DEFAULT_VALUE =
        "[%1$tF %1$tl:%1$tM:%1$tS.%1$tN] [%4$-7s] [%2$-80s] %5$s%6$s%n";
    static final Property LOG_FORMAT_PROPERTY = new Property(LOG_FORMAT, LOG_FORMAT_ENV);

    static final String LOG_SKIP_PACKAGES = "jdk.logger.skip.packages";
    static final String LOG_SKIP_PACKAGES_ENV = "JDK_LOGGER_SKIP_PACKAGES";
    static final String LOG_SKIP_PACKAGES_SEPARATOR = ",";
    static final String LOG_SKIP_PACKAGES_SPLIT_PATTERN = "[,]+";
    static final Predicate<String> LOG_SKIP_PACKAGES_MATCHER =
        compile("^[\\p{L}][\\p{L}0-9_]*(\\.[\\p{L}0-9_]+)+[0-9\\p{L}_]$").asMatchPredicate();
    static final Property LOG_SKIP_PACKAGES_PROPERTY = new Property(LOG_SKIP_PACKAGES, LOG_SKIP_PACKAGES_ENV);

    /**
     * A static initialization of the default java logging system. Setting up formatting and names of packages to
     * filter out from stack trace.
     * <p>
     * This method looks in to {@link System#getProperties()} and {@link System#getenv()} to find possible values. In
     * case when no parameters in system properties and system environment, this method will initialize logging system
     * with default values.
     */
    static void init() {
        final var logger = System.getLogger(LoggerJdkStatic.class.getName());
        final var packageName = Logger.class.getPackageName();

        try (final var log = InternalLog.of(m -> logger.log(INFO, m))) {
            final Consumer<IllegalArgumentException> logConsumer = e -> log.log("LOG: ALERT", e.getMessage());
            final var packagesToSkip = LOG_SKIP_PACKAGES_PROPERTY.getOrDefault(packageName, logConsumer);

            // check for the invalid values in order to secure internal logic from invalid values
            final var packageNames = Stream.of(packagesToSkip.split(LOG_SKIP_PACKAGES_SPLIT_PATTERN))
                .filter(LOG_SKIP_PACKAGES_MATCHER)
                .distinct()
                .collect(joining(LOG_SKIP_PACKAGES_SEPARATOR));
            final var packages = packageNames.isBlank() ? packageName : packageNames;

            LOG_SKIP_PACKAGES_PROPERTY.set(packages.contains(packageName)
                ? packages : packages + LOG_SKIP_PACKAGES_SEPARATOR + packageName);

            // assign default format for Java Util Logging (JUL)
            final var messageFormat = LOG_FORMAT_PROPERTY.getOrDefault(LOG_FORMAT_DEFAULT_VALUE, logConsumer);

            // again, check for the length of the argument (assume that under given property we can get harmful value
            // in order to hack our application (see https://cwe.mitre.org/data/definitions/20.html for details), but
            // here is a MAX VALUE for signed byte in Java
            if (messageFormat.length() > MAX_VALUE) {
                log.log("LOG: ALERT", "An invalid value has been specified as log record format. The given value will "
                    + "be ignored, since it has too many characters [%d].", messageFormat.length());

                LOG_FORMAT_PROPERTY.set(LOG_FORMAT_DEFAULT_VALUE);
            } else {
                LOG_FORMAT_PROPERTY.set(messageFormat);
            }
        }
    }

    /**
     * Constructor of the class {@code LoggerJdkStatic} was declared as private to prevent its instantiation.
     */
    private LoggerJdkStatic() {
        throw new UnsupportedOperationException("Unable to instantiate utility class");
    }

}