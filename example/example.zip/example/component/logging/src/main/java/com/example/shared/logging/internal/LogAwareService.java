package com.example.shared.logging.internal;

import static java.lang.System.Logger.Level.INFO;
import static java.nio.charset.StandardCharsets.UTF_8;

import static com.example.shared.core.Services.load;
import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_CONFIG;
import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_ENVIRONMENT_PARAM;
import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import java.io.InputStream;
import java.net.URL;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

import com.example.shared.core.ResourceScope;
import com.example.shared.core.property.Property;
import com.example.shared.logging.InternalLog;
import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerFactory;
import com.example.shared.logging.internal.jdk.LoggerFactoryJdk;

/**
 * The {@code LogAwareService} is a class with private container and factory for {@link Logger loggers}.
 * <p>
 * The class is used for smooth and fast selection of specific {@code logger} in the multithreaded environment.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class LogAwareService {

    /**
     * A property with names from System properties and environment. This property is used to lookup value for custom
     * logger factory class.
     */
    private static final Property LOG_CLASS_NAME_PROPERTY =
        new Property(LOG_FACTORY_NAME_PARAM, LOG_FACTORY_NAME_ENVIRONMENT_PARAM);

    /**
     * A log factory instance that should be used by the application to get instances of {@link Logger}.
     */
    private static final LoggerFactory LOG_FACTORY;

    static { // create and assign instance of the logger factory
        try (final var log = InternalLog.of(r -> logger(LogAwareService.class).log(INFO, r))) {
            LOG_FACTORY = getFactory(log, getFactoryName(log, lookupFactoryClassName(log)));
        }
    }

    /**
     * Returns an instance of {@link Logger} for the caller's use.
     *
     * @implSpec
     * Instances returned by this method route messages to loggers assigned to instances of {@link Logger}.
     *
     * @apiNote
     * This method may defer calling the dedicated method to create an actual logger supplied by the logging backend,
     * for instance, to allow loggers to be obtained during the application initialization time.
     *
     * @param   source the source class which name is used as a name of the logger.
     * @return  an instance of {@link Logger} that can be used by the calling class.
     * @throws  NullPointerException if {@code source} is {@code null}.
     * @throws  IllegalCallerException if there is no Java caller frame on the stack.
     */
    public static Logger logger(final Class<?> source) {
        return LOG_FACTORY.logger(source);
    }

    /**
     * Creates and returns an instance of the logger factory with specified name.
     *
     * @implNote
     * This method uses {@link ServiceFactory} as a factory for the logger factory and iterates over all available
     * logger factories in order to find the proper one.
     *
     * @param   log an instance of internal log (in-memory logging) to log actions and results.
     * @param   factoryClassName a name of the logger factory name.
     * @return  an instance of logger factory. In case of specified {@code null} or unknown logger factory class name,
     *          this method returns an instance of default logger factory - {@link LoggerFactoryJdk}.
     */
    private static LoggerFactory getFactory(final InternalLog log, final String factoryClassName) {
        log.log("LOG", "Looking for the logger factory with '%s' class name...", factoryClassName);

        try {
            return load(LoggerFactory.class, s -> ServiceLoader.load(s)::stream,
                    p -> p.type().getName().equals(factoryClassName), thrown -> logAlert(log, thrown))
                .orElseGet(LoggerFactoryJdk::new);
        } catch (final ServiceConfigurationError e) {
            logAlert(log, e);
        }
        log.log("LOG", "A logger factory with '%s' class name not found. A default factory class '%s' will be used.",
            factoryClassName, LoggerFactoryJdk.class.getName());

        return new LoggerFactoryJdk(); // default factory
    }

    /**
     * Gets a logger factory name based on the values in System properties and environment. If no logger factory name
     * specified in System properties and environment , a default logger factory name {@code factoryClassName} is
     * returned.
     *
     * @param   log an instance of internal log (in-memory logging) to log actions and results.
     * @param   defaultFactoryName a default logger factory name.
     * @return  a logger factory name.
     */
    private static String getFactoryName(final InternalLog log, final String defaultFactoryName) {
        // primary factory name can be specified via System properties or environment, while another way
        // to provide default factory name is to use 'META-INF/log' file with factory class name in the class path
        // also log invalid values and continue with default factory name
        return LOG_CLASS_NAME_PROPERTY.getOrDefault(defaultFactoryName, thrown -> logAlert(log, thrown));
    }

    /**
     * Logs in a proper way a specified {@link Throwable} in a given {@code log}.
     *
     * @param   log a logger to log given throwable.
     * @param   thrown a throwable to log.
     */
    private static void logAlert(final InternalLog log, final Throwable thrown) {
        log.log("LOG: ALERT", thrown.getMessage());
    }

    /**
     * Lookups for the logger factory name in the application's class path from 'META-INF/log' file and returns name of
     * the class.
     *
     * @param   log an instance of internal log (in-memory logging) to log actions and results.
     * @return  a name of the logger factory. If logger factory name cannot be obtained from the configuration, a name
     *          of default logger factory {@link LoggerFactoryJdk} will be returned.
     */
    private static String lookupFactoryClassName(final InternalLog log) {
        log.log("LOG", "Looking for the logger factory class name from the configuration resource [%s]...",
            LOG_FACTORY_CONFIG);

        return ResourceScope.of(LOG_FACTORY_CONFIG)
            .flatMap(s -> s.open(LOG_FACTORY_CONFIG))
            .map(u -> lookupFactoryClassNameInUrl(log, u))
            .orElse(LoggerFactoryJdk.class.getName());
    }

    /**
     * Loads a file with logger factory name and tries to read it.
     *
     * @param   log an instance of internal log (in-memory logging) to log actions and results.
     * @param   factoryClassUrl an {@link URL} to configuration file with logger factory name.
     * @return  a name of logger factory or {@code null} if configuration not found or URL is invalid.
     */
    private static String lookupFactoryClassNameInUrl(final InternalLog log, final InputStream in) {
        try (in) {
            final var factoryName = new String(in.readAllBytes(), UTF_8); // run a seconds attempt

            if (factoryName.isBlank()) {
                return null;
            }
            return factoryName;
        } catch (final Exception e) {
            log.log("LOG: ERROR", "An unexpected error occurred while trying to load a name of the default logger "
                + "factory from the configuration resource: %s", e.getMessage());
        }
        return null;
    }

    /**
     * Constructor of the class {@code LogAwareService} was declared as private to prevent its instantiation.
     */
    private LogAwareService() {
        throw new UnsupportedOperationException("Unable to instantiate service class");
    }

}