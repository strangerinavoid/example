package com.example.shared.logging;

import static java.util.Objects.requireNonNull;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@code AbstractLoggerFactory} class is an abstract implementation of the {@link LoggerFactory} interface that
 * provides a fast access cache for known loggers.
 *
 * @implNote
 * This implementation uses {@link ConcurrentHashMap} as a fast access cache to store known loggers.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public abstract class AbstractLoggerFactory implements LoggerFactory {

    /**
     * A shared cache of known loggers.
     */
    private static final Map<Class<?>, Logger> loggers = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     */
    @Override
    public Logger logger(final Class<?> source) {
        return loggers.computeIfAbsent(
            requireNonNull(source, "Unable to allocate logger for null source class"),
            this::newLogger);
    }

    /**
     * Creates a new instance of the logger for the given source class.
     *
     * @param   source the non-null class, which name is used as a name for the returned logger.
     * @return  an instance of the {@link Logger}.
     * @throws  IllegalCallerException if there is no Java caller frame on the stack.
     */
    protected abstract Logger newLogger(final Class<?> source);

}