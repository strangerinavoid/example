package com.example.shared.logging.internal.jdk;

import static java.lang.System.getLogger;

import com.example.shared.logging.AbstractLoggerFactory;
import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerFactory;

/**
 * The {@code LoggerFactoryJdk} class is a JDK {@link System.Logger} oriented {@link LoggerFactory logger factory}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class LoggerFactoryJdk extends AbstractLoggerFactory {

    /**
     * {@inheritDoc}
     */
    @Override
    protected Logger newLogger(final Class<?> source) {
        return new LoggerJdk(getLogger(source.getName()));
    }

}