import com.example.shared.logging.LoggerFactory;
import com.example.shared.logging.internal.jdk.LoggerFactoryJdk;

module example.shared.logging {

     exports com.example.shared.logging;
     exports com.example.shared.logging.internal.jdk to example.shared.core;

    requires example.shared.core;

    requires java.logging;

        uses LoggerFactory;

    provides LoggerFactory
        with LoggerFactoryJdk;

}