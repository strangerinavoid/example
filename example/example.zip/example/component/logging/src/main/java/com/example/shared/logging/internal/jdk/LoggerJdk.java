package com.example.shared.logging.internal.jdk;

import static java.lang.String.valueOf;
import static java.lang.System.Logger.Level.WARNING;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElse;

import java.lang.System.Logger.Level;
import java.util.IllegalFormatException;
import java.util.function.Supplier;

import com.example.shared.logging.Logger;

/**
 * The {@code LoggerJdk} is a default implementation of {@link Logger} interface. It is a wrapper around standard
 * {@link System.Logger} class and supports default message formatting by {@link String#format(String, Object...)}
 * function.
 * <p>
 * This interface lets program call logger's method with message template and arguments, like this:
 * <pre>info("Hello %s! Today is %tc.", "world", LocalDateTime.now());</pre>
 * or
 * <pre>error("Attention, %s! Exception '%s' occurred while reading news from '%s':%n", throwable,
 *     context.getSupport(), throwable.getMessage(), context.getSource());</pre>
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     java.lang.System.Logger
 * @see     java.lang.System.Logger.Level
 * @see     String#format(String, Object...)
 */
final class LoggerJdk implements Logger {

    static {
        LoggerJdkStatic.init();
    }

    /**
     * Formats a text message. All placeholders will be replaced with the given arguments.
     *
     * @param   logger a logger for error cases.
     * @param   message a text message with placeholders.
     * @param   arguments a replacements for placeholders.
     * @return  formatted text message.
     */
    static String format(final System.Logger logger, final String message, final Object[] arguments) {
        try {
            return String.format(requireNonNullElse(message, "%s"), resolve(arguments));
        } catch (final IllegalFormatException e) {
            logger.log(WARNING, () -> "Illegal message format '" + message + "'", e);
        }
        return message;
    }

    /**
     * Resolves a potential lazy argument.
     *
     * @param   argument {@link Supplier} or any other object.
     * @return  a generated value, if passed argument is a {@link Supplier}, otherwise the original passed object.
     */
    static Object resolve(final Object argument) {
        if (argument instanceof Supplier<?>) {
            return ((Supplier<?>) argument).get();
        }
        return argument;
    }

    /**
     * Resolves potential lazy arguments of an array.
     *
     * @param   arguments an array of {@link Supplier Suppliers} and other objects.
     * @return  a new array in which all {@link Supplier Suppliers} are resolved to its real object.
     */
    static Object[] resolve(final Object[] arguments) {
        if (null == arguments) {
            return arguments;
        }

        final var resolvedArguments = new Object[arguments.length];

        for (var i = 0; i < resolvedArguments.length; ++i) {
            resolvedArguments[i] = resolve(arguments[i]);
        }
        return resolvedArguments;
    }

    private final System.Logger logger;

    /**
     * Creates an instance of class {@code LoggerJdk} with specified instance of {@link Logger}.
     *
     * @param   logger an instance of the backend logger.
     */
    LoggerJdk(final System.Logger logger) {
        this.logger = logger;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isLoggable(final Level level) {
        return this.logger.isLoggable(level);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void log(final Level level, final Throwable thrown, final String message, final Object... arguments) {
        this.logger.log(level, () -> LoggerJdk.format(this.logger, message, arguments), thrown);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void log(final Level level, final Throwable thrown, final Supplier<?> messageSupplier) {
        if (isLoggable(level)) {
            this.logger.log(level, () ->
                valueOf(requireNonNull(messageSupplier, "Cannot log with null message supplier").get()),
                thrown);
        }
    }

}