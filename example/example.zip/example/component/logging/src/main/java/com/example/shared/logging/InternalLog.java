package com.example.shared.logging;

import static java.lang.String.format;
import static java.util.Objects.requireNonNull;

import java.util.Formatter;
import java.util.IllegalFormatException;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

/**
 * The {@code InternalLog} class is an in-memory aggregator of log records that is used by the logging service before
 * initializing any logging system (JUL, Log4j2, TinyLog, etc.).
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class InternalLog implements AutoCloseable {

    /**
     * A factory method that used to create an instance of {@link InternalLog} with specified log records consumer.
     *
     * @param   consumer a log record consumer that used to consume all accumulated log records, when instance of
     *          {@link InternalLog} will be closed.
     * @return  a new instance of {@link InternalLog}.
     * @throws  NullPointerException when specified log records consumer is {@code null}.
     */
    public static InternalLog of(final Consumer<String> consumer) {
        return new InternalLog(requireNonNull(consumer));
    }

    /**
     * The list of log records to log to the logger.
     */
    private final List<String> log;

    /**
     * The log records consumer.
     */
    private final Consumer<String> consumer;

    /**
     * Creates an instance of class @{code InternalLog}.
     *
     * @param   consumer a log record consumer that used to consume all accumulated log records, when instance of
     *          {@link InternalLog} will be closed.
     */
    private InternalLog(final Consumer<String> consumer) {
        this.log = new LinkedList<>();
        this.consumer = consumer;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() {
        // publish all messages and clean internal log
        for (final var message : this.log) {
            this.consumer.accept(message); // use direct call in order to get proper stack trace construction
        }
        this.log.clear();
    }

    /**
     * Creates a log record form parameterized message and puts it to the internal list of log records. This operation
     * is fully in-memory and does not performs any I/O operation.
     *
     * @param   tag the log record tag, like component name or functional name, i.e. 'LOG', 'INIT', etc.
     * @param   pattern a pattern string as described in {@link Formatter} documentation.
     * @param   arguments an arguments referenced by the format specifiers in the format string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The maximum number of arguments is
     *          limited by the maximum dimension of a Java array as defined by <cite>The Java&trade; Virtual Machine
     *          Specification</cite>.
     * @throws  IllegalFormatException If a pattern contains an illegal syntax, a format specifier that is incompatible
     *          with the given arguments, insufficient arguments given the format string, or other illegal conditions.
     *          For specification of all possible formatting errors, see the documentation of the formatter class.
     */
    public void log(final String tag, final String pattern, final Object... arguments) {
        this.log.add(format("%s: %s", tag, format(pattern, arguments)));
    }

}