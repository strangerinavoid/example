package com.example.shared.logging.internal.jdk;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/**
 * The {@code LoggerFactoryJdkTest} class is a unit test for the class {@link LoggerFactoryJdk}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LoggerFactoryJdkTest {

    @Test
    void testNewLogger() {
        final var factory = new LoggerFactoryJdk();
        final var logger = assertDoesNotThrow(() -> factory.logger(getClass()));

        assertNotNull(logger);
        assertEquals(LoggerJdk.class, logger.getClass());
    }

    @Test
    void testNewLoggerWithNull() {
        final var factory = new LoggerFactoryJdk();
        final var ex = assertThrows(NullPointerException.class, () -> factory.logger(null));

        assertEquals("Unable to allocate logger for null source class", ex.getMessage());
    }

}