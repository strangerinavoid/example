package com.example.shared.logging;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.lang.Math.min;

import java.lang.System.Logger.Level;
import java.util.Random;

/**
 * The {@code LoggerTestUtils} is a collection of utility test methods that used by unit tests.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface LoggerTestUtils {

    char[] ALPHABET = "ABCDEFGHJIKLMNOPQRSTUVWXYZabcdefghjiklmnopqrstuvwxyz0123456789 ".toCharArray();

    Random RANDOM = new Random();
    int MAX_RANDOM_STRING = 32;
    int MIN_RANDOM_STRING = 16;

    static int randomInt() {
        return abs(RANDOM.nextInt());
    }

    static int randomIntWithLimit(final int limit) {
        return randomInt() % limit;
    }

    static Level randomLevel() {
        return Level.values()[randomInt() % Level.values().length];
    }

    static String randomPattern(final int arguments) {
        return randomString()
            + ":"
            + " %s".repeat(arguments);
    }

    static String randomString() {
        final var size = max(min(randomInt(), MAX_RANDOM_STRING), MIN_RANDOM_STRING);
        final var chars = new char[size];

        for (var i = 0; i < size; i++) {
            final var pos = randomInt();

            chars[i] = ALPHABET[pos % ALPHABET.length];
        }
        return new String(chars);
    }

}