package com.example.shared.logging.mock;

import static java.util.List.copyOf;
import static java.util.Objects.requireNonNull;

import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The {@code LoggerMock} class is a mock implementation of the {@link System.Logger} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public class LoggerMock implements System.Logger {

    private static final AtomicInteger IDS = new AtomicInteger(0);

    private final int id;
    private final boolean loggable;
    private final List<String> records;
    private final AtomicReference<Throwable> thrownHolder;

    /**
     * Creates an instance of class @{code LoggerMock}.
     */
    public LoggerMock() {
        this(true);
    }

    /**
     * Creates an instance of class @{code LoggerMock}.
     */
    public LoggerMock(final boolean loggable) {
        this.id = IDS.incrementAndGet();
        this.loggable = loggable;
        this.records = new LinkedList<>();
        this.thrownHolder = new AtomicReference<>();
    }

    public int getId() {
        return this.id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return getClass().getName();
    }

    public List<String> getRecords() {
        return copyOf(this.records);
    }

    public Throwable getThrown() {
        return this.thrownHolder.get();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isLoggable(final Level level) {
        requireNonNull(level, "Cannot accept null level");
        return this.loggable;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void log(final Level level, final ResourceBundle bundle, final String format, final Object... params) {
        this.records.add(level + ": " + format);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void log(final Level level, final ResourceBundle bundle, final String msg, final Throwable thrown) {
        this.records.add(level + ": " + msg);
        this.thrownHolder.set(thrown);
    }

}