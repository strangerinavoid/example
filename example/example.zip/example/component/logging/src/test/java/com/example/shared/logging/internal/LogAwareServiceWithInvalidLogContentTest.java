package com.example.shared.logging.internal;

import static java.lang.Short.MAX_VALUE;
import static java.lang.System.getProperty;
import static java.nio.file.Files.write;
import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.WRITE;
import static java.util.Arrays.fill;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import java.nio.file.Path;

import org.junit.jupiter.api.Test;

/**
 * The {@code LogAwareServiceWithInvalidLogContentTest} class is a unit test for the class {@link LogAwareService}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogAwareServiceWithInvalidLogContentTest implements LogAwareServiceTestContract {

    @Test
    void testWithDefault() throws Exception {
        final byte b = 13;
        final var content = new byte[MAX_VALUE + 1];
        final var log = Path.of("target", "test-classes", "META-INF", "log");

        fill(content, b);
        write(log, content, CREATE, WRITE);

        assertNotNull(getLogger());
        assertEquals(null, getProperty(LOG_FACTORY_NAME_PARAM));
    }

}