package com.example.shared.logging.internal;

import static java.lang.System.getProperties;
import static java.lang.reflect.Modifier.isPrivate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The {@code LogAwareServiceTest} class is a unit test for the class {@link LogAwareService}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogAwareServiceTest {

    @BeforeEach
    void setup() {
        getProperties().remove(LOG_FACTORY_NAME_PARAM);
    }

    @Test
    void testConstructor() {
        final var constructors = LogAwareService.class.getDeclaredConstructors();

        assertEquals(1, constructors.length);

        for (final var c : constructors) {
            c.setAccessible(true);

            assertTrue(isPrivate(c.getModifiers()));

            final var ex = assertThrows(InvocationTargetException.class, () -> c.newInstance());

            assertNotNull(ex.getClass());
            assertEquals(UnsupportedOperationException.class, ex.getCause().getClass());
            assertEquals("Unable to instantiate service class", ex.getCause().getMessage());
        }
    }

}