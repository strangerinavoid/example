package com.example.shared.logging.internal.jdk;

import static java.lang.String.format;
import static java.time.LocalDateTime.now;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.example.shared.logging.LoggerTestUtils.randomInt;
import static com.example.shared.logging.LoggerTestUtils.randomIntWithLimit;
import static com.example.shared.logging.LoggerTestUtils.randomLevel;
import static com.example.shared.logging.LoggerTestUtils.randomPattern;
import static com.example.shared.logging.LoggerTestUtils.randomString;

import java.util.function.Supplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerTestUtils;
import com.example.shared.logging.mock.LoggerMock;

/**
 * The {@code LoggerJdkTest} class is a unit test for the class {@link LoggerJdk}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LoggerJdkTest {

    private Logger logg;
    private LoggerMock logger;

    @BeforeEach
    void setUp() {
        this.logger = new LoggerMock();
        this.logg = new LoggerJdk(this.logger);
    }

    @Test
    void testFormat() {
        testFormatWith("message %s %d", new Object[] {"one", (Supplier<Integer>)() -> 2, now()}, "message one 2");
    }

    @Test
    void testFormatWithArgumentsWithNullAndPlaceholder() {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, "message %s", new Object[] {null}));

        assertEquals("message null", value);
    }

    @Test
    void testFormatWithEmptyArgumentsAndPlaceholder() {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, "message %s", new Object[0]));

        assertEquals("message %s", value);
    }

    @Test
    void testFormatWithNullArguments() {
        testFormatWith("message", (Object[])null, "message");
    }

    @Test
    void testFormatWithNullArgumentsAndPlaceholder() {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, "message %s", (Object[])null));

        assertEquals("message null", value);
    }

    @Test
    void testFormatWithNullMessage() {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, null, (Object[])null));

        assertEquals("null", value);
    }

    @Test
    void testFormatWithNullMessageAndNonNullArguments() {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, null, new Object[] {"value", now()}));

        assertEquals("value", value);
    }

    @Test
    void testIsLoggable() {
        final var level = randomLevel();

        assertTrue(assertDoesNotThrow(() -> this.logg.isLoggable(level)));
    }

    @Test
    void testIsLoggableWithNull() {
        final var ex = assertThrows(NullPointerException.class, () -> this.logg.isLoggable(null));

        assertEquals("Cannot accept null level", ex.getMessage());
    }

    @Test
    void testLoggerJdk() {
        final var value = assertDoesNotThrow(() -> new LoggerJdk(null));

        assertNotNull(value);
    }

    @Test
    void testLogWithMessage() {
        final var level = randomLevel();
        final var message = randomString();

        assertDoesNotThrow(() -> this.logg.log(level, message));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + message + "]", log.toString());
    }

    @Test
    void testLogWithPatternAndArguments() {
        final var level = randomLevel();
        final var arguments = randomIntWithLimit(8);
        final var pattern = randomPattern(arguments);
        final var values = new Object[arguments];

        for (var i = 0; i < arguments; i++) {
            values[i] = randomInt();
        }

        assertDoesNotThrow(() -> this.logg.log(level, pattern, values));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + format(pattern, values) + "]", log.toString());
    }

    @Test
    void testLogWithPatternAndArgumentSuppliers() {
        final var level = randomLevel();
        final var arguments = randomIntWithLimit(8);
        final var pattern = randomPattern(arguments);
        final var suppliers = new Object[arguments];
        final var values = new Object[arguments];

        for (var i = 0; i < arguments; i++) {
            final var pos = i;

            values[pos] = randomInt();
            suppliers[pos] = (Supplier<?>)() -> values[pos];
        }

        assertDoesNotThrow(() -> this.logg.log(level, pattern, suppliers));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + format(pattern, values) + "]", log.toString());
    }

    @Test
    void testLogWithPatternAndInvalidArgumentSuppliers() {
        final var level = randomLevel();
        final var arguments = 1;
        final var pattern = "%t message";
        final var values = new Object[arguments];

        for (var i = 0; i < arguments; i++) {
            values[i] = (Supplier<?>)LoggerTestUtils::randomInt;
        }

        assertDoesNotThrow(() -> this.logg.log(level, pattern, values));

        final var log = this.logger.getRecords();

        assertEquals(2, log.size());
        assertEquals("[WARNING: Illegal message format '"
            + pattern
            + "', "
            + level
            + ": "
            + pattern
            + "]", log.toString());
    }

    @Test
    void testLogWithSupplier() {
        final var level = randomLevel();
        final var message = randomString();

        assertDoesNotThrow(() -> this.logg.log(level, () -> message));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + message + "]", log.toString());
    }

    @Test
    void testLogWithThrowable() {
        final var level = randomLevel();
        final var arguments = randomIntWithLimit(8);
        final var pattern = randomPattern(arguments);
        final var values = new Object[arguments];
        final var thrown = new Exception("dummy exception");

        for (var i = 0; i < arguments; i++) {
            values[i] = randomInt();
        }

        assertDoesNotThrow(() -> this.logg.log(level, thrown, pattern, values));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + format(pattern, values) + "]", log.toString());
        assertEquals(thrown, this.logger.getThrown());
    }

    @Test
    void testLogWithThrowableAndNullSupplier() {
        final var level = randomLevel();
        final var thrown = new Exception("dummy exception");
        final var ex = assertThrows(NullPointerException.class, () -> this.logg.log(level, thrown, null));

        assertEquals("Cannot log with null message supplier", ex.getMessage());
    }

    @Test
    void testLogWithThrowableAndSupplier() {
        final var level = randomLevel();
        final var message = randomString();
        final var thrown = new Exception("dummy exception");

        assertDoesNotThrow(() -> this.logg.log(level, thrown, () -> message));

        final var log = this.logger.getRecords();

        assertEquals(1, log.size());
        assertEquals("[" + level +": " + message + "]", log.toString());
        assertEquals(thrown, this.logger.getThrown());
    }

    @Test
    void testLogWithThrowableAndSupplierNotLoggable() {
        final var level = randomLevel();
        final var message = randomString();
        final var thrown = new Exception("dummy exception");

        this.logger = new LoggerMock(false);
        this.logg = new LoggerJdk(this.logger);

        assertDoesNotThrow(() -> this.logg.log(level, thrown, () -> message));

        final var log = this.logger.getRecords();

        assertEquals(0, log.size());
        assertNull(this.logger.getThrown());
    }

    private void testFormatWith(final String message, final Object[] arguments, final String expected) {
        final var lg = System.getLogger("test");
        final var value = assertDoesNotThrow(() -> LoggerJdk.format(lg, message, arguments));

        assertEquals(expected, value);
    }

}