package com.example.shared.logging;

import static java.lang.String.valueOf;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

import org.junit.jupiter.api.Test;

/**
 * The {@code InternalLogTest} class is a unit test for the internal class {@link InternalLog}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class InternalLogTest {

    @Test
    void testLog() {
        final var logger = mock(Logger.class);
        final List<String> log = new LinkedList<>();
        final var consumer = (Consumer<String>)logger::info;

        doAnswer(i -> {
            final var count = i.getArguments().length;

            if (0 < count) {
                final var o = i.getArgument(0);

                log.add(valueOf(o));
            }
            return logger;
        }).when(logger).info(anyString());

        try (var ilog = InternalLog.of(consumer)) {
            ilog.log("LOG", "Message");
            ilog.log("LOG", "Message with arguments: %s %d", "value", 42);
        }

        assertEquals(2, log.size());
        assertEquals("LOG: Message", log.get(0));
        assertEquals("LOG: Message with arguments: value 42", log.get(1));

        verify(logger, times(2)).info(anyString());
    }

    @Test
    void testOf() {
        assertNotNull(assertDoesNotThrow(() -> InternalLog.of(NullPointerException::new)));
    }

    @Test
    void testOfWithNull() {
        final var ex = assertThrows(NullPointerException.class, () -> InternalLog.of(null));

        assertNull(ex.getMessage());
    }

}