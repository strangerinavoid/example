package com.example.shared.logging.internal.jdk;

import static java.lang.System.getProperty;
import static java.lang.System.setProperty;
import static java.util.Arrays.fill;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static com.example.shared.logging.internal.jdk.LoggerJdkStatic.LOG_FORMAT;
import static com.example.shared.logging.internal.jdk.LoggerJdkStatic.LOG_FORMAT_DEFAULT_VALUE;
import static com.example.shared.logging.internal.jdk.LoggerJdkStatic.LOG_SKIP_PACKAGES;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

import com.example.shared.logging.Logger;

/**
 * The {@code LoggerJdkStaticTest} class is a unit test for the class {@link LoggerJdkStatic}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LoggerJdkStaticTest {

    @Test
    void testConstructor() {
        LoggerJdkStatic.init();

        final var constructors = LoggerJdkStatic.class.getDeclaredConstructors();

        assertEquals(1, constructors.length);

        for (final Constructor<?> c : constructors) {
            c.setAccessible(true);

            final var ex = assertThrows(InvocationTargetException.class, () -> c.newInstance());

            assertNotNull(ex.getCause());
            assertEquals(UnsupportedOperationException.class, ex.getCause().getClass());
            assertEquals("Unable to instantiate utility class", ex.getCause().getMessage());
        }
    }

    @Test
    void testInit() {
        assertDoesNotThrow(LoggerJdkStatic::init);
        assertEquals(LOG_FORMAT_DEFAULT_VALUE, getProperty(LOG_FORMAT));
    }

    @Test
    void testInitWithInvalidPackage() {
        final var packageCharacters = new char[256];

        fill(packageCharacters, 0, 255, '-');
        setProperty(LOG_SKIP_PACKAGES, new String(packageCharacters));

        assertDoesNotThrow(LoggerJdkStatic::init);
        assertEquals(Logger.class.getPackageName(), getProperty(LOG_SKIP_PACKAGES));
    }

    @Test
    void testInitWithTooLongFormat() {
        final var formatCharacters = new char[256];

        fill(formatCharacters, 0, 255, '-');
        setProperty(LOG_FORMAT, new String(formatCharacters));

        assertDoesNotThrow(LoggerJdkStatic::init);
        assertEquals(LOG_FORMAT_DEFAULT_VALUE, getProperty(LOG_FORMAT));
    }

    @Test
    void testInitWithTooLongPackage() {
        final var packageCharacters = new char[Short.MAX_VALUE + 1];

        fill(packageCharacters, 0, Short.MAX_VALUE, '-');
        setProperty(LOG_SKIP_PACKAGES, new String(packageCharacters));

        assertDoesNotThrow(LoggerJdkStatic::init);
        assertEquals(Logger.class.getPackageName(), getProperty(LOG_SKIP_PACKAGES));
    }

    @Test
    void testInitWithValidPackage() {
        setProperty(LOG_SKIP_PACKAGES, System.class.getPackageName());
        assertDoesNotThrow(LoggerJdkStatic::init);
        assertEquals(LOG_FORMAT_DEFAULT_VALUE, getProperty(LOG_FORMAT));
    }

}