package com.example.shared.logging.internal;

import static java.lang.System.getProperties;
import static java.nio.file.Files.deleteIfExists;
import static java.nio.file.Path.of;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import java.io.IOException;
import java.io.UncheckedIOException;

import org.junit.jupiter.api.BeforeEach;

import com.example.shared.logging.Logger;

/**
 * The {@code LogAwareServiceTestContract} is a contract interface for all unit tests for {@link LogAwareService} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
interface LogAwareServiceTestContract {

    default Logger getLogger() throws Exception {
        return assertDoesNotThrow(() -> LogAwareService.logger(getClass()));
    }

    @BeforeEach
    default void setup() {
        getProperties().remove(LOG_FACTORY_NAME_PARAM);

        try {
            deleteIfExists(of("target", "test-classes", "META-INF", "log"));
        } catch (final IOException e) {
            throw new UncheckedIOException(e);
        }
    }

}