package com.example.shared.logging.internal;

import static java.lang.System.getProperty;
import static java.lang.System.setProperty;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import org.junit.jupiter.api.Test;

import com.example.shared.logging.internal.jdk.LoggerFactoryJdk;

/**
 * The {@code LogAwareServiceWithFactoryTest} class is a unit test for the class {@link LogAwareService}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogAwareServiceWithFactoryTest implements LogAwareServiceTestContract {

    @Test
    void testWithFactory() throws Exception {
        setProperty(LOG_FACTORY_NAME_PARAM, LoggerFactoryJdk.class.getName());

        assertNotNull(getLogger());
        assertEquals(LoggerFactoryJdk.class.getName(), getProperty(LOG_FACTORY_NAME_PARAM));
    }

}