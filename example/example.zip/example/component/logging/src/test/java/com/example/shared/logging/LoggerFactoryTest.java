package com.example.shared.logging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

/**
 * The {@code LoggerFactoryTest} class is a unit test for the interface {@link LoggerFactory}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LoggerFactoryTest implements LogAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoggerFactoryTest.class);

    @Test
    void test() {
        assertNotNull(log());
        assertNotNull(LOGGER);
        assertEquals(LOGGER, log());
    }

}