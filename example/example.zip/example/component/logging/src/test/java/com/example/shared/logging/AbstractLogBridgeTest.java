package com.example.shared.logging;

import static java.lang.System.Logger.Level.DEBUG;
import static java.lang.System.Logger.Level.ERROR;
import static java.lang.System.Logger.Level.INFO;
import static java.lang.System.Logger.Level.TRACE;
import static java.lang.System.Logger.Level.WARNING;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.System.Logger.Level;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;

/**
 * The {@code AbstractLogBridgeTest} is a base class for all unit tests for the {@link LogAware} interface and
 * implementations of {@link Logger} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@DisplayName("Abstract LogAware Test Case")
@Tags({@Tag("log"), @Tag("logger"), @Tag("l4j")})
abstract class AbstractLogBridgeTest<L> implements LogAware {

    private static final String message = "The Test Message";
    private static final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private static final PrintStream newErr = new PrintStream(out);
    private static final PrintStream err = System.err;

    static {
        System.setErr(newErr);
    }

    static String console() {
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    @AfterAll
    static void tearDownAfterAll() throws Exception {
        System.setErr(err);
    }

    private final String messageWithArguments;
    private final String patternVariableMark;

    AbstractLogBridgeTest(final String patternVariableMark) {
        this.patternVariableMark = patternVariableMark;
        this.messageWithArguments = "The Test Message '"
            + patternVariableMark
            + "'";
    }

    abstract String getMessage1(L lvl, String value);

    abstract String getMessage2(L lvl, Level level, String value);

    abstract L of(Level level);

    @BeforeEach
    void setUp() throws Exception {
        out.reset();
    }

    @Test
    @Tags({@Tag("log"), @Tag("logger"), @Tag("level.debug")})
    @DisplayName("Test DEBUG Level")
    final void testDebug() {
        log().debug(message);
        log().debug(this.patternVariableMark, message);

        final Exception e = new Exception(DEBUG.getName());
        log().debug(this.patternVariableMark + ": " + this.patternVariableMark, e, e.getMessage(), message);

        testLog(DEBUG, new Throwable(message), "Debug");
    }

    @Test
    @Tags({@Tag("log"), @Tag("logger"), @Tag("level.error")})
    @DisplayName("Test ERROR Level")
    final void testError() {
        log().error(message);
        log().error(this.patternVariableMark, message);

        final Exception e = new Exception(ERROR.getName());
        log().error(this.patternVariableMark + ": " + this.patternVariableMark, e, e.getMessage(), message);

        testLog(ERROR, new Throwable(message), "Error");
    }

    @Test
    @Tags({@Tag("log"), @Tag("logger"), @Tag("level.info")})
    @DisplayName("Test INFO Level")
    final void testInfo() {
        log().info(message);
        log().info(this.patternVariableMark, message);

        final Exception e = new Exception(INFO.getName());
        log().info(this.patternVariableMark + ": " + this.patternVariableMark, e, e.getMessage(), message);

        testLog(INFO, new Throwable(message), "Info");
    }

    @Test
    @Tags({@Tag("log"), @Tag("logger"), @Tag("level.trace")})
    @DisplayName("Test TRACE Level")
    final void testTrace() {
        log().trace(message);
        log().trace(this.patternVariableMark, message);

        final Exception e = new Exception(TRACE.getName());
        log().trace(this.patternVariableMark + ": " + this.patternVariableMark, e, e.getMessage(), message);

        testLog(TRACE, new Throwable(message), "Trace");
    }

    @Test
    @Tags({@Tag("log"), @Tag("logger"), @Tag("level.warning")})
    @DisplayName("Test WARNING Level")
    final void testWarning() {
        log().warning(message);
        log().warning(this.patternVariableMark, message);

        final Exception e = new Exception(WARNING.getName());

        log().warning(this.patternVariableMark + ": " + this.patternVariableMark, e, e.getMessage(), message);

        testLog(WARNING, new Throwable(message), "Warning");
    }

    private void testLog(final Level lvl, final Throwable th,
            final String source) {
        final L level = of(lvl);
        final String levelName = lvl.toString();
        final String value = levelName.charAt(0) + levelName.substring(1).toLowerCase();

        log().log(lvl, th, this.messageWithArguments, lvl);

        final String console = console();
        final String message1 = getMessage1(level, value);
        final String message2 = getMessage2(level, lvl, value);

        final int index = console.indexOf(message1);

        assertTrue(index > 0);
        assertTrue(console.lastIndexOf(message1) > index);
        assertTrue(console.contains(message2));
        assertTrue(console.contains("/com.example.shared.logging.AbstractLogBridgeTest.test" + source));
        assertTrue(console.contains("java.lang.Throwable: The Test Message"));
    }

}