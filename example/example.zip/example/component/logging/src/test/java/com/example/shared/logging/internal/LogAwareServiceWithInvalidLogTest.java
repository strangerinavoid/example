package com.example.shared.logging.internal;

import static java.lang.System.getProperty;
import static java.nio.file.Files.createDirectories;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import java.nio.file.Path;

import org.junit.jupiter.api.Test;

/**
 * The {@code LogAwareServiceWithInvalidLogTest} class is a unit test for the class {@link LogAwareService}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogAwareServiceWithInvalidLogTest implements LogAwareServiceTestContract {

    @Test
    void testWithDefault() throws Exception {
        final var log = Path.of("target", "test-classes", "META-INF", "log");

        createDirectories(log);

        assertNotNull(getLogger());
        assertEquals(null, getProperty(LOG_FACTORY_NAME_PARAM));
    }

}