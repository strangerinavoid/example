package com.example.shared.logging.internal;

import static java.lang.System.getProperty;
import static java.lang.System.setProperty;
import static java.util.Arrays.fill;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static com.example.shared.logging.LogEnvironment.LOG_FACTORY_NAME_PARAM;

import org.junit.jupiter.api.Test;

/**
 * The {@code LogAwareServiceWithInvalidFactoryNameTest} class is a unit test for the class {@link LogAwareService}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogAwareServiceWithInvalidFactoryNameTest implements LogAwareServiceTestContract {

    @Test
    void testWithInvalidFactory() throws Exception {
        final var factoryCharacters = new char[256];

        fill(factoryCharacters, 0, factoryCharacters.length - 1, '-');
        setProperty(LOG_FACTORY_NAME_PARAM, new String(factoryCharacters));

        assertNotNull(getLogger());
        assertEquals(new String(factoryCharacters), getProperty(LOG_FACTORY_NAME_PARAM));
    }

}