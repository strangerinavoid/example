package com.example.shared.logging;

import static java.lang.String.format;
import static java.lang.String.valueOf;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.lang.System.Logger.Level;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import org.junit.jupiter.api.Test;

import com.example.shared.logging.mock.LoggerMock;

/**
 * The {@code LoggerTest} class is a unit test for the interface {@link Logger}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LoggerTest {

    private static final class LoggerImpl implements Logger {

        private final LoggerMock mock;

        /**
         * Creates an instance of class @{code LoggerImpl}.
         */
        private LoggerImpl() {
            this.mock = new LoggerMock();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean isLoggable(final Level level) {
            return this.mock.isLoggable(level);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void log(final Level level, final Throwable thrown, final String message, final Object... arguments) {
            this.mock.log(level, () -> format(message, arguments), thrown);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void log(final Level level, final Throwable thrown, final Supplier<?> messageSupplier) {
            this.mock.log(level, () -> valueOf(messageSupplier.get()), thrown);
        }

    }

    private static final String TEST_EXCEPTION_MESSAGE = "dummy exception";
    private static final String TEST_MESSAGE = "Hello, buddy!";
    private static final String TEST_MESSAGE_DEBUG = "[DEBUG: Hello, buddy!]";
    private static final String TEST_MESSAGE_ERROR = "[ERROR: Hello, buddy!]";
    private static final String TEST_MESSAGE_FORMAT = "Hello, %s!";
    private static final String TEST_MESSAGE_FORMAT_ARGUMENT = "buddy";
    private static final String TEST_MESSAGE_INFO = "[INFO: Hello, buddy!]";
    private static final String TEST_MESSAGE_TRACE = "[TRACE: Hello, buddy!]";
    private static final String TEST_MESSAGE_WARNING = "[WARNING: Hello, buddy!]";

    @Test
    void testDebugWithMessage() {
        testWithOperator(logger -> logger.debug(TEST_MESSAGE), TEST_MESSAGE_DEBUG);
    }

    @Test
    void testDebugWithMessageAndArguments() {
        testWithOperator(logger -> logger.debug(TEST_MESSAGE_FORMAT, TEST_MESSAGE_FORMAT_ARGUMENT), TEST_MESSAGE_DEBUG);
    }

    @Test
    void testDebugWithMessageAndThrowableAndArguments() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.debug(TEST_MESSAGE_FORMAT, thrown, TEST_MESSAGE_FORMAT_ARGUMENT),
            TEST_MESSAGE_DEBUG, thrown);
    }

    @Test
    void testDebugWithSupplier() {
        testWithOperator(logger -> logger.debug(() -> TEST_MESSAGE), TEST_MESSAGE_DEBUG);
    }

    @Test
    void testDebugWithSupplierWithThrown() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.debug(() -> TEST_MESSAGE, thrown), TEST_MESSAGE_DEBUG, thrown);
    }

    @Test
    void testErrorWithMessage() {
        testWithOperator(logger -> logger.error(TEST_MESSAGE), TEST_MESSAGE_ERROR);
    }

    @Test
    void testErrorWithMessageAndArguments() {
        testWithOperator(logger -> logger.error(TEST_MESSAGE_FORMAT, TEST_MESSAGE_FORMAT_ARGUMENT), TEST_MESSAGE_ERROR);
    }

    @Test
    void testErrorWithMessageAndThrowableAndArguments() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.error(TEST_MESSAGE_FORMAT, thrown, TEST_MESSAGE_FORMAT_ARGUMENT),
            TEST_MESSAGE_ERROR, thrown);
    }

    @Test
    void testErrorWithSupplier() {
        testWithOperator(logger -> logger.error(() -> TEST_MESSAGE), TEST_MESSAGE_ERROR);
    }

    @Test
    void testErrorWithSupplierWithThrown() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.error(() -> TEST_MESSAGE, thrown), TEST_MESSAGE_ERROR, thrown);
    }

    @Test
    void testInfoWithMessage() {
        testWithOperator(logger -> logger.info(TEST_MESSAGE), TEST_MESSAGE_INFO);
    }

    @Test
    void testInfoWithMessageAndArguments() {
        testWithOperator(logger -> logger.info(TEST_MESSAGE_FORMAT, TEST_MESSAGE_FORMAT_ARGUMENT), TEST_MESSAGE_INFO);
    }

    @Test
    void testInfoWithMessageAndThrowableAndArguments() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.info(TEST_MESSAGE_FORMAT, thrown, TEST_MESSAGE_FORMAT_ARGUMENT),
            TEST_MESSAGE_INFO, thrown);
    }

    @Test
    void testInfoWithSupplier() {
        testWithOperator(logger -> logger.info(() -> TEST_MESSAGE), TEST_MESSAGE_INFO);
    }

    @Test
    void testInfoWithSupplierWithThrown() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.info(() -> TEST_MESSAGE, thrown), TEST_MESSAGE_INFO, thrown);
    }

    @Test
    void testTraceWithMessage() {
        testWithOperator(logger -> logger.trace(TEST_MESSAGE), TEST_MESSAGE_TRACE);
    }

    @Test
    void testTraceWithMessageAndArguments() {
        testWithOperator(logger -> logger.trace(TEST_MESSAGE_FORMAT, TEST_MESSAGE_FORMAT_ARGUMENT), TEST_MESSAGE_TRACE);
    }

    @Test
    void testTraceWithMessageAndThrowableAndArguments() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.trace(TEST_MESSAGE_FORMAT, thrown, TEST_MESSAGE_FORMAT_ARGUMENT),
            TEST_MESSAGE_TRACE, thrown);
    }

    @Test
    void testTraceWithSupplier() {
        testWithOperator(logger -> logger.trace(() -> TEST_MESSAGE), TEST_MESSAGE_TRACE);
    }

    @Test
    void testTraceWithSupplierWithThrown() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.trace(() -> TEST_MESSAGE, thrown), TEST_MESSAGE_TRACE, thrown);
    }

    @Test
    void testWarningWithMessage() {
        testWithOperator(logger -> logger.warning(TEST_MESSAGE), TEST_MESSAGE_WARNING);
    }

    @Test
    void testWarningWithMessageAndArguments() {
        testWithOperator(logger -> logger.warning(TEST_MESSAGE_FORMAT, TEST_MESSAGE_FORMAT_ARGUMENT),
            TEST_MESSAGE_WARNING);
    }

    @Test
    void testWarningWithMessageAndThrowableAndArguments() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(
            logger -> logger.warning(TEST_MESSAGE_FORMAT, thrown, TEST_MESSAGE_FORMAT_ARGUMENT), TEST_MESSAGE_WARNING,
            thrown);
    }

    @Test
    void testWarningWithSupplier() {
        testWithOperator(logger -> logger.warning(() -> TEST_MESSAGE), TEST_MESSAGE_WARNING);
    }

    @Test
    void testWarningWithSupplierAndThrown() {
        final var thrown = new Exception(TEST_EXCEPTION_MESSAGE);

        testWithOperatorAndThrowable(logger -> logger.warning(() -> TEST_MESSAGE, thrown), TEST_MESSAGE_WARNING,
            thrown);
    }

    private <T> void testWithOperator(final UnaryOperator<Logger> operator, final String reference) {
        final var logger = new LoggerImpl();

        assertEquals(logger, assertDoesNotThrow(() -> operator.apply(logger)));

        final var log = logger.mock.getRecords();

        assertEquals(1, log.size());
        assertEquals(reference, log.toString());
        assertNull(logger.mock.getThrown());
    }

    private <T> void testWithOperatorAndThrowable(final UnaryOperator<Logger> operator, final String reference,
            final Throwable thrown) {
        final var logger = new LoggerImpl();

        assertEquals(logger, assertDoesNotThrow(() -> operator.apply(logger)));

        final var log = logger.mock.getRecords();

        assertEquals(1, log.size());
        assertEquals(reference, log.toString());
        assertEquals(thrown, logger.mock.getThrown());
    }

}