package com.example.shared.logging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

/**
 * The {@code LogEnvironmentTest} class is a unit test for the class {@link LogEnvironment}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class LogEnvironmentTest {

    @Test
    void testConstructor() {
        final var constructors = LogEnvironment.class.getDeclaredConstructors();

        assertEquals(1, constructors.length);

        for (final Constructor<?> c : constructors) {
            c.setAccessible(true);

            final var ex = assertThrows(InvocationTargetException.class, () -> c.newInstance());

            assertNotNull(ex.getCause());
            assertEquals(UnsupportedOperationException.class, ex.getCause().getClass());
            assertEquals("Unable to instantiate utility class", ex.getCause().getMessage());
        }
    }

}