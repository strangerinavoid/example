package com.example.shared.core;

import static java.nio.charset.StandardCharsets.UTF_8;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.example.shared.core.ResourceScope.CLASSPATH;
import static com.example.shared.core.ResourceScope.NONE;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Optional;

import org.junit.jupiter.api.Test;

/**
 * The {@code ResourceScopeTest} class is a unit test for the internal class
 * {@link ResourceScope}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class ResourceScopeTest {

    private static final String TEST_INVALID = "resource.invalid";
    private static final String TEST_PHRASE = "RESOURCE SCOPE";
    private static final String TEST_RESOURCE = "META-INF/resource";
    private static final String TEST_RESOURCE_PATH = "target/test-classes/";

    private static final String[] resources = {
        "file:" + TEST_RESOURCE_PATH + TEST_RESOURCE,
        "classpath:" + TEST_RESOURCE,
        "url:" + asUrl(),
        null
        };

    private static URL asUrl() {
        try {
            return Path.of(TEST_RESOURCE_PATH + TEST_RESOURCE).toUri().toURL();
        } catch (final MalformedURLException e) {}

        return null;
    }

    @Test
    void testAlias() {
        for (final ResourceScope scope : ResourceScope.values()) {
            assertEquals(scope.name().toLowerCase(), scope.alias());
        }
    }

    @Test
    void testIsSupported() {
        for (final ResourceScope scope : ResourceScope.values()) {
            final var path = "test/path";
            final var alias = scope.name().toLowerCase();

            assertTrue(scope.isSupported(alias + ":" + path));
            assertFalse(scope.isSupported(alias + "@" + path));
            assertFalse(scope.isSupported(path));
        }
    }

    @Test
    void testIsSupportedWithEmptyValue() {
        for (final ResourceScope scope : ResourceScope.values()) {
            assertFalse(assertDoesNotThrow(() -> scope.isSupported("   ")));
        }
    }

    @Test
    void testIsSupportedWithNull() {
        var i = 0;

        for (final ResourceScope scope : ResourceScope.values()) {
            if (assertDoesNotThrow(() -> scope.isSupported(null))) {
                assertEquals(NONE, scope);
                i++;
            }
        }
        assertEquals(1, i);
    }

    @Test
    void testNone() {
        final var stream1 = NONE.open(null);
        final var stream2 = NONE.open(TEST_INVALID);

        assertEquals(stream1, stream2);
    }

    @Test
    void testOf() {
        assertEquals(Optional.of(CLASSPATH), assertDoesNotThrow(() -> ResourceScope.of("classpath:dummy")));
    }

    @Test
    void testOfWithNull() {
        assertEquals(Optional.of(NONE), assertDoesNotThrow(() -> ResourceScope.of(null)));
    }

    @Test
    void testOfWithUnsupported() {
        assertEquals(Optional.empty(), assertDoesNotThrow(() -> ResourceScope.of("UNSUPPORTED")));
    }

    @Test
    void testOpen() throws IOException {
        for (final String resource : resources) {
            var i = 0;

            for (final ResourceScope scope : ResourceScope.values()) {
                if (scope.isSupported(resource)) {
                    i++;
                    final var stream = assertDoesNotThrow(() -> scope.open(resource));

                    assertNotNull(stream);

                    if (NONE == scope) {
                        assertTrue(stream.isEmpty());
                    } else {
                        assertTrue(stream.isPresent());

                        try (var in = stream.get()) {
                            final var value = assertDoesNotThrow(() -> new String(in.readAllBytes(), UTF_8));

                            assertNotNull(value);
                            assertEquals(TEST_PHRASE, value);
                        }
                    }
                }
            }
            assertEquals(1, i);
        }
    }

    @Test
    void testOpenWithInvalidResource() {
        var i = 0;

        for (final String resource : new String[] {resources[0], resources[2]}) {
            final var r = resource + ".invalid";

            for (final ResourceScope scope : ResourceScope.values()) {
                if (scope.isSupported(resource)) {
                    i++;

                    final var ex = assertThrows(UncheckedIOException.class, () -> scope.open(r));

                    assertNotNull(ex.getMessage());
                    assertTrue(ex.getMessage().contains(TEST_INVALID));
                    assertNotNull(ex.getCause());
                    assertNotNull(ex.getCause().getMessage());
                    assertTrue(ex.getCause().getMessage().contains(TEST_INVALID));
                }
            }
        }
        assertEquals(2, i);
    }

    @Test
    void testValues() {
        for (final ResourceScope scope : ResourceScope.values()) {
            final var path = "test/path";
            final var alias = scope.name().toLowerCase();

            assertEquals(alias + ":" + path, scope.resolve(path));
        }
    }

}