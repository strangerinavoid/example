package com.example.shared.core.type;

import static java.lang.reflect.Modifier.isPrivate;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static com.example.shared.core.type.Types.ofType;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

/**
 * The {@code TypesTest} is a unit test for {@link Types} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class TypesTest {

    @Test
    void testConstructor() {
        final var constructors = Types.class.getDeclaredConstructors();

        assertEquals(1, constructors.length);

        for (final Constructor<?> c : constructors) {
            c.setAccessible(true);

            assertTrue(isPrivate(c.getModifiers()));

            final var ex = assertThrows(InvocationTargetException.class, () -> c.newInstance());

            assertNotNull(ex.getClass());
            assertEquals(UnsupportedOperationException.class, ex.getCause().getClass());
            assertEquals("Unable to instantiate service class", ex.getCause().getMessage());
        }
    }

    @Test
    void testOfType() {
        final Object o = "test".getBytes();
        final var type = assertDoesNotThrow(() -> ofType(byte[].class));

        assertNotNull(type);
        assertEquals("test", new String(type.as(o)));
    }

}