package com.example.shared.core.property;

import static java.lang.String.valueOf;
import static java.util.stream.Collectors.toUnmodifiableMap;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import static com.example.shared.core.property.Properties.newProperties;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.net.InetAddress;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.function.Supplier;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * The {@code PropertiesTest} is a unit test class for {@link Properties} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class PropertiesTest {

    private static final java.util.Properties reference = new java.util.Properties();

    static InputStream newStream() {
        try (var output = new ByteArrayOutputStream()) {
            reference.store(output, "Properties Test");

            return new ByteArrayInputStream(output.toByteArray());
        } catch (final IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
        reference.setProperty("prop1", "value1");
        reference.setProperty("prop2", LocalDate.now().toString());
        reference.setProperty("prop3", InetAddress.getLocalHost().getHostName());
    }

    @Test
    void testEmpty() {
        final var empty1 = Properties.empty();
        final var empty2 = Properties.empty();

        assertEquals(empty1, empty2);
        assertTrue(empty1.isEmpty());
        assertTrue(empty2.isEmpty());
    }

    @Test
    void testGet() {
        final var props = newProperties(newStream());

        assertEquals(reference.getProperty("prop1"), props.get("prop1"));
        assertEquals(reference.getProperty("prop2"), props.get("prop2"));
        assertEquals(reference.getProperty("prop3"), props.get("prop3"));
    }

    @Test
    void testGetOrDefault() {
        final var props = newProperties(newStream());

        assertEquals(reference.getProperty("prop1"), props.getOrDefault("prop1", "value10"));
        assertEquals(reference.getProperty("prop2"), props.getOrDefault("prop2", "value20"));
        assertEquals(reference.getProperty("prop3"), props.getOrDefault("prop3", "value30"));

        assertEquals("value40", props.getOrDefault("prop4", "value40"));
        assertNull(props.getOrDefault("prop5", (String)null));
    }

    @Test
    void testGetOrDefaultWithNullSupplier() {
        final var props = newProperties(newStream());
        final var ex = assertThrows(NullPointerException.class, () ->
            props.getOrDefault("missingKey", (Supplier<String>)null));

        assertEquals("Cannot invoke null default value supplier for specified key 'missingKey'", ex.getMessage());
    }

    @Test
    void testGetOrDefaultWithSupplier() {
        final var props = newProperties(newStream());

        assertEquals(reference.getProperty("prop1"), props.getOrDefault("prop1", () -> "value10"));
        assertEquals(reference.getProperty("prop2"), props.getOrDefault("prop2", () -> "value20"));
        assertEquals(reference.getProperty("prop3"), props.getOrDefault("prop3", () -> "value30"));

        assertEquals("value40", props.getOrDefault("prop4", () -> "value40"));
        assertNull(props.getOrDefault("prop5", () -> null));
    }

    @Test
    void testNewPropertiesWithDefaults() {
        final var defaults = new HashMap<String, String>();

        defaults.put("prop1", "value1");
        defaults.put("prop_default", "value_default");

        final var props = assertDoesNotThrow(() -> newProperties(newStream(), defaults));

        assertEquals(reference.getProperty("prop1"), props.get("prop1"));
        assertEquals(reference.getProperty("prop2"), props.get("prop2"));
        assertEquals(reference.getProperty("prop3"), props.get("prop3"));
        assertEquals(reference.getProperty("prop_default"), props.get("value_default"));
    }

    @Test
    void testNewPropertiesWithEmptyDefaults() {
        final var props = assertDoesNotThrow(() -> newProperties(newStream(), new HashMap<>()));

        assertEquals(reference.getProperty("prop1"), props.get("prop1"));
        assertEquals(reference.getProperty("prop2"), props.get("prop2"));
        assertEquals(reference.getProperty("prop3"), props.get("prop3"));
    }

    @Test
    void testNewPropertiesWithException() throws IOException {
        final var in = mock(InputStream.class);

        when(in.read(any())).thenThrow(IOException.class);

        final var ex = assertThrows(UncheckedIOException.class, () -> newProperties(in));

        assertNull(ex.getMessage());
    }

    @Test
    void testNewPropertiesWithNull() {
        final var ex = assertThrows(NullPointerException.class, () -> newProperties(null));

        assertEquals("Cannot create properties from null input stream", ex.getMessage());
    }

    @Test
    void testNewPropertiesWithNullDefaults() {
        final var props = assertDoesNotThrow(() -> newProperties(newStream(), (Properties)null));

        assertEquals(reference.getProperty("prop1"), props.get("prop1"));
        assertEquals(reference.getProperty("prop2"), props.get("prop2"));
        assertEquals(reference.getProperty("prop3"), props.get("prop3"));
    }

    @Test
    void testNewPropertiesWithNulls() {
        final var ex = assertThrows(NullPointerException.class, () -> newProperties(null, (Properties)null));

        assertEquals("Cannot create properties from null input stream", ex.getMessage());
    }

    @Test
    void testStream() {
        final var props = assertDoesNotThrow(() -> newProperties(newStream()));

        final var properties = new java.util.Properties();

        props.stream().forEach(e -> properties.put(e.getKey(), e.getValue()));

        assertEquals(reference, properties);
    }

    @Test
    void testToString() {
        final var defaults = reference.entrySet().stream()
            .collect(toUnmodifiableMap(e -> valueOf(e.getKey()), e -> valueOf(e.getValue())));
        final var properties = newProperties(newStream());
        final var defaultsString = defaults.toString();
        final var propertiesString = assertDoesNotThrow(properties::toString);

        assertEquals(defaultsString, propertiesString);
    }

}