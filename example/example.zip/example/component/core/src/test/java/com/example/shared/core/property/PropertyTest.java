package com.example.shared.core.property;

import static java.lang.System.getProperties;
import static java.lang.System.getProperty;
import static java.lang.System.setProperty;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The {@code PropertyTest} is a unit test class for {@link Property} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class PropertyTest {

    private static final String TEST_PROPERTY_KEY = "TEST_PROPERTY_KEY";
    private static final String TEST_PROPERTY_KEY_ALT = "TEST_PROPERTY_KEY_ALT";
    private static final String TEST_PROPERTY_DEFAULT_VALUE = "TEST_PROPERTY_DEFAULT_VALUE";
    private static final Property TEST_PROPERTY = new Property(TEST_PROPERTY_KEY, TEST_PROPERTY_KEY_ALT);

    @BeforeEach
    void setUp() {
        getProperties().remove(TEST_PROPERTY_KEY);
        getProperties().remove(TEST_PROPERTY_KEY_ALT);
    }

    @Test
    void testGet() {
        setProperty(TEST_PROPERTY_KEY, "TEST_VALUE");

        final var value = TEST_PROPERTY.get();

        assertEquals("TEST_VALUE", value);
    }

    @Test
    void testGetOrDefault() {
        final var value = TEST_PROPERTY.getOrDefault(TEST_PROPERTY_DEFAULT_VALUE);

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE, value);
    }

    @Test
    void testGetOrDefaultWithConsumer() {
        final var thrown = new AtomicReference<Throwable>();
        final var value = TEST_PROPERTY.getOrDefault(TEST_PROPERTY_DEFAULT_VALUE, th -> thrown.set(th));

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE, value);
        assertNull(thrown.get());
    }

    @Test
    void testGetOrDefaultWithConsumerAndTooLongValue() {
        final var chars = new char[Short.MAX_VALUE + 1];
        final var value = new String(chars);

        setProperty(TEST_PROPERTY_KEY, value);

        final var thrown = new AtomicReference<Throwable>();
        final var result = TEST_PROPERTY.getOrDefault(TEST_PROPERTY_DEFAULT_VALUE, th -> thrown.set(th));

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE, result);
        assertNotNull(thrown.get());
        assertEquals("An invalid value has been specified as part of System properties or environment. The value of "
            + "the property 'TEST_PROPERTY_KEY' will be ignored, since it has too many characters",
                thrown.get().getMessage());
    }

    @Test
    void testGetOrDefaultWithNullSupplierOfString() {
        final var ex = assertThrows(NullPointerException.class, () ->
            TEST_PROPERTY.getOrDefault((Supplier<String>)null));

        assertEquals("Cannot get default value from null supplier", ex.getMessage());
    }

    @Test
    void testGetOrDefaultWithSupplier() {
        final var value = TEST_PROPERTY.getOrDefault(() -> TEST_PROPERTY_DEFAULT_VALUE);

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE, value);
    }

    @Test
    void testGetOrDefaultWithSupplierOfNull() {
        final var value = TEST_PROPERTY.getOrDefault(() -> null);

        assertNull(value);
    }

    @Test
    void testGetWithTooLongValue() {
        final var chars = new char[Short.MAX_VALUE + 1];
        final var value = new String(chars);

        setProperty(TEST_PROPERTY_KEY, value);

        final var ex = assertThrows(IllegalArgumentException.class, () ->
            TEST_PROPERTY.getOrDefault(TEST_PROPERTY_DEFAULT_VALUE));

        assertEquals("An invalid value has been specified as part of System properties or environment. The value of "
            + "the property 'TEST_PROPERTY_KEY' will be ignored, since it has too many characters", ex.getMessage());
    }

    @Test
    void testProperty() {
        final var property = assertDoesNotThrow(() -> new Property(TEST_PROPERTY_KEY_ALT));

        assertNull(property.get());
    }

    @Test
    void testPropertyWithEmptyArgs() {
        final var ex = assertThrows(IllegalArgumentException.class, () -> new Property());

        assertEquals("Cannot create a nameless property", ex.getMessage());
    }

    @Test
    void testPropertyWithNullNames() {
        final var ex = assertThrows(NullPointerException.class, () -> new Property(null, null));

        assertEquals("Cannot use null property name under index 0", ex.getMessage());
    }

    @Test
    void testPropertyWithOneNullName() {
        final var ex = assertThrows(NullPointerException.class, () -> new Property(TEST_PROPERTY_KEY, null));

        assertEquals("Cannot use null property name under index 1", ex.getMessage());
    }

    @Test
    void testPropertyWithoutName() {
        final var ex = assertThrows(NullPointerException.class, () -> new Property((String)null));

        assertNull(ex.getMessage());
    }

    @Test
    void testPropertyWithoutNames() {
        final var ex = assertThrows(NullPointerException.class, () -> new Property((String[])null));

        assertEquals("Cannot create a new property from null names", ex.getMessage());
    }

    @Test
    void testSet() {
        setProperty(TEST_PROPERTY_KEY_ALT, TEST_PROPERTY_DEFAULT_VALUE);

        final var value = TEST_PROPERTY.get();

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE, value);

        final var value1 = TEST_PROPERTY.set(TEST_PROPERTY_DEFAULT_VALUE + ":new");
        final var value2 = getProperty(TEST_PROPERTY_KEY);

        assertEquals(TEST_PROPERTY_DEFAULT_VALUE + ":new", value2);
        assertNull(value1);

        final var value3 = TEST_PROPERTY.get();

        assertEquals(value2, value3);
    }

}