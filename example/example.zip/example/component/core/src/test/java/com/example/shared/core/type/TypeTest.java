package com.example.shared.core.type;

import static java.util.stream.Collectors.joining;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import static com.example.shared.core.type.Type.asType;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * The {@code TypeTest} is a unit test for {@link Type} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class TypeTest {

    @Test
    void testAsFunction() {
        final Object data = "test";
        final var type = Type.of(String.class);
        final var value = assertDoesNotThrow(() -> Stream.of(data).map(type).collect(joining()));

        assertEquals(data, value);
    }

    @Test
    void testAsType() {
        assertNull(asType(null));

        final var stream = assertDoesNotThrow(() -> {
            final Object obj = Stream.of("dummy");

            return asType(obj);
        });
        assertNotNull(stream);
    }

    @Test
    void testAsTypeWithTypeDef() {
        assertNull(asType(null, new Type<>() {}));

        try (final var stream = assertDoesNotThrow(() -> {
            final Object obj = Stream.of("dummy");

            return asType(obj, new Type<Stream<String>>() {});
        })) {
            assertNotNull(stream);
            assertEquals(1, stream.count());
        }
    }

    @Test
    void testAsTypeWithTypeDefAndNullDef() {
        final var ex = assertThrows(NullPointerException.class, () -> asType(null, null));

        assertEquals("Cannot cast to a null type", ex.getMessage());
    }

    @Test
    void testAsTypeWithWrongType() {
        final var ex = assertThrows(ClassCastException.class, this::failTest);

        assertEquals("class java.lang.Object cannot be cast to class java.lang.String (java.lang.Object and java.lang"
            + ".String are in module java.base of loader 'bootstrap')", ex.getMessage());
    }

    @Test
    void testOf() {
        final Object obj = Stream.of("dummy");
        final var stream = assertDoesNotThrow(() -> Type.of(Stream.class).as(obj));
        final var value = asType(stream, new Type<Stream<String>>() {}).collect(joining());

        assertEquals("dummy", value);
    }

    private void failTest() {
        final var value = asType(new Object(), Type.of(String.class));

        fail("A value is not acceptable: " + value);
    }

}