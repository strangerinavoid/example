package com.example.shared.core;

import static java.lang.ClassLoader.getSystemClassLoader;
import static java.lang.reflect.Modifier.isPrivate;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import static com.example.shared.core.Services.load;
import static com.example.shared.core.Services.loadAll;
import static com.example.shared.core.Services.toCollection;
import static com.example.shared.core.Services.toSupplier;
import static com.example.shared.core.type.Type.asType;

import java.lang.System.LoggerFinder;
import java.lang.reflect.InvocationTargetException;
import java.util.ServiceLoader;
import java.util.ServiceLoader.Provider;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * The {@code ServicesTest} is a unit test class for {@link Services} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class ServicesTest {

    private interface Service extends Supplier<String> {}

    private static class ServiceImpl1 implements Service {

        @Override
        public String get() {
            return "impl1";
        }

    }

    private static class ServiceImpl2 implements Service {

        @Override
        public String get() {
            return "impl2";
        }

    }

    private static final Executable EXECUTABLE = () -> loadAll(LoggerFinder.class,
        service -> ServiceLoader.load(service, getSystemClassLoader())::stream, p -> true, Throwable::printStackTrace);

    @Test
    void testConstructor() {
        final var constructors = Services.class.getDeclaredConstructors();

        assertEquals(1, constructors.length);

        for (final var c : constructors) {
            c.setAccessible(true);

            assertTrue(isPrivate(c.getModifiers()));

            final var ex = assertThrows(InvocationTargetException.class, () -> c.newInstance());

            assertNotNull(ex.getCause());
            assertEquals(UnsupportedOperationException.class, ex.getCause().getClass());
            assertEquals("Unable to instantiate service class", ex.getCause().getMessage());
        }
    }

    @Test
    void testLoad() {
        final var holder = newHolder();
        final var impl1 = new ServiceImpl1();
        final var impl2 = new ServiceImpl2();
        final var provider1 = newProviderMock(impl1);
        final var provider2 = newProviderMock(impl2);

        final var opt = assertDoesNotThrow(() -> load(Service.class,
            s -> () -> asType(Stream.of(provider1, provider2)), p -> p.type() == ServiceImpl2.class, holder::set));

        assertTrue(opt.isPresent());

        final var service = opt.get();

        assertNotNull(service);
        assertEquals(impl2.get(), service.get());
        assertNull(holder.get());
    }

    @Test
    void testLoadAllEmpty() {
        final var holder = newHolder();
        final var collection = assertDoesNotThrow(() ->
            loadAll(Service.class, s -> Stream::empty, p -> true, holder::set));

        assertTrue(collection.isEmpty());
        assertNull(holder.get());
    }

    @Test
    void testLoadAllWithAllError() {
        final var holder = newHolder();
        final var impl1 = new ServiceImpl1();
        final var impl2 = new ServiceImpl2();
        final var provider1 = newProviderExMock(impl1);
        final var provider2 = newProviderExMock(impl2);
        final var collection = assertDoesNotThrow(() ->
            loadAll(Service.class, s -> () -> asType(Stream.of(provider1, provider2)), p -> true, holder::set));

        assertTrue(collection.isEmpty());
        assertNotNull(holder.get());
        assertEquals(IllegalStateException.class, holder.get().getClass());
    }

    @Test
    void testLoadAllWithOneError() {
        final var holder = newHolder();
        final var impl1 = new ServiceImpl1();
        final var impl2 = new ServiceImpl2();
        final var provider1 = newProviderMock(impl1);
        final var provider2 = newProviderExMock(impl2);
        final var collection = assertDoesNotThrow(() ->
            loadAll(Service.class, s -> () -> asType(Stream.of(provider1, provider2)), p -> true, holder::set));

        assertEquals(1, collection.size());
        assertNotNull(holder.get());
        assertEquals(IllegalStateException.class, holder.get().getClass());

        final var simpl = collection.stream().findAny().orElse(null);

        assertNotNull(simpl);
        assertEquals(impl1.get(), simpl.get());
    }

    @Test
    void testLoadEmpty() {
        final var holder = newHolder();
        final var opt = assertDoesNotThrow(() ->
            load(Service.class, s -> Stream::empty, p -> true, holder::set));

        assertTrue(opt.isEmpty());
        assertNull(holder.get());
    }

    @Test
    void testLoadWithError() {
        final var holder = newHolder();
        final var impl = new ServiceImpl1();
        final var provider = newProviderExMock(impl);
        final var opt = assertDoesNotThrow(() ->
            load(Service.class, s -> () -> asType(Stream.of(provider)), p -> true, holder::set));

        assertTrue(opt.isEmpty());
        assertNotNull(holder.get());
        assertEquals(IllegalStateException.class, holder.get().getClass());
    }

    @Test
    void testLoadWithUsesError() {
        final var ex = assertThrows(Error.class, EXECUTABLE);

        assertEquals("java.lang.System$LoggerFinder: module example.shared.core does not declare `uses`",
            ex.getMessage());
    }

    @Test
    void testToCollection() {
        final var impl = new ServiceImpl1();
        final var provider = newProviderMock(impl);
        final var providers = assertDoesNotThrow(() -> toCollection(() -> Stream.of(provider), p -> true,
            Throwable::printStackTrace));

        assertEquals(1, providers.size());

        final var sprovider = providers.stream().findAny().orElse(null);

        assertNotNull(sprovider);

        final var simpl = sprovider.get();

        assertNotNull(simpl);
        assertEquals(impl.get(), simpl.get());
    }

    @Test
    void testToCollectionWithError() {
        final var message = "artificial error";
        final var holder = newHolder();
        final var providers = assertDoesNotThrow(() ->
            toCollection(() -> {
                    throw new Error(message);
                }, p -> true, holder::set));

        assertNotNull(holder.get());
        assertEquals(message, holder.get().getMessage());
        assertTrue(providers.isEmpty());
    }

    @Test
    void testToSupplier() {
        final var ex = assertThrows(Error.class, () ->
            toSupplier(LoggerFinder.class, service ->
                ServiceLoader.load(service, getSystemClassLoader())::stream));

        assertEquals("java.lang.System$LoggerFinder: module example.shared.core does not declare `uses`",
            ex.getMessage());
    }

    @Test
    void testToSupplierWithNullFactory() {
        final var ex = assertThrows(NullPointerException.class, () -> toSupplier(LoggerFinder.class, null));

        assertEquals("A service loader factory cannot be null", ex.getMessage());
    }

    @Test
    void testToSupplierWithNullService() {
        final Class<LoggerFinder> service = null;
        final var ex = assertThrows(NullPointerException.class, () ->
            toSupplier(service, s -> ServiceLoader.load(s)::stream));

        assertEquals("A service class cannot be null", ex.getMessage());
    }

    private AtomicReference<Throwable> newHolder() {
        return new AtomicReference<>();
    }

    private <T, S extends T> Provider<T> newProviderExMock(final S impl) {
        final var provider = mock(Provider.class);

        when(provider.type()).thenReturn(impl.getClass());
        when(provider.get()).thenThrow(IllegalStateException.class);

        return asType(provider);
    }

    private <T, S extends T> Provider<T> newProviderMock(final S impl) {
        final var provider = mock(Provider.class);

        when(provider.type()).thenReturn(impl.getClass());
        when(provider.get()).thenReturn(impl);

        return asType(provider);
    }

}