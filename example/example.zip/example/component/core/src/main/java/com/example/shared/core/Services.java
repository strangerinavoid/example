package com.example.shared.core;

import static java.util.Collections.emptyList;
import static java.util.List.copyOf;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.empty;
import static java.util.stream.Collectors.toUnmodifiableList;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Optional;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import java.util.ServiceLoader.Provider;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * The {@code Services} is a support class for a {@link ServiceLoader} functions.
 *
 * <h3><a id="errors">Errors</a></h3>
 * <p>
 * When using the service loader methods will fail with {@link ServiceConfigurationError} if an error occurs
 * locating, loading or instantiating a service provider. When processing the service loader's stream then
 * {@code ServiceConfigurationError} may be thrown by any method that causes a service provider to be located or
 * loaded.
 * <p>
 * When loading or instantiating a service provider in a module, {@code ServiceConfigurationError} can be thrown for
 * the following reasons:
 * <ul>
 *   <li>The service provider cannot be loaded.</li>
 *
 *   <li>The service provider does not declare a provider method, and either it is not assignable to the service's
 *   interface/class or does not have a provider constructor.</li>
 *
 *   <li>The service provider declares a public static no-args method named "provider" with a return type that is
 *   not assignable to the service's interface or class.</li>
 *
 *   <li>The service provider class file has more than one public static no-args method named
 *   "{@code provider}".</li>
 *
 *   <li>The service provider declares a provider method and it fails by returning {@code null} or throwing an
 *   exception.</li>
 *
 *   <li>The service provider does not declare a provider method, and its provider constructor fails by throwing an
 *   exception.</li>
 * </ul>
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Services {

    /**
     * Loads the first available service of the service class that matches the given predicate.
     * <p>
     * This convenience method is equivalent to invoking the {@link ServiceLoader#stream()} method, use filter with
     * predicate {@link Stream#filter(Predicate)} and then obtain the first element using {@link Stream#findFirst()}
     * method.
     * <p>
     * The following example loads the first available service. If no service providers are located then it returns
     * empty {@link Optional}.
     * <pre>{@code
     * Optional<CodecFactory> optFactory = Services.load(CodecFactory.class,
     *     s -> ServiceLoader.load(s)::stream,
     *     p -> p.type() = Base64CodecFactory.class,
     *     Throwable::printStackTrace());
     *
     * CodecFactory factory = optFactory.orElseGet(NopBase64CodecFactory::new);
     * }</pre>
     *
     * @param   <S> the class of the service type.
     * @param   service the interface or abstract class representing the service.
     * @param   factory the factory that loads service providers supplier.
     * @param   predicate the predicate to filter unnecessary service providers.
     * @param   handler an error handler that can be used to handle errors, occurred during service instantiation.
     * @return  an {@link Optional} with the first service or empty {@code Optional} if no service is located.
     * @throws  ServiceConfigurationError if a provider classes cannot be loaded for any of the reasons specified in
     *          the <a href="#errors">Errors</a> section above.
     */
    public static <S> Optional<S> load(final Class<S> service, final ServiceSupplierFactory<S> factory,
            final Predicate<Provider<S>> predicate, final ServiceFailureCallback handler) {
        final var loader = toSupplier(service, factory);

        for (final var provider : toCollection(loader, predicate, handler)) {
            try {
                return Optional.of(provider.get());
            } catch (final Exception e) {
                handler.accept(e);
            }
        }
        return empty(); // cannot return service instance of the given service interface
    }

    /**
     * Loads the collection of available services of the service class that matches the given predicate.
     * <p>
     * This convenience method is equivalent to invoking the {@link ServiceLoader#stream()} method, use filter with
     * predicate {@link Stream#filter(Predicate)} and then obtain the elements using
     * {@link Stream#collect(java.util.stream.Collector)} method.
     * <p>
     * The following example loads the all available services. If no service providers are located then it returns
     * empty collection.
     * <pre>{@code
     * Collection<CodecFactory> factories = Services.load(CodecFactory.class,
     *     s -> ServiceLoader.load(s)::stream, p -> p.type().getSimpleName().endsWith("Base64CodecFactory"),
     *     Throwable::printStackTrace());
     * }</pre>
     *
     * @param   <S> the class of the service type.
     * @param   service the interface or abstract class representing the service.
     * @param   factory the factory that loads service providers supplier.
     * @param   predicate the predicate to filter unnecessary service providers.
     * @param   handler an error handler that can be used to handle errors, occurred during service instantiation.
     * @return  a {@link Collection} with the all available services or empty collection if no service is located.
     * @throws  ServiceConfigurationError if a provider classes cannot be loaded for any of the reasons specified in
     *          the <a href="#errors">Errors</a> section above.
     */
    public static <S> Collection<S> loadAll(final Class<S> service, final ServiceSupplierFactory<S> factory,
            final Predicate<Provider<S>> predicate, final ServiceFailureCallback handler) {
        final var loader = toSupplier(service, factory);
        final var instances = new LinkedList<S>();

        for (final Provider<S> provider : toCollection(loader, predicate, handler)) {
            try {
                instances.add(provider.get());
            } catch (final Exception e) {
                handler.accept(e);
            }
        }
        return copyOf(instances);
    }

    static <S> Collection<Provider<S>> toCollection(final ServiceSupplier<S> supplier,
            final Predicate<? super Provider<S>> predicate, final ServiceFailureCallback handler) {
        try {
            return supplier.get()
                .filter(requireNonNull(predicate, "A service criteria predicate cannot be null"))
                .collect(toUnmodifiableList());
        } catch (final Error e) {
            // a service loader has no other option to handle the case with the missing class, even if this class is
            // not required
            handler.accept(e);
        }
        return emptyList();
    }

    static <S> ServiceSupplier<S> toSupplier(final Class<S> service, final ServiceSupplierFactory<S> factory) {
        return requireNonNull(factory, "A service loader factory cannot be null")
            .apply(requireNonNull(service, "A service class cannot be null"));
    }

    /**
     * Constructor of the class {@code Services} was declared as private to prevent its instantiation.
     */
    private Services() {
        throw new UnsupportedOperationException("Unable to instantiate service class");
    }

}