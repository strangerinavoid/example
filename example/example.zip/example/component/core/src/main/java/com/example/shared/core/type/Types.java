package com.example.shared.core.type;

import static java.util.Objects.requireNonNull;

import static com.example.shared.core.Services.loadAll;
import static com.example.shared.core.type.Type.asType;

import java.util.Map;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@code Types} class is a service class that is used to manage known types and cache types if necessary.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Types {

    /**
     * The {@code TypesHolder} is TODO write correct comment
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private static final class TypesHolder {

        private static final Map<Class<?>, Type<?>> KNOWN_TYPES = new ConcurrentHashMap<>();
        private static final Map<String, Type<?>> KNOWN_TYPES_BY_NAME = new ConcurrentHashMap<>();

        static {
            final var types =
                loadAll(TypeService.class, s -> ServiceLoader.load(s)::stream, t -> true, Throwable::printStackTrace);

            types.forEach(t -> {
                KNOWN_TYPES.putIfAbsent(t.type(), t);
                KNOWN_TYPES_BY_NAME.putIfAbsent(t.name(), t);
            });
        }

    }

    /**
     * The default abstract type that can be used each time when unknown type is requested.
     */
    static final Type<?> ABSTRACT_TYPE = new Type<>() {};

    /**
     * Computes and returns instance of the type according to the given type class.
     *
     * @return  an instance of the {@link Type}.
     */
    public static <T> Type<T> ofType(final Class<T> type) {
        return asType(TypesHolder.KNOWN_TYPES.computeIfAbsent(requireNonNull(type, "A type class cannot be null"),
            k -> ABSTRACT_TYPE));
    }

    /**
     * Computes and returns instance of the type according to the given type name.
     *
     * @return  an instance of the {@link Type}.
     */
    public static <T> Type<T> ofType(final String type) {
        return asType(TypesHolder.KNOWN_TYPES_BY_NAME.computeIfAbsent(requireNonNull(type,
            "A type name cannot be null"), k -> ABSTRACT_TYPE));
    }

    /**
     * Constructor of the class {@code Types} was declared as private to prevent its instantiation.
     */
    private Types() {
        throw new UnsupportedOperationException("Unable to instantiate service class");
    }

}