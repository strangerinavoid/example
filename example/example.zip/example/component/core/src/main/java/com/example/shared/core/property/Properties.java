package com.example.shared.core.property;

import static java.lang.String.valueOf;
import static java.util.Collections.emptyMap;
import static java.util.Map.copyOf;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElse;
import static java.util.stream.Collectors.toUnmodifiableMap;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * The {@code Properties} class represents a persistent set of properties. The {@code Properties} can be constructed
 * from an input stream. Each key and its corresponding value in the property list is a string.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Properties {

    /**
     * Common instance for {@code empty()}.
     */
    private static final Properties EMPTY = new Properties(emptyMap());

    /**
     * Returns an empty {@code Properties} instance.  No key-value pairs are present for this {@code Properties}.
     *
     * @apiNote
     * Though it may be tempting to do so, avoid testing if an object is empty by comparing with {@code ==} against
     * instances returned by {@code #empty()}. There is no guarantee that it is a singleton. Instead, use
     * {@link #isEmpty()}.
     *
     * @return  an empty {@code Properties}
     */
    public static Properties empty() {
        return EMPTY;
    }

    /**
     * Creates a new instance of the {@link Properties} from given {@link InputStream}.
     *
     * @implNote
     * This implementation does not close given input stream. It is a task of a caller, to close given input stream in
     * order to avoid resource leak.
     *
     * @param   in an input stream to read in order get properties with values.
     * @return  a new instance of the {@link Properties}.
     * @throws  IllegalArgumentException if the input stream contains a malformed Unicode escape sequence.
     * @throws  NullPointerException if given input stream {@code in} is {@code null}.
     * @throws  UncheckedIOException if an error occurred when reading from the input stream.
     */
    public static Properties newProperties(final InputStream in) {
        return newProperties(in, (Map<String, String>)null);
    }

    /**
     * Creates a new instance of the {@link Properties} from given {@link InputStream} with default values.
     *
     * @implNote
     * This implementation does not close given input stream. It is a task of a caller, to close given input stream in
     * order to avoid resource leak.
     *
     * @param   in an input stream to read in order get properties with values.
     * @param   defaults a property list that contains default values for any keys not found in this property list.
     * @return  a new instance of the {@link Properties}.
     * @throws  IllegalArgumentException if the input stream contains a malformed Unicode escape sequence.
     * @throws  NullPointerException if given input stream {@code in} is {@code null}.
     * @throws  UncheckedIOException if an error occurred when reading from the input stream.
     */
    public static Properties newProperties(final InputStream in, final Map<String, String> defaults) {
        final var properties = new java.util.Properties();

        try {
            properties.load(requireNonNull(in, "Cannot create properties from null input stream"));
        } catch (final IOException e) {
            throw new UncheckedIOException(e.getMessage(), e);
        }

        if (null == defaults || defaults.isEmpty()) {
            // properties is a Map<Object,Object>, while we expect Map<String,String>
            // with the code below, we do type transformation from Map<Object,Object> to Map<String,String>
            return new Properties(properties.entrySet().stream()
                .collect(toUnmodifiableMap(e -> valueOf(e.getKey()), e -> valueOf(e.getValue()))));
        }

        final var values = new HashMap<>(defaults);

        properties.forEach((k, v) -> values.put(valueOf(k), valueOf(v)));
        return new Properties(copyOf(values));
    }

    /**
     * Creates a new instance of the {@link Properties} from given {@link InputStream} with default values.
     *
     * @implNote
     * This implementation does not close given input stream. It is a task of a caller, to close given input stream in
     * order to avoid resource leak.
     *
     * @param   in an input stream to read in order get properties with values.
     * @param   defaults a properties that contains default values.
     * @return  a new instance of the {@link Properties}.
     * @throws  IllegalArgumentException if the input stream contains a malformed Unicode escape sequence.
     * @throws  NullPointerException if given input stream {@code in} is {@code null}.
     * @throws  UncheckedIOException if an error occurred when reading from the input stream.
     */
    public static Properties newProperties(final InputStream in, final Properties defaults) {
        return newProperties(in, requireNonNullElse(defaults, EMPTY).props);
    }

    private final Map<String, String> props;

    /**
     * Creates an instance of class @{code Properties}.
     */
    private Properties(final Map<String, String> properties) {
        this.props = properties;
    }

    /* (non-Javadoc)
     * @see java.util.Map#get(java.lang.Object)
     */
    public String get(final String key) {
        return getOrDefault(key, (String)null);
    }

    /* (non-Javadoc)
     * @see java.util.Map#getOrDefault(java.lang.Object, java.lang.Object)
     */
    public String getOrDefault(final String key, final String defaultValue) {
        return this.props.getOrDefault(key, defaultValue);
    }

    /**
     * Returns the value to which the specified key is mapped, or calls given {@code default value supplier} if this
     * map contains no mapping for the key.
     *
     * @param   key the key whose associated value is to be returned.
     * @param   defaultValueSupplier the default mapping supplier of the key.
     * @return  the value to which the specified key is mapped, or {@code defaultValueSupplier} will be invoked if this
     *          map contains no mapping for the key.
     * @throws  NullPointerException if the specified key is {@code null} or default value supplier is {@code null}, if
     *          no mapping for the given key.
     */
    public String getOrDefault(final String key, final Supplier<String> defaultValueSupplier) {
        final var value = this.props.get(key);

        if (null == value) {
            return requireNonNull(defaultValueSupplier, () ->
                "Cannot invoke null default value supplier for specified key '" + key + "'").get();
        }
        return value;
    }

    /**
     * Returns {@code true} if this properties contains no key-value mappings.
     *
     * @return {@code true} if this properties contains no key-value mappings
     */
    public boolean isEmpty() {
        return this.props.isEmpty();
    }

    /**
     * Returns a sequential {@code Stream} with this collection as its source.
     *
     * @implSpec
     * This implementation creates a sequential {@code Stream} from the collection's {@code Spliterator}.
     *
     * @return  a sequential {@code Stream} over the elements in this collection.
     */
    public Stream<Entry<String, String>> stream() {
        return this.props.entrySet().stream();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return this.props.toString();
    }

}