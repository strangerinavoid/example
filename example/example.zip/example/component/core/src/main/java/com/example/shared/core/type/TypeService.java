package com.example.shared.core.type;

/**
 * The {@code TypeService} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface TypeService<T> extends Type<T> {

    /**
    *
    * @return
    */
   String name();

   /**
    *
    * @return
    */
   Class<T> type();

}