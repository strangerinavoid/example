package com.example.shared.core;

import java.util.function.Function;

/**
 * The {@code ServiceSupplierFactory} is a function that uses given service class to create and return a new instance
 * of {@link ServiceSupplier}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@FunctionalInterface
public interface ServiceSupplierFactory<S> extends Function<Class<S>, ServiceSupplier<S>> {}