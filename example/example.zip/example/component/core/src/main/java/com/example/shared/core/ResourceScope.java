package com.example.shared.core;

import static java.nio.file.Files.newInputStream;
import static java.nio.file.StandardOpenOption.READ;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Function;

/**
 * The {@code ResourceScope} enumeration reflects all known scopes for application resources.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public enum ResourceScope {

    NONE(v -> null),

    CLASSPATH(v -> {
        final var value = v.substring(10); // classpath:

        return ResourceScope.class.getClassLoader().getResourceAsStream(value);
    }),

    FILE(v -> {
        final var value = v.substring(5);  // file:
        final var path = Path.of(value);

        try {
            return newInputStream(path, READ);
        } catch (final IOException e) {
            throw new UncheckedIOException(e.getMessage(), e);
        }
    }),

    URL(v -> {
        final var value = v.substring(4);  // url:

        try {
            return new URL(value).openStream();
        } catch (final IOException e) {
            throw new UncheckedIOException(e.getMessage(), e);
        }
    });

    public static Optional<ResourceScope> of(final String resource) {
        for (final var value : values()) {
            if (value.isSupported(resource)) {
                return Optional.of(value);
            }
        }
        return Optional.empty();
    }

    private final Function<String, InputStream> bridge;

    /**
     * Creates an instance of class @{code ResourceScope}.
     *
     * @param   bridge a function that use given string (resource name) as a link to the resource and returns an
     *          instance of {@link InputStream}.
     */
    ResourceScope(final Function<String, InputStream> bridge) {
        this.bridge = bridge;
    }

    /**
     * Gets an enumeration element name in a lower case.
     *
     * @return  an enumeration element name in a lower case.
     */
    public String alias() {
        return name().toLowerCase();
    }

    /**
     * Tests if specified resource name is supported by this enumeration element.
     *
     * @param   resource the resource name.
     * @return  {@code true} if given resource name is supported; otherwise returns {@code false}.
     */
    public boolean isSupported(final String resource) {
        return this == NONE && null == resource
            || nonNull(resource) && resource.trim()
                .toLowerCase()
                .startsWith(alias() + ":");
    }

    /**
     * Takes given resource name as link to the resource and tries to open {@link InputStream}. This method never
     * returns {@code null}, but returns {@link Optional}. In case when {@link InputStream} cannot be open, an
     * {@link Optional#empty()} is returned.
     *
     * @param   resource the resource name.
     * @return  an {@link Optional} with {@link InputStream} or {@link Optional#empty()} if {@link InputStream} cannot
     *          be opened.
     */
    public Optional<InputStream> open(final String resource) {
        return Optional.ofNullable(resource).map(this.bridge);
    }

    /**
     * Converts given raw resource name into a resource name with embedded resource type. The returned resource name
     * can be verified later using {@link #isSupported(String)} method.
     *
     * @param   resource the raw resource name.
     * @return  the resource name with resource type.
     */
    public String resolve(final String resource) {
        return alias()
            + ":"
            + requireNonNull(resource, "Unable to construct a path for given null value").trim();
    }

}