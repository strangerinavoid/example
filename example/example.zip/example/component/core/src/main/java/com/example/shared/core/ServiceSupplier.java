package com.example.shared.core;

import java.util.ServiceLoader.Provider;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * The {@code ServiceSupplier} is a functional interface that used to create and return a stream of {@link Provider}
 * for all known implementations of a certain service.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@FunctionalInterface
public interface ServiceSupplier<S> extends Supplier<Stream<Provider<S>>> {}