package com.example.shared.core.property;

import static java.lang.Short.MAX_VALUE;
import static java.lang.String.format;
import static java.lang.System.getProperty;
import static java.lang.System.getenv;
import static java.lang.System.setProperty;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElseGet;

import java.security.PrivilegedAction;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * The {@code Property} class is a representation of the {@code System} property or environment variable.
 * <p>
 * The class provides simple {@link #get()} and {@link #set(String)} methods to access the property value or to set or
 * modify such value.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Property {

    /**
     * An instance of function that creates privileged action, used to read property and environment property values.
     * <p>
     * This function uses {@link System#getProperties() system properties} as primary source and in case when value is
     * missing, it tries to read value from {@link System#getenv() system environment}.
     */
    private static final Function<String, PrivilegedAction<String>> GET_PROPERTY_FUNCTION =
        property -> () -> requireNonNullElseGet(getProperty(property), () -> getenv(property));

    /**
     * An instance of function that creates privileged action, used to read property and environment property values.
     */
    private static final BiFunction<String, String, PrivilegedAction<String>> SET_PROPERTY_FUNCTION =
        (property, value) -> () -> setProperty(property, value);

    /**
     * An array of all names that assigned to this properties. The names from this array will be used to scan System
     * properties and environment for an available value.
     */
    private final String[] names;

    /**
     * Creates an instance of class @{code Property}.
     *
     * @param   name the name of the property.
     * @throws  NullPointerException if given name is {@code null}.
     */
    public Property(final String name) {
        this.names = new String[] {requireNonNull(name)};
    }

    /**
     * Creates an instance of class @{code Property}.
     *
     * @param   names the list of names that associated with this property. The value will be checked according to the
     *          order of the given names. If value of the N's name is available, the N+1 name is ignored.
     * @throws  NullPointerException if given list of names is {@code null} or list contains {@code null} values.
     * @throws  IllegalArgumentException if given list of names is empty.
     */
    public Property(final String... names) {
        final var len = requireNonNull(names, "Cannot create a new property from null names").length;

        if (0 == len) {
            throw new IllegalArgumentException("Cannot create a nameless property");
        }

        this.names = new String[len];

        for (var i = 0; i < len; i++) {
            this.names[i] = requireNonNull(names[i], "Cannot use null property name under index " + i);
        }
    }

    /**
     * Gets the system property/environment variable indicated by this property.
     * <p>
     * This method attempts to get value by calling {@link System#getProperty(String)} using known names and in case of
     * missing value it tries to get value from environment by calling {@link System#getenv(String)} (an environment
     * variable is a system-dependent external named value). If value is still missing, then this method returns
     * {@code null}.
     *
     * @implNote
     * Since property can have multiple names, this method iterates over known names in accordance with initial order
     * (specified in the constructor) and returns first non-null value. In order to get value it executes
     * {@link #GET_PROPERTY_FUNCTION} for each known name with a security manager, if any, until non-null value is
     * obtained or all known names will be used.
     * <p>
     * <a id="EnvironmentVSSystemProperties"><i>System properties</i> and <i>environment variables</i></a> are both
     * conceptually mappings between names and values. Both mechanisms can be used to pass user-defined information to
     * a Java process. Environment variables have a more global effect, because they are visible to all descendants of
     * the process which defines them, not just the immediate Java subprocess. They can have subtly different
     * semantics, such as case insensitivity, on different operating systems. For these reasons, environment variables
     * are more likely to have unintended side effects. It is best to use system properties where possible. Environment
     * variables should be used when a global effect is desired, or when an external system interface requires an
     * environment variable (such as {@code PATH}).
     * <p>
     * On UNIX systems the alphabetic case of {@code envProperty} is typically significant, while on Microsoft Windows
     * systems it is typically not. The expression {@code System.getenv("FOO").equals(System.getenv("foo"))} is
     * likely to be {@code true} on Microsoft Windows.
     * <p>
     * Any discovered value is verified against the maximum length to avoid possible breach, as mentioned in
     * <a href="https://cwe.mitre.org/data/definitions/20.html">CWE-20</a>.
     *
     * @return  the string value for this property, or {@code null} if the value is not defined in the system
     *          properties and environment.
     * @throws  SecurityException if a security manager exists and its {@code checkPropertyAccess} method doesn't allow
     *          access to the specified system property.
     * @throws  NullPointerException if {@code property} or {@code envProperty} is {@code null}.
     * @throws  IllegalArgumentException if value length exceeds {@link Short#MAX_VALUE}.
     */
    public String get() {
        return getOrDefault(() -> null);
    }

    /**
     * Gets the system property/environment variable indicated by this property.
     * <p>
     * This method attempts to get value by calling {@link System#getProperty(String)} using {@code property} and in
     * the case of missing value it tries to get value by calling {@link System#getenv(String)} using environment
     * variable name from {@code envProperty} (an environment variable is a system-dependent external named value). If
     * value is still missing, then this method takes a specified <b>defaultValue</b>, which can be {@code null}.
     *
     * @implNote
     * Since property can have multiple name, this method iterates over known names in according to the initial order
     * (specified in the constructor) and returns first non-null value.
     *
     * @param   property the name of the system property.
     * @param   envProperty the name of the environment variable.
     * @param   defaultValue a default value.
     * @return  the string value of the variable, or {@code null} if the variable is not defined in the system
     *          properties and environment, and specified default value is {@code null} either.
     * @throws  SecurityException if a security manager exists and its {@code checkPropertyAccess} method doesn't allow
     *          access to the specified system property.
     * @throws  NullPointerException if {@code property} or {@code envProperty} is {@code null}.
     * @throws  IllegalArgumentException if {@code property} or {@code envProperty} is empty, or if value length
     *          exceeds {@link Short#MAX_VALUE}.
     */
    public String getOrDefault(final String defaultValue) {
        return getOrDefault(() -> defaultValue);
    }

    /**
     * Gets the system property indicated by the specified property name.
     * <p>
     * This method attempts to get value by calling {@link System#getProperty(String)} using known names and in case of
     * missing value it tries to get value from environment by calling {@link System#getenv(String)} (an environment
     * variable is a system-dependent external named value). If value is still missing, then this method takes a
     * specified {@code defaultValue}, which can be {@code null}.
     * <p>
     * This method uses specified
     *
     * @implNote
     * Calls {@link #getProperty(String, String, String)} and wraps an {@link IllegalArgumentException} with the call
     * of given {@code handler}. In case of {@link IllegalArgumentException} this method returns {@code defaultValue}.
     *
     * @param   defaultValue a default value.
     * @param   handler an {@link IllegalArgumentException} handler.
     * @return  the string value of the variable, or {@code null} if the variable is not defined in the system
     *          properties and environment, and specified default value is {@code null} either.
     * @throws  SecurityException if a security manager exists and its {@code checkPropertyAccess} method doesn't allow
     *          access to the specified system property.
     * @throws  NullPointerException if {@code property} or {@code envProperty} is {@code null}.
     */
    public String getOrDefault(final String defaultValue, final Consumer<IllegalArgumentException> handler) {
        try {
            return getOrDefault(() -> defaultValue);
        } catch (final IllegalArgumentException e) {
            requireNonNull(handler, "Exception handler cannot be null").accept(e);
        }
        return defaultValue;
    }

    /**
     * Gets the system property indicated by the specified property name.
     * <p>
     * This method attempts to get value by calling {@link System#getProperty(String)} using known names and in case of
     * missing value it tries to get value from environment by calling {@link System#getenv(String)} (an environment
     * variable is a system-dependent external named value). If value is still missing, then this method takes a
     * specified default value supplier in order to calculate default value for this property.
     *
     * @param   defaultValueSupplier a default value supplier.
     * @return  the string value of this property, or {@code null} if no value is defined in the system properties and
     *          environment for all known names, and specified default value supplier gives {@code null} as default
     *          value.
     * @throws  SecurityException if a security manager exists and its {@code checkPropertyAccess} method doesn't allow
     *          access to the specified system property or environment property.
     * @throws  NullPointerException if {@code defaultValueSupplier} is {@code null}.
     */
    public String getOrDefault(final Supplier<String> defaultValueSupplier) {
        for (final var name : this.names) {
            final var value = GET_PROPERTY_FUNCTION.apply(name).run();

            if (null == value) {
                continue;
            }

            // check for the length of the argument (assume that under given property we can get harmful value in order
            // to hack our application (see https://cwe.mitre.org/data/definitions/20.html for details)
            if (value.length() > MAX_VALUE) {
                // assume that we have harmful value that cannot be processed and must be ignored
                throw new IllegalArgumentException(format("An invalid value has been specified as part of System "
                    + "properties or environment. The value of the property '%s' will be ignored, since it has too "
                    + "many characters", name));
            }
            return value;
        }
        // nothing configured
        return requireNonNull(defaultValueSupplier, "Cannot get default value from null supplier").get();
    }

    /**
     * Sets this system property.
     *
     * First, if a security manager exists, its {@code SecurityManager.checkPermission} method is called with a
     * {@code PropertyPermission(key, "write")} permission. This may result in a {@link SecurityException} being thrown.
     * If no exception is thrown, the specified property is set to the given value.
     *
     * @apiNote
     * <strong>Changing a standard system property may have unpredictable results unless otherwise specified</strong>.
     * See {@linkplain #get} for details.
     *
     * @param      value the value of the system property.
     * @return     the previous value of the system property, or {@code null} if it did not have one.
     * @throws     SecurityException if a security manager exists and its {@code checkPermission} method doesn't allow
     *             setting of the specified property.
     * @throws     NullPointerException if {@code value} is {@code null}.
     *
     * @see        #get
     */
    public String set(final String value) {
        // always use the first property name to setup the new value
        return SET_PROPERTY_FUNCTION.apply(this.names[0], value).run();
    }

}