package com.example.shared.core;

import java.util.function.Consumer;

/**
 * The {@code ServiceFailureCallback} is a type of consumer that used to consume errors while creating instances of
 * services.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@FunctionalInterface
public interface ServiceFailureCallback extends Consumer<Throwable> {}