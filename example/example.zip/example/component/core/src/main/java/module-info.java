module example.shared.core {

     exports com.example.shared.core;
     exports com.example.shared.core.property;
     exports com.example.shared.core.type;

}