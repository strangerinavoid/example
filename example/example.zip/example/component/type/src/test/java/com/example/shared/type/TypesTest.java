package com.example.shared.type;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

import com.example.shared.core.type.Types;

/**
 * The {@code TypesTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class TypesTest {

    @Test
    void testOfTypeClass() {
        final var type = assertDoesNotThrow(() -> Types.ofType(String.class));

        assertNotNull(type);
    }

    @Test
    void testOfTypeString() {
        fail("Not yet implemented");
    }

}