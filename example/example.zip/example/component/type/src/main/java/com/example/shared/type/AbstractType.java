package com.example.shared.type;

import com.example.shared.core.type.TypeService;
import com.example.shared.logging.LogAware;

/**
 * The {@code AbstractType} class is the base class for type conversion classes.
 * <p>
 * The class defines an abstract method for converting one type to another. An instance of a class inherited from this
 * abstract class must be immutable and cacheable.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public abstract class AbstractType<T> implements LogAware, TypeService<T> {

    private final Class<T> typeClass;

    /**
     * Creates an instance of class {@code AbstractType}.
     *
     * @param   typeClass a type of type transformer.
     */
    protected AbstractType(final Class<T> typeClass) {
        this.typeClass = typeClass;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T as(final Object o) {
        if (null == o) {
            return null;
        }
        if (this.typeClass.isAssignableFrom(o.getClass())) {
            return TypeService.super.as(o);
        }
        return transform(o);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String name() {
        return this.typeClass.getName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Class<T> type() {
        return this.typeClass;
    }

    /**
     * Converts the specified object of an arbitrary type to an object of a specific type.
     * <p>
     * The specified object can be a value object or a meta-object that contains the value to transform and the
     * required attributes for correct transformation. This is necessary for complex transformations, for example, it
     * can be useful for localized data such as {@code Date} or {@code Money}, or some complex values such as phone
     * numbers, etc. This approach requires support in type converters for the corresponding meta-objects.
     *
     * @param   value an object to transform.
     * @return  transformed object.
     * @throws  Exception in case when correct type transformation is impossible.
     */
    protected abstract T transform(final Object o);

}