package com.example.shared.type.text;

import static java.lang.String.valueOf;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UncheckedIOException;

import com.example.shared.type.AbstractType;

/**
 * The class {@code StringType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link String} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     String
 * @see     Type
 */
public final class StringType extends AbstractType<String> {

    /**
     * Creates an instance of class {@code StringType}.
     */
    public StringType() {
        super(String.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String transform(final Object o) {
        if (o instanceof final byte[] b) {
            return new String(b, UTF_8);
        }
        if (o instanceof final InputStream i) {
            try (i) {
                return new String(i.readAllBytes(), UTF_8);
            } catch (final IOException e) {
                throw new UncheckedIOException("An unexpected exception occurred while trying to convert input stream "
                    + "to a string value", e);
            }
        }
        if (o instanceof final Throwable th) {
            try (final var sw = new StringWriter()) {
                try (final var pw = new PrintWriter(sw)) {
                    th.printStackTrace(pw);
                }
                return sw.toString();
            } catch (final IOException e) {
                throw new UncheckedIOException("An unexpected exception occurred while trying to convert throwable to "
                    + "a string value", e);
            }
        }
        return valueOf(o); // try convert object to string
    }

}