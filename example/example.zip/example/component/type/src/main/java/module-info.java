import com.example.shared.core.type.TypeService;
import com.example.shared.type.numeric.LongType;
import com.example.shared.type.special.BooleanType;
import com.example.shared.type.special.UuidType;
import com.example.shared.type.text.CharacterType;
import com.example.shared.type.text.StringType;

module example.shared.type {

     exports com.example.shared.type;

     exports com.example.shared.type.numeric to example.shared.core;
     exports com.example.shared.type.special to example.shared.core;
     exports com.example.shared.type.text to example.shared.core;

    requires example.shared.core;
    requires example.shared.logging;
    requires example.shared.utils;

        uses TypeService;

    provides TypeService
        with LongType, BooleanType, UuidType, CharacterType, StringType;

}