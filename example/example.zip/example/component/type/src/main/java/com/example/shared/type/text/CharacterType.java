package com.example.shared.type.text;

import com.example.shared.type.AbstractType;

/**
 * The class {@code CharacterType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link Character} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Type
 */
public final class CharacterType extends AbstractType<Character> {

    /**
     * Creates an instance of class {@code CharacterType}.
     */
    public CharacterType() {
        super(Character.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Character transform(final Object o) {
        if (o instanceof final Boolean b) {
            return (char)(b ? 1 : 0);
        }
        if (o instanceof final Number n) {
            return (char)n.shortValue();
        }
        if (o instanceof final String s) {
            // due no standard strategy for extracting character from the string value, we just getting the first
            // character from a specified string
            return s.charAt(0);
        }
        throw new ClassCastException("Illegal cast operation for class ["
            + o.getClass().getName()
            + "]");
    }

}