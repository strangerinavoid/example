package com.example.shared.type.special;

import static java.lang.String.valueOf;

import java.util.UUID;

import com.example.shared.type.AbstractType;

/**
 * The class {@code UuidType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link UUID} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     UUID
 * @see     Type
 */
public final class UuidType extends AbstractType<UUID> {

    /**
     * Creates an instance of class {@code UuidType}.
     */
    public UuidType() {
        super(UUID.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected UUID transform(final Object o) {
        if (o instanceof final Number n) {
            return new UUID(n.longValue(), 0L);
        }
        if (o instanceof final String s) {
            return UUID.fromString(s);
        }
        return UUID.fromString(valueOf(o)); // try convert object to string and then parse it as uuid
    }

}