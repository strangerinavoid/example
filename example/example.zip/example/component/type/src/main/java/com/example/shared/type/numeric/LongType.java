package com.example.shared.type.numeric;

import static java.lang.Long.parseLong;
import static java.lang.String.valueOf;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

import com.example.shared.type.AbstractType;

/**
 * The class {@code LongType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link Long} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Long
 * @see     Type
 */
public final class LongType extends AbstractType<Long> {

    /**
     * Creates an instance of class {@code LongType}.
     */
    public LongType() {
        super(Long.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Long transform(final Object o) {
        if (o instanceof final Number n) {
            return n.longValue();
        }
        if (o instanceof final String s) {
            return parseLong(s);
        }
        if (o instanceof final Instant i) {
            return i.toEpochMilli();
        }
        if (o instanceof final Date d) {
            return d.getTime();
        }
        if (o instanceof final Duration d) {
            return d.toMillis();
        }
        return parseLong(valueOf(o)); // try convert object to string and then parse it as long
    }

}