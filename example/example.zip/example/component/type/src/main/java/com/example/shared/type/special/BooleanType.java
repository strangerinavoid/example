package com.example.shared.type.special;

import static java.lang.Boolean.parseBoolean;
import static java.lang.String.valueOf;

import com.example.shared.type.AbstractType;

/**
 * The class {@code BooleanType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link Boolean} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     Boolean
 * @see     Type
 */
public final class BooleanType extends AbstractType<Boolean> {

    /**
     * Creates an instance of class {@code BooleanType}.
     */
    public BooleanType() {
        super(Boolean.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Boolean transform(final Object o) {
        if (o instanceof final Number n) {
            return n.longValue() != 0L;
        }
        if (o instanceof final String s) {
            return parseBoolean(s);
        }
        return parseBoolean(valueOf(o)); // try convert object to string and then parse it as boolean
    }

}