package com.example.shared.boot.internal;

import static java.lang.Runtime.getRuntime;
import static java.lang.String.valueOf;
import static java.lang.System.err;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static java.util.ServiceLoader.load;

import static com.example.shared.core.Services.load;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.example.shared.boot.Boot;
import com.example.shared.boot.BootEntry;
import com.example.shared.boot.BootError;
import com.example.shared.logging.LogAware;

/**
 * The {@code BootImpl} class is an bootstrap application that starts application.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
final class BootImpl implements AutoCloseable, Boot, LogAware {

    /**
     * The {@code CodeImpl} an internal implementation of the {@link Code} interface.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private static final class CodeImpl implements Code {

        private final AtomicBoolean defined = new AtomicBoolean();
        private final AtomicInteger holder = new AtomicInteger();

        /**
         * Defines the status.
         */
        public void define() {
            this.defined.compareAndSet(false, true);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public int get() {
            final var code = this.holder.get();

            if (this.defined.compareAndSet(false, false)) {
                throw new IllegalStateException("An application exit code is undefined");
            }
            return code;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean isDefined() {
            return this.defined.get();
        }

        /**
         * Sets the new exit code value.
         *
         * @param   code the new value to assign.
         */
        public void set(final int code) {
            final var oldCode = this.holder.get();

            if (this.defined.compareAndSet(false, false)) {
                if (this.holder.compareAndSet(oldCode, code)) {
                    return;
                }
                throw new IllegalStateException("Concurrent application exit code modification detected");
            }
            throw new IllegalStateException("Unable to overwrite defined application exit code");
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            return valueOf(get());
        }

    }

    private static final int EXIT_CODE_SUCCESS = 0;
    private static final int EXIT_CODE_RUNNING = 10;
    private static final int EXIT_CODE_MISSING_ENTRY = 100;
    private static final int EXIT_CODE_UNKNOWN_ERROR = 999;

    /**
     * The banner of the application.
     */
    private final String banner;

    /**
     * The status code.
     */
    private final CodeImpl code;

    /**
     * The entry class of the application.
     */
    private final Class<?> entry;

    /**
     * The environment configuration of the application.
     */
    private final Environment environemnt;

    /**
     * The name of the application.
     */
    private final String name;

    /**
     * A flag of running application.
     */
    private final AtomicBoolean running;

    /**
     * Creates an instance of class {@code BootImpl}.
     *
     * @param   builder the boot builder instance.
     */
    BootImpl(final BootBuilderImpl builder) {
        this.code = new CodeImpl();
        this.name = requireNonNull(builder.name, "Unable to create a bootstrap for the application with null name");
        this.banner = builder.banner; // optional
        this.environemnt = builder.environment; // optional
        this.entry = builder.entry; // cannot be null, since always has default value (check the builder)
        this.running = new AtomicBoolean();
    }

    /**
     * Propagates the given exit code to the operating system if given code not equals with zero.
     *
     * @param   code the exit code to publish.
     */
    @Override
    public void close() {
        if (this.running.compareAndSet(true, false)) {
            this.code.define();

            log().info("BOOT: Application stopped with exit code %s.", this.code);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Code code() {
        return this.code;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void exit() {
        getRuntime().exit(this.code.get()); // use system exit to propagate error code
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isRunning() {
        return this.running.get();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Boot run(final String[] args) {
        try (var boot = open()) {
            try {
                if (null == this.environemnt) {
                    log().info("BOOT: Application environment initializer is missing. Starting with the defaults...");
                } else if (this.environemnt.init()) {
                    log().info("BOOT: Application environment initialized successfully.");
                } else {
                    log().info("BOOT: The application environment was initialized with errors.");
                }

                this.code.set(execute(args));
            } catch (final BootError e) {
                if (EXIT_CODE_SUCCESS == e.getErrorCode()) {
                    return this; // normal exit
                }
                this.code.set(e.getErrorCode());
            } catch (final Exception e) {
                log().error("BOOT: An unknown exception occurred while the application was running: %s", e.getMessage())
                    .debug("BOOT: An unknown exception details:", e);

                this.code.set(EXIT_CODE_UNKNOWN_ERROR); // unknown exception
            }
        }
        return this;
    }

    private void banner() throws IOException {
        if (nonNull(this.banner)) {
            try (final var in = this.entry.getClassLoader().getResourceAsStream(this.banner)) {
                if (nonNull(in)) {
                    final var text = new String(in.readAllBytes(), UTF_8);

                    if (!text.isBlank()) {
                        err.println(text);
                    }
                }
            }
        }
    }

    /**
     * Executes the application with the given arguments.
     *
     * @param   args the arguments for the application.
     * @throws  IOException in case of input/output errors.
     */
    private int execute(final String[] args) throws IOException {
        final var opt = load(BootEntry.class, s -> load(s)::stream, provider -> this.entry == provider.type(),
            thrown -> log().error("BOOT: An unexpected error occurred: %s", thrown, thrown.getMessage()));

        if (opt.isEmpty()) {
            log().error("BOOT: Unable to start application with missing application entry %s.", this.entry);
            return EXIT_CODE_MISSING_ENTRY; // a missing application's entry code
        }

        log().info("BOOT: Starting application '%s' with entry %s...", this.name, this.entry);

        banner();

        final var application = opt.get();

        try (var c = application.run(args)) {
            return application.getExitCode();
        }
    }

    private BootImpl open() {
        if (this.running.compareAndSet(false, true)) {
            return this;
        }
        throw new BootError(EXIT_CODE_RUNNING); // unable to start application when it is already running
    }

}