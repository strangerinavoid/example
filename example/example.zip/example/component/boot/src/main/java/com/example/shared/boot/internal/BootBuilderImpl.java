package com.example.shared.boot.internal;

import static java.util.Objects.requireNonNull;

import com.example.shared.boot.Boot;
import com.example.shared.boot.Boot.Builder;
import com.example.shared.boot.Boot.Environment;
import com.example.shared.boot.BootEntry;
import com.example.shared.boot.BootEntryUndefined;

/**
 * The {@code BootBuilderImpl} is a default implementation of the {@link Builder} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class BootBuilderImpl implements Boot.Builder {

    String banner;
    Class<?> entry;
    Boot.Environment environment;
    String name;

    /**
     * Creates an instance of class {@code BootBuilderImpl}.
     */
    public BootBuilderImpl() {
        this.entry = BootEntryUndefined.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Builder banner(final String banner) {
        this.banner = banner;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Boot build() {
        return new BootImpl(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <E extends BootEntry> Builder entry(final Class<E> entry) {
        this.entry = requireNonNull(entry);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Builder environment(final Environment environment) {
        this.environment = environment;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Builder name(final String name) {
        this.name = requireNonNull(name);
        return this;
    }

}