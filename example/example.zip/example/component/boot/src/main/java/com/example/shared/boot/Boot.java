package com.example.shared.boot;

import com.example.shared.boot.internal.BootBuilderImpl;

/**
 * The {@code Boot} interface defines an application bootstrap.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface Boot {

    /**
     * A builder of {@linkplain Boot}.
     * <p>
     * Builders are created by invoking {@link Boot#newBuilder() newBuilder}. Each of the setter methods modifies the
     * state of the builder and returns the same instance. Builders are not thread-safe and should not be used
     * concurrently from multiple threads without external synchronization.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    interface Builder {

        /**
         * Sets the name of the banner resource in the classpath that can be used to print banner in the console.
         *
         * @param   banner the banner resource name in the classpath. The {@code null} value is allowed since this
         *          value is optional.
         * @return  this builder.
         */
        Builder banner(final String banner);

        /**
         * Returns a new {@linkplain Boot} based on the current state of this builder.
         *
         * @return  a new {@code Boot}.
         */
        Boot build();

        /**
         * Sets the application entry point class that used to identify correct entry point instance.
         *
         * @param   entry the class of the application entry point. Cannot be {@code null}.
         * @return  this builder.
         * @throws  NullPointerException if {@code null} value is specified.
         */
        <E extends BootEntry> Builder entry(final Class<E> entry);

        /**
         * Sets the environment that used to prepare all required application's variables and context.
         *
         * @param   environment the environment for the application. The {@code null} value is allowed since this
         *          value is optional.
         * @return  this builder.
         */
        Builder environment(final Environment environment);

        /**
         * Sets the application name that used to identify an application the log.
         *
         * @param   name the name of the application. Cannot be {@code null}.
         * @return  this builder.
         * @throws  NullPointerException if {@code null} value is specified.
         */
        Builder name(final String name);

    }

    /**
     * The {@code Code} interface describes an application exit code.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    interface Code {

        /**
         * Gets the application exit code. If code is undefined then throws an exception.
         *
         * @return  an application exit code.
         * @throws  IllegalStateException when trying to read code with undefined state.
         */
        int get();

        /**
         * Tests if the application exit code is defined.
         *
         * @return  {@code true} if application exit code is defined; otherwise returns {@code false}.
         */
        boolean isDefined();

    }

    /**
     * The {@code Environment} defines an application environment initializer.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    interface Environment {

        /**
         * Setup environment properties from an external source.
         *
         * @return  {@code true} is succeed; otherwise returns {@code false}.
         */
        boolean init();

    }

    /**
     * Creates a new {@code Boot} builder.
     *
     * @return  an {@code Boot.Builder}.
     */
    static Builder newBuilder() {
        return new BootBuilderImpl();
    }

    /**
     * Gets the application exit code. The code can be undefined, but never {@code null}.
     *
     * @return  an application exit code.
     */
    Code code();

    /**
     * Exits from the application with the code. Typically means stop the java virtual machine.
     */
    void exit();

    /**
     * Tests if the application is running.
     *
     * @return  {@code true} if application is running; otherwise returns {@code false}.
     */
    boolean isRunning();

    /**
     * Runs an application, which class specified in the configuration.
     *
     * @param   args the arguments for the application.
     * @return  this bootstrap.
     */
    Boot run(final String[] args);

}