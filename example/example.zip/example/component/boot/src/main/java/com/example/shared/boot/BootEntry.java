package com.example.shared.boot;

import java.io.Closeable;

/**
 * The {@code BootEntry} is an interface that define contract for any boot entry, which could be used as an entry
 * point to an application by {@link Boot boot logic}.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public interface BootEntry {

    /**
     * Returns the exit code that should be returned from the application.
     *
     * @return  the exit code.
     */
    int getExitCode();

    /**
     * Entry method that can be used to run a application from the specified source using default settings.
     *
     * @param   args the application arguments (usually passed from a Java main method).
     * @return  the running {@link Closeable}.
     */
    Closeable run(String... args);

}