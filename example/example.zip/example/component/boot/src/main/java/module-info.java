import com.example.shared.boot.BootEntry;
import com.example.shared.boot.BootEntryUndefined;

module example.shared.boot {

     exports com.example.shared.boot;

    requires transitive example.shared.core;
    requires transitive example.shared.logging;

        uses BootEntry;

    provides BootEntry
        with BootEntryUndefined;

}