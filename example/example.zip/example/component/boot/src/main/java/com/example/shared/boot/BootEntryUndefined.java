package com.example.shared.boot;

import java.io.Closeable;

import com.example.shared.logging.LogAware;

/**
 * The {@code BootEntryUndefined} is a an undefined boot entry implementation. This entry is used if by some reason a
 * real application entry is not provided.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class BootEntryUndefined implements BootEntry, LogAware {

    /**
     * {@inheritDoc}
     */
    @Override
    public int getExitCode() {
        return 90; // undefined boot entry
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Closeable run(final String... args) {
        return () ->
            log().error("BOOT: An application's boot entry is not configured. Please check the configuration.");
    }

}