package com.example.shared.boot;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * The {@code BootError} is a unit test class for {@link BootError} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootErrorTest {

    @Test
    void testGetErrorCode() {
        final var e = assertDoesNotThrow(() -> new BootError(100));

        assertEquals(100, e.getErrorCode());
    }

}