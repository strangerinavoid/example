package com.example.shared.boot;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.Test;

/**
 * The {@code BootEntryTest} is a unit test class for {@link BootEntry} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootEntryTest {

    static class DummyBootEntry implements BootEntry {

        static final AtomicBoolean CLOSED = new AtomicBoolean();

        /**
         * {@inheritDoc}
         */
        @Override
        public int getExitCode() {
            return 0;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Closeable run(final String... args) {
            return () -> CLOSED.compareAndSet(false, true);
        }

    }

    @Test
    void testEntry() {
        final String[] args = {};
        final var boot = assertDoesNotThrow(() -> Boot.newBuilder()
            .entry(DummyBootEntry.class)
            .name("TEST")
            .build());

        assertDoesNotThrow(() -> boot.run(args));
        assertFalse(DummyBootEntry.CLOSED.get());
    }

}