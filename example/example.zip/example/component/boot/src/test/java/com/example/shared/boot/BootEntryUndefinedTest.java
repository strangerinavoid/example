package com.example.shared.boot;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * The {@code BootEntryUndefinedTest} is a unit test class for {@link BootEntryUndefined} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootEntryUndefinedTest {

    @Test
    void testEntry() {
        final String[] args = {};
        final var entry = new BootEntryUndefined();

        assertEquals(90, entry.getExitCode());
        assertDoesNotThrow(() -> entry.run(args));
    }

}