package com.example.shared.boot;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The {@code EmptyBootEntry} an empty boot entry.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class EmptyBootEntry implements BootEntry {

    static final AtomicBoolean CLOSED = new AtomicBoolean();

    /**
     * {@inheritDoc}
     */
    @Override
    public int getExitCode() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Closeable run(final String... args) {
        return this::close;
    }

    /**
     * Marks this entry as closed and returns confirmation result.
     */
    protected boolean close() {
        return CLOSED.compareAndSet(false, true);
    }

}