package com.example.shared.boot;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.example.shared.boot.internal.BootBuilderImpl;

/**
 * The {@code BootTest} is a unit test class for {@link Boot} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootTest {

    @Test
    void testNewBuilder() {
        final var builder = assertDoesNotThrow(Boot::newBuilder);

        assertNotNull(builder);
        assertEquals(BootBuilderImpl.class, builder.getClass());
    }

}