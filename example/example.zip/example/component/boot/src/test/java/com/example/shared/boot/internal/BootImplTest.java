package com.example.shared.boot.internal;

import static java.util.stream.Collectors.toUnmodifiableList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

import com.example.shared.boot.Boot;
import com.example.shared.boot.Boot.Builder;
import com.example.shared.boot.BootError;
import com.example.shared.boot.EmptyBootEntry;

/**
 * The {@code BootImplTest} is a unit test class for {@link BootImpl} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootImplTest {

    private static final String DUMMY_NAME = "dummy";
    private static final AtomicInteger counter = new AtomicInteger();

    @Test
    void testNew() {
        final var env = new AtomicBoolean();

        testBoot(() -> new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true))
            .banner("banner"), 90);

        assertTrue(env.get());
    }

    @Test
    void testNewConcurrent() {
        final String[] args = {};
        final var env = new AtomicBoolean();
        final var builder = new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true))
            .banner("bannerUnknown");
        final var boot = assertDoesNotThrow(builder::build);
        final var latch = new CountDownLatch(2);
        final var codes = new HashSet<Integer>();

        final Runnable task = () -> {
            latch.countDown();

            try {
                latch.await();
                boot.run(args);

                assertTrue(env.get());
                assertFalse(boot.isRunning());
                assertTrue(boot.code().isDefined());
                assertEquals(90, boot.code().get());

                codes.add(boot.code().get());
            } catch (final BootError e) {
                assertEquals(10, e.getErrorCode());

                codes.add(e.getErrorCode());
            } catch (final InterruptedException e) {
                fail("Cannot continue with interrupted test");
            }
        };

        Stream.of(newWorker(task), newWorker(task))
            .map(w -> {
                w.start();
                return w;
            })
            .collect(toUnmodifiableList())
            .forEach(w -> {
                try {
                    w.join();
                } catch (final InterruptedException e) {
                    fail("Cannot continue with interrupted test");
                }
            });

        assertEquals(Set.of(10, 90), Set.copyOf(codes));
    }

    @Test
    void testNewWithEmptyBanner() {
        final var env = new AtomicBoolean();

        testBoot(() -> new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true))
            .banner("empty"), 90);

        assertTrue(env.get());
    }

    @Test
    void testNewWithNullBanner() {
        final var env = new AtomicBoolean();

        testBoot(() -> new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true)), 90);

        assertTrue(env.get());
    }

    @Test
    void testNewWithNullEntry() {
        final var builder = new BootBuilderImpl();

        builder.name(DUMMY_NAME);
        builder.entry = null;

        final var boot = assertDoesNotThrow(builder::build);

        assertNotNull(boot);
    }

    @Test
    void testNewWithNullName() {
        final var builder = new BootBuilderImpl();
        final var ex = assertThrows(NullPointerException.class, builder::build);

        assertEquals("Unable to create a bootstrap for the application with null name", ex.getMessage());
    }

    @Test
    void testNewWithUnknownEntry() {
        final var env = new AtomicBoolean();

        testBoot(() -> new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true))
            .entry(EmptyBootEntry.class)
            .banner("empty"), 100);

        assertTrue(env.get());
    }

    @Test
    void testRunTwice() {
        final var env = new AtomicBoolean();
        final var boot = testBoot(() -> new BootBuilderImpl()
            .name(DUMMY_NAME)
            .environment(() -> env.compareAndSet(false, true)), 90);

        assertTrue(env.get());

        // the second run of the same instance
        final var ex = assertThrows(IllegalStateException.class, () -> boot.run(new String[0]));

        assertEquals("Unable to overwrite defined application exit code", ex.getMessage());
    }

    private Thread newWorker(final Runnable task) {
        final var thread = new Thread(task, "worker-" + counter.incrementAndGet());

        thread.setDaemon(true);
        return thread;
    }

    private Boot testBoot(final Supplier<Builder> supplier, final int code) {
        final String[] args = {};
        final var builder = supplier.get();
        final var boot = assertDoesNotThrow(builder::build);

        assertDoesNotThrow(() -> boot.run(args));
        assertFalse(boot.isRunning());
        assertTrue(boot.code().isDefined());
        assertEquals(code, boot.code().get());

        return boot;
    }

}