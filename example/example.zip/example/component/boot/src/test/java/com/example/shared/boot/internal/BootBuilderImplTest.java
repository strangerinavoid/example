package com.example.shared.boot.internal;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static com.example.shared.core.type.Type.asType;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.shared.boot.Boot;
import com.example.shared.boot.BootEntry;
import com.example.shared.boot.BootEntryUndefined;

/**
 * The {@code BootBuilderImplTest} is a unit test class for {@link BootBuilderImpl} class.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class BootBuilderImplTest {

    static class DummyBootEntry implements BootEntry {

        static final AtomicBoolean CLOSED = new AtomicBoolean();

        /**
         * {@inheritDoc}
         */
        @Override
        public int getExitCode() {
            return 0;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Closeable run(final String... args) {
            return () -> CLOSED.compareAndSet(false, true);
        }

    }

    private BootBuilderImpl builder;

    @BeforeEach
    void setUp() {
        this.builder = asType(assertDoesNotThrow(Boot::newBuilder));
    }

    @Test
    void testBanner() {
        final var banner = "banner";

        assertNull(this.builder.banner);
        assertDoesNotThrow(() -> this.builder.banner(banner));
        assertEquals(banner, this.builder.banner);
        assertDoesNotThrow(() -> this.builder.banner(null));
        assertNull(this.builder.banner);
    }

    @Test
    void testBuild() {
        final var ex = assertThrows(NullPointerException.class, () -> this.builder.build());

        assertNotNull(ex.getMessage());
    }

    @Test
    void testEntry() {
        assertEquals(BootEntryUndefined.class, this.builder.entry);
        assertDoesNotThrow(() -> this.builder.entry(DummyBootEntry.class));
        assertEquals(DummyBootEntry.class, this.builder.entry);
    }

    @Test
    void testEntryWithNull() {
        final var ex =
            assertThrows(NullPointerException.class, () -> this.builder.entry(null));

        assertNull(ex.getMessage());
    }

    @Test
    void testEnvironment() {
        final var init = new AtomicBoolean();
        final Boot.Environment env = () -> init.compareAndSet(false, true);

        assertNull(this.builder.environment);
        assertDoesNotThrow(() -> this.builder.environment(env));
        assertEquals(env, this.builder.environment);
        assertDoesNotThrow(() -> this.builder.environment(null));
        assertNull(this.builder.environment);
    }

    @Test
    void testName() {
        assertNull(this.builder.name);
        assertDoesNotThrow(() -> this.builder.name("dummy"));
        assertEquals("dummy", this.builder.name);
    }

    @Test
    void testNameWithNull() {
        final var ex = assertThrows(NullPointerException.class, () -> this.builder.name(null));

        assertNull(ex.getMessage());
    }

}