package com.example.shared.error;

import static java.lang.Thread.currentThread;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.ofNullable;

import java.util.Arrays;
import java.util.Formatter;
import java.util.concurrent.Callable;

import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerFactory;

/**
 * The class {@code ServerException} is the superclass of those exceptions that can be thrown during the normal
 * operation of the Java Virtual Machine.
 * <p>
 * A method is not required to declare in its {@code throws} clause any subclasses of {@code ServerException}
 * that might be thrown during the execution of the method but not caught.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     java.lang.Throwable
 * @see     java.lang.RuntimeException
 */
public class ServerException extends RuntimeException {

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = 5639640035928210739L;

    private static final Logger LOGGER = LoggerFactory.getLogger(ServerException.class);

    /**
     *
     * @param   <T>
     * @param   action
     * @return
     */
    public static <T> T wrap(final Callable<T> action) {
        try {
            return action.call();
        } catch (final InterruptedException e) {
            currentThread().interrupt();
            throw new ServerException(e.getMessage(), e);
        } catch (final Exception e) {
            throw new ServerException(e.getMessage(), e);
        }
    }

    /**
     * Returns a formatted string using the specified format string and arguments.
     *
     * @param   message a <a href="../util/Formatter.html#syntax">format string</a>.
     * @param   arguments arguments referenced by the format specifiers in the format string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The number of arguments is variable
     *          and may be zero. The maximum number of arguments is limited by the maximum dimension of a Java array as
     *          defined by <cite>The Java&trade; Virtual Machine Specification</cite>. The behavior on a {@code null}
     *          argument depends on the <a href="../util/Formatter.html#syntax">conversion</a>.
     * @return  a formatted string.
     */
    private static String format(final String message, final Object... arguments) {
        try {
            return ofNullable(arguments)
                .filter(a -> a.length > 0)
                .map(a -> String.format(message, a))
                .orElse(message);
        } catch (final Exception e) {
            LOGGER.error("An error '{}' occurred while trying to format message with given arguments: {}",
                e.getMessage(), Arrays.toString(arguments));
        }
        return message;
    }

    /**
     * Constructs a new {@link ServerException} with the specified detail message. The cause is not initialized, and
     * may subsequently be initialized by a call to {@link #initCause(Throwable)}.
     *
     * @param   message the detail message. The detail message is saved for later retrieval by the
     *          {@link #getMessage()} method.
     * @param   arguments an arguments referenced by the format specifiers in the message string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The number of arguments is variable
     *          and may be zero. The maximum number of arguments is limited by the maximum dimension of a Java array as
     *          defined by <cite>The Java&trade; Virtual Machine Specification</cite>. The behavior on a {@code null}
     *          argument depends on the {@link Formatter} conversion.
     */
    public ServerException(final String message, final Object... arguments) {
        this(message, null, arguments);
    }

    /**
     * Constructs a new {@link ServerException} with the specified detail message and exception cause.
     * <p>
     * Note that the detail message associated with {@code cause} is <i>not</i> automatically incorporated in this
     * exception's detail message.
     *
     * @param   message the detail message. The detail message is saved for later retrieval by the
     *          {@link #getMessage()} method.
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the {@link #getCause()}
     *          method. A {@code null} value is permitted, and indicates that the cause is nonexistent or unknown.
     * @param   arguments an arguments referenced by the format specifiers in the message string. If there are more
     *          arguments than format specifiers, the extra arguments are ignored. The number of arguments is variable
     *          and may be zero. The maximum number of arguments is limited by the maximum dimension of a Java array as
     *          defined by <cite>The Java&trade; Virtual Machine Specification</cite>. The behavior on a {@code null}
     *          argument depends on the {@link Formatter} conversion.
     */
    public ServerException(final String message, final Throwable cause, final Object... arguments) {
        super(ofNullable(message)
            .map(m -> format(m, arguments))
            .or(() -> ofNullable(cause)
                .map(Throwable::getMessage))
            .orElse(null), cause);
    }

    /**
     * Constructs a new {@link ServerException} with the specified cause and a detail message of {@code (cause == null ?
     * null : cause.toString())} (which typically contains the class and detail message of {@code cause}).
     * This constructor is useful for exceptions that are little more than wrappers for other throwables.
     *
     * @param   cause the exception cause. The exception cause is saved for later retrieval by the {@link #getCause()}
     *          method. A {@code null} value is permitted, and indicates that the cause is nonexistent or unknown.
     */
    public ServerException(final Throwable cause) {
        super(requireNonNull(cause, "Cannot create ServerException with null cause").getMessage(), cause);
    }

}