module example.shared.utils {

     exports com.example.shared.error;
     exports com.example.shared.utils;

    requires example.shared.core;
    requires example.shared.logging;

    requires java.desktop;

}