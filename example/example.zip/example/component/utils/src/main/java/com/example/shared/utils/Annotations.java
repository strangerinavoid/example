package com.example.shared.utils;

import static java.util.Objects.requireNonNull;

import static com.example.shared.core.type.Type.asType;
import static com.example.shared.error.ServerException.wrap;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.stream.Stream;

import com.example.shared.logging.Logger;
import com.example.shared.logging.LoggerFactory;

/**
 * The {@code Annotations} class is a utility class that used to avoid direct invocation of the API for annotations.
 * It is used to add in the future a special framework which will make possible add annotations to already compiled
 * classes even if they are from {@code java.lang} package.
 * <p>
 * Usage of the class {@code Annotations} will dramatically reduce time of the refactoring and will gives new
 * features in the future smoothly and without special development in the client classes.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Annotations {

    private static final Logger LOGGER = LoggerFactory.getLogger(Annotations.class);

    /**
     * Empty array of annotations.
     */
    public static final Annotation[] EMPTY_ANNOTATION_ARRAY = {};

    /* (non-Javadoc)
     * @see java.lang.reflect.AnnotatedElement#getAnnotation(java.lang.Class)
     */
    public static <T extends Annotation> T getAnnotation(final AnnotatedElement annotatedElement,
            final Class<T> annotationClass) {
        return annotatedElement.getAnnotation(annotationClass);
    }

    /* (non-Javadoc)
     * @see java.lang.reflect.AnnotatedElement#getAnnotations()
     */
    public static Annotation[] getAnnotations(final AnnotatedElement annotatedElement) {
        return annotatedElement.getAnnotations();
    }

    /**
     *
     * @param   <T>
     * @param   annotation
     * @param   attribute
     * @return
     */
    public static <T> T getAttribute(final Annotation annotation, final String attribute) {
        try {
            return getAttribute(annotation, getAttributePath(attribute));
        } catch (final Exception e) {
            LOGGER.error("CORE: An exception occurred while trying to access attribute '%s' of the annotation [%s]: %s",
                attribute, annotation, e.getMessage(), e);
        }
        return null;
    }

    /* (non-Javadoc)
     * @see java.lang.reflect.AnnotatedElement#getDeclaredAnnotations()
     */
    public static Annotation[] getDeclaredAnnotations(final AnnotatedElement annotatedElement) {
        return annotatedElement.getDeclaredAnnotations();
    }

    /* (non-Javadoc)
     * @see java.lang.reflect.AnnotatedElement#isAnnotationPresent(java.lang.Class)
     */
    public static boolean isAnnotationPresent(final AnnotatedElement annotatedElement,
            final Class<? extends Annotation> annotationClass) {
        return annotatedElement.isAnnotationPresent(annotationClass);
    }

    /**
     * @param   <T>
     * @param   annotation
     * @param   path
     * @return
     */
    private static <T> T getAttribute(final Object object, final List<String> path) throws InvocationTargetException {
        if (null == path || path.isEmpty()) {
            LOGGER.warning("CORE: Unable to use null or empty path to get attribute value.");
            return null;
        }

        final var size = path.size();
        final var cl = requireNonNull(object, "Unable to extract attribute value from null object").getClass();
        final var obj = path.stream()
            .findFirst()
            .map(a -> wrap(() -> cl.getMethod(a).invoke(object)))
            .orElse(null); // if result is null or attribute is missing

        return null == obj || 1 == size ? asType(obj) : asType(getAttribute(obj, path.subList(1, size)));
    }

    /**
     *
     * @param   property
     * @return
     */
    private static List<String> getAttributePath(final String attribute) {
        return Stream.of(attribute.split("\\.")).toList();
    }

    /**
     * Constructor of the class {@code Annotations} was declared as private to prevent its instantiation.
     */
    private Annotations() {
        // this class is a static util class
    }

}