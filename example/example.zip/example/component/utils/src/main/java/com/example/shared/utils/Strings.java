package com.example.shared.utils;

import com.example.shared.core.property.Property;

/**
 * The class {@code Strings} represents a common string utilities.
 *
 * @author  Andrey OCHIROV
 * @version 1.1
 */
public final class Strings {

    /**
     * Empty string.
     */
    public static final String EMPTY_STRING = "".intern();

    /**
     * Empty array of string.
     */
    public static final String[] EMPTY_STRING_ARRAY = {};

    /**
     * This constant contains line separator string.
     */
    public static final String LINE_SEPARATOR = new Property("line.separator").get();

    /**
     * The whitespace.
     */
    public static final String WHITESPACE = " ".intern();

    /**
     * Returns a string that is equivalent to the specified string with its first character converted to upper case as
     * by {@link String#toUpperCase()}. The returned string will have the same value as the specified string if its
     * first character is non-alphabetic, if its first character is already upper case, or if the specified string is
     * of length 0.
     * <p>
     * For example:
     * <pre>
     *     capitalize(&quot;foo bar&quot;).equals(&quot;Foo bar&quot;);
     *     capitalize(&quot;2b or not 2b&quot;).equals(&quot;2b or not 2b&quot;)
     *     capitalize(&quot;Foo bar&quot;).equals(&quot;Foo bar&quot;);
     *     capitalize(&quot;&quot;).equals(&quot;&quot;);
     * </pre>
     *
     * @param   value the string whose first character is to be upper case.
     * @return  a string equivalent to {@code value} with its first character converted to upper case.
     * @throws  NullPointerException if {@code value} is {@code null}.
     *
     * @see     #decapitalize(String)
     */
    public static String capitalize(final String value) {
        if (value.length() == 0) {
            return value;
        }

        final char first = value.charAt(0);
        final char capitalized = Character.toUpperCase(first);

        return first == capitalized ? value : capitalized + value.substring(1);
    }

    /**
     * Returns a string that is equivalent to the specified string with its first character converted to lower case as
     * by {@link String#toLowerCase()}. The returned string will have the same value as the specified string if its
     * first character is non-alphabetic, if its first character is already lower case, or if the specified string is
     * of length 0.
     * <p>
     * For example:
     * <pre>
     *     decapitalize(&quot;Foo bar&quot;).equals(&quot;foo bar&quot;);
     *     decapitalize(&quot;2b or not 2b&quot;).equals(&quot;2b or not 2b&quot;)
     *     decapitalize(&quot;foo bar&quot;).equals(&quot;foo bar&quot;);
     *     decapitalize(&quot;&quot;).equals(&quot;&quot;);
     * </pre>
     *
     * @param   value the string whose first character is to be lower case.
     * @return  a string equivalent to {@code value} with its first character converted to lower case.
     * @throws  NullPointerException if {@code value} is {@code null}.
     *
     * @see     #capitalize(String)
     */
    public static String decapitalize(final String value) {
        if (value.length() == 0) {
            return value;
        }

        final char first = value.charAt(0);
        final char decapitalized = Character.toLowerCase(first);

        return first == decapitalized ? value : decapitalized + value.substring(1);
    }

    /**
     * Clears string from spaces. Special feature of this method consists in converting string to {@code null}, if
     * string is empty or contains only whitespaces.
     *
     * @param   string string to trim.
     * @return  trimmed string or {@code null}.
     */
    public static String trim(final String string) {
        if (string == null) {
            return null;
        }

        final String s = string.trim();

        if (s.length() < 1) {
            return null;
        }
        return s;
    }

    /**
     * Same as {@link #trim(String)} but return specified value instead of {@code null} result.
     *
     * @param   string string to trim.
     * @param   nullValue string for {@code null} result of trim operation.
     * @return  trimmed string or {@code nullValue} in case of {@code null} result.
     */
    public static String trim(final String string, final String nullValue) {
        final String trimmedString = trim(string);

        return trimmedString == null ? nullValue : trimmedString;
    }

    /**
     * Constructor of the class {@code Strings} was declared as private to prevent its instantiation.
     */
    private Strings() {
        // this class is a static util class
    }

}