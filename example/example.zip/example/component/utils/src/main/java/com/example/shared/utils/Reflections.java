package com.example.shared.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * The {@code Reflections} class represents a common utilities class that helps with reflection operations.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Reflections {

    /**
     * Empty array of classes.
     */
    public static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];

    /**
     * Empty array of fields.
     */
    public static final Field[] EMPTY_FIELD_ARRAY = {};

    /**
     * Empty array of methods.
     */
    public static final Method[] EMPTY_METHOD_ARRAY = {};

    /**
     * The name of prefix for every 'get' method like {@code getFirstName}.
     */
    public static final String GETTER_PREFIX = "get";

    /**
     * The name of prefix for every 'is' method like {@code isAuthorized}.
     */
    public static final String IS_PREFIX = "is";

    /**
     * The name of prefix for every 'set' method like {@code setFirstName}.
     */
    public static final String SETTER_PREFIX = "set";

    /**
     *
     * @param   method
     * @return  TODO write correct comment
     */
    public static boolean isGetter(final Method method) {
        return (method.getName().startsWith(GETTER_PREFIX) && method.getName().length() > 3
            || method.getName().startsWith(IS_PREFIX) && method.getName().length() > 2)
            && method.getParameterTypes().length == 0
            && method.getReturnType() != void.class;
    }

    /**
     *
     * @param   method
     * @return  TODO write correct comment
     */
    public static boolean isSetter(final Method method) {
        return method.getName().startsWith(SETTER_PREFIX)
            && method.getName().length() > 3
            && method.getParameterTypes().length == 1;
    }

    /**
     *
     * @param   method
     * @return  TODO write correct comment
     */
    public static String propertyName(final Method method) {
        String name = method.getName();

        if (name.startsWith(IS_PREFIX)) {
            name = Strings.decapitalize(name.substring(2));
        } else if (name.startsWith(GETTER_PREFIX) || name.startsWith(SETTER_PREFIX)) {
            name = Strings.decapitalize(name.substring(3));
        } else {
            name = null;
        }
        return name;
    }

    /**
     * Constructor of the class {@code Reflections} was declared as private to prevent its
     * instantiation.
     */
    private Reflections() {
        // this class is a static util class
    }

}