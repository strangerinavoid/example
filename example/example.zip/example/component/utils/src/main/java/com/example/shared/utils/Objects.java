package com.example.shared.utils;

/**
 * The {@code Objects} class represents a common object utilities.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class Objects {

    /**
     * Empty array of bytes.
     */
    public static final byte[] EMPTY_BYTES_ARRAY = {};

    /**
     *
     * @param   o
     * @return
     */
    public static Class<?> classOf(final Object o) {
        return null == o ? null : o.getClass();
    }

    /**
     * Constructor of the class {@code Objects} was declared as private to prevent its instantiation.
     */
    private Objects() {
        throw new UnsupportedOperationException("Unable to instantiate utility class");
   }

}