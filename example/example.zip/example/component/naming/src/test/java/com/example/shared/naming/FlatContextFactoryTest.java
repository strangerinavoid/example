package com.example.shared.naming;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingSupplier;
import org.junitpioneer.jupiter.SetSystemProperty;

/**
 * The {@code FlatContextFactoryTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@SetSystemProperty(key = Context.INITIAL_CONTEXT_FACTORY, value = "com.example.shared.naming.FlatContextFactory")
class FlatContextFactoryTest {

    @Test
    void newContext() {
        final var ctx = assertDoesNotThrow((ThrowingSupplier<Context>)InitialContext::new);

        assertNotNull(ctx);
        assertDoesNotThrow(() -> ctx.bind("com.example.sid.core.party.IndividualEntity", this));
        assertDoesNotThrow(() -> ctx.unbind("com.example.sid.core.party.IndividualEntity"));
    }

    @Test
    void testGetInitialContext() {
        assertNotNull("Not yet implemented");
    }

}