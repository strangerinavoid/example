package com.example.shared.naming;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.junit.jupiter.api.Test;
import org.junitpioneer.jupiter.SetSystemProperty;

/**
 * The {@code FlatContextTest} is class test case that tests {@link FlatContext} as {@link Context} implementation.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
@SetSystemProperty(key = Context.INITIAL_CONTEXT_FACTORY, value = "com.example.shared.naming.FlatContextFactory")
class FlatContextTest {

    static final String TEST_VALUE = "value";
    static final String TEST_VALUE_KEY = "key";

    @Test
    void testAddToEnvironment() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testBindNameObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testBindStringObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testClone() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testClose() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testComposeNameNameName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testComposeNameStringString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testContext() throws Exception {
        final var ctx = new InitialContext();

        ctx.bind(TEST_VALUE_KEY, TEST_VALUE);

        assertEquals(TEST_VALUE, ctx.lookup(TEST_VALUE_KEY));
    }

    @Test
    void testCreateSubcontextName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testCreateSubcontextString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testDestroySubcontextName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testDestroySubcontextString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testEquals() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testFinalize() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testFlatContext() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetClass() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetEnvironment() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetNameInNamespace() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetNameParserName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetNameParserString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testHashCode() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testIsClosed() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testListBindingsName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testListBindingsString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testListName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testListString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testLookupLinkName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testLookupLinkString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testLookupName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testLookupString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testNotify() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testNotifyAll() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRebindNameObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRebindStringObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRemoveFromEnvironment() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRenameNameName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRenameStringString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testToString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testToString1() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testUnbindName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testUnbindString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testWait() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testWaitLong() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testWaitLongInt() {
        assertNotNull("Not yet implemented");
    }

}