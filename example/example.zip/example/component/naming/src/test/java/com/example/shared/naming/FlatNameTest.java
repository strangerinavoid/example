package com.example.shared.naming;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

/**
 * The {@code FlatNameTest} TODO complete comment
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
class FlatNameTest {

    @Test
    void testAddAllIntName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testAddAllName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testAddIntString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testAddString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testClone() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testCompareTo() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testEndsWith() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testEqualsObject() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testFlatName() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testFlatNameString() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGet() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetAll() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetPrefix() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testGetSuffix() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testHashCode() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testIsEmpty() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testRemove() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testSize() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testStartsWith() {
        assertNotNull("Not yet implemented");
    }

    @Test
    void testToString() {
        assertNotNull("Not yet implemented");
    }

}