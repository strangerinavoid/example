package com.example.shared.naming;

import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;

/**
 * The {@code FlatContextFactory} class is an implementation of the {@link InitialContextFactory} interface and
 * represents a factory, which provides a method for creating instances of initial context that implement the
 * {@link Context} interface.
 * <p>
 * The JNDI framework allows for different initial context implementations to be specified at runtime. The initial
 * context is created using an <em>initial context factory</em>.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class FlatContextFactory implements InitialContextFactory {

    /**
     * The map of initial contexts that was constructed by this factory.
     */
    private static final Map<Long, FlatContext> context = new ConcurrentHashMap<>();

    /**
     * Creates an instance of {@link FlatContext} for beginning name resolution. Special requirements of this context
     * are supplied using {@code environment}.
     * <p>
     * The environment parameter is owned by the caller. The implementation will not modify the object or keep a
     * reference to it, although it may keep a reference to a clone or copy.
     *
     * @param   environment the possibly {@code null} environment specifying information to be used in the creation of
     *          the initial context.
     * @return  a non-null initial context object that implements the {@link Context} interface.
     * @throws  NamingException if cannot create an initial context.
     */
    @Override
    public Context getInitialContext(final Hashtable<?, ?> environment) throws NamingException {
        return context.compute(0L, (k, v) -> null == v || v.isClosed() ? new FlatContext() : v);
    }

}