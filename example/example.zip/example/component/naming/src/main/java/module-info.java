import com.example.shared.core.type.TypeService;
import com.example.shared.naming.FlatNameType;

module example.shared.naming {

     exports com.example.shared.naming
          to java.naming, example.shared.core;

    requires example.shared.core;
    requires example.shared.logging;
    requires example.shared.type;
    requires example.shared.utils;

    requires transitive java.naming;

        uses TypeService;

    provides TypeService
        with FlatNameType;

}