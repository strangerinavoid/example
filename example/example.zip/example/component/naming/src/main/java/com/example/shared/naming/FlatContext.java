package com.example.shared.naming;

import static java.lang.String.valueOf;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElse;

import static com.example.shared.utils.Strings.EMPTY_STRING;
import static com.example.shared.utils.Strings.trim;

import java.io.Closeable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.naming.Binding;
import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameClassPair;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.NotContextException;
import javax.naming.OperationNotSupportedException;
import javax.naming.PartialResultException;
import javax.naming.SizeLimitExceededException;

/**
 * The {@code FlatContext} class is an implementation of the interface {@link Context} and provides flat namespace in
 * memory.
 * <p>
 * For details of how to use and manage initial context see javadoc for {@link Context} interface.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     FlatContextFactory
 */
final class FlatContext implements Context, Closeable {

    /**
     * The {@code FlatBindings} class is an internal implementation of the {@link FlatNamingEnumeration} class.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private final class FlatBindings extends FlatNamingEnumeration<Binding> {

        /**
         * Creates an instance of class {@code FlatBindings}.
         */
        public FlatBindings(final Iterator<String> names) {
            super(names);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Binding nextElement() {
            final var name = this.names.next();

            return new Binding(name, FlatContext.this.bindings.get(name));
        }

    }

    /**
     * The {@code FlatBindings} class is an internal implementation of the {@link FlatNamingEnumeration} class.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private final class FlatNames extends FlatNamingEnumeration<NameClassPair> {

        /**
         * Creates an instance of class {@code FlatNames}.
         */
        public FlatNames(final Iterator<String> names) {
            super(names);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public NameClassPair nextElement() {
            final var name = this.names.next();
            final var className = FlatContext.this.bindings.get(name).getClass().getName();

            return new NameClassPair(name, className);
        }

    }

    /**
     * The {@code FlatNamingEnumeration} class is an abstract implementation of the {@link NamingEnumeration} interface
     * and used to enumerating lists returned by methods in the {@code javax.naming} package. It extends
     * {@link Enumeration} interface to allow an exceptions to be thrown during the enumeration.
     * <p>
     * When a method such as {@code list()}, {@code listBindings()}, or {@code search()} returns a
     * {@link NamingEnumeration}, any exceptions encountered are reserved until all results have been returned. At the
     * end of the enumeration, the exception is thrown (by {@link #hasMore()}).
     * <p>
     * For example, if the {@code list()} is returning only a partial answer, the corresponding exception would be
     * {@link PartialResultException}. A {@code list()} would first return a {@link NamingEnumeration}. When the last
     * of the results has been returned by the {@link #next()}, invoking {@link #hasMore()} would result in
     * {@link PartialResultException} being thrown.
     * <p>
     * In another example, if a {@code search()} method was invoked with a specified size limit of 'n'. If the answer
     * consists of more than 'n' results, {@code search()} would first return a {@link NamingEnumeration}. When the
     * n'th result has been returned by invoking {@link #next()} on the {@link NamingEnumeration}, a
     * {@link SizeLimitExceededException} would then thrown when {@link #hasMore()} is invoked.
     * <p>
     * Note that if the program uses {@link #hasMoreElements()} and {@link #nextElement()} instead to iterate through
     * the {@link NamingEnumeration}, because these methods cannot throw exceptions, no exception will be thrown.
     * Instead, in the previous example, after the n'th result has been returned by {@link #nextElement()}, invoking
     * {@link #hasMoreElements()} would return {@code false}.
     * <p>
     * Note also that {@link NoSuchElementException} is thrown if the program invokes {@link #next()} or
     * {@link #nextElement()} when there are no elements left in the enumeration. The program can always avoid this
     * exception by using {@link #hasMore()} and {@link #hasMoreElements()} to check whether the end of the enumeration
     * has been reached.
     * <p>
     * If an exception is thrown during an enumeration, the enumeration becomes invalid. Subsequent invocation of any
     * method on that enumeration will yield undefined results.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private abstract class FlatNamingEnumeration<E> implements NamingEnumeration<E> {

        /**
         * The names for this enumeration.
         */
        protected Iterator<String> names;

        /**
         * Creates an instance of class {@code FlatNamingEnumeration}.
         */
        public FlatNamingEnumeration(final Iterator<String> names) {
            this.names = names;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void close() {
            this.names = null;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean hasMore() throws NamingException {
            return hasMoreElements();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean hasMoreElements() {
            return this.names.hasNext();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public E next() throws NamingException {
            return nextElement();
        }

    }

    /**
     * The flag of closed context. When method {@link #close()} invoked this flag is set to {@code true}.
     */
    private final AtomicBoolean closed;

    /**
     * The value bindings. Here stored all values that bounded to this context.
     */
    private final Map<String, Object> bindings;

    /**
     * Creates an instance of class {@code FlatContext}.
     */
    FlatContext() {
        this.closed = new AtomicBoolean();
        this.bindings = new ConcurrentHashMap<>();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object addToEnvironment(final String name, final Object value) throws NamingException {
        return null; // ignore this call
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bind(final Name name, final Object obj) throws NamingException {
        bind(valueOf(name), obj); // flat namespace; no federation; just call string version
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bind(final String name, final Object obj) throws NamingException {
        if (this.bindings.containsKey(requireNonNull(trim(name), "Unable to bind value with null or empty name"))) {
            throw new NameAlreadyBoundException("Use rebind to override value for binding with name \""
                + name
                + "\"");
        }
        this.bindings.put(name, obj);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() {
        if (this.closed.compareAndSet(false, true)) {
            this.bindings.clear();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name composeName(final Name name, final Name prefix) throws NamingException {
        return ((Name)prefix.clone()).addAll(name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String composeName(final String name, final String prefix) throws NamingException {
        return valueOf(composeName(new CompositeName(name), new CompositeName(prefix)));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Context createSubcontext(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        return createSubcontext(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Context createSubcontext(final String name) throws NamingException {
        throw new OperationNotSupportedException(getClass().getSimpleName()
            + " does not support subcontexts.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void destroySubcontext(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        destroySubcontext(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void destroySubcontext(final String name) throws NamingException {
        throw new OperationNotSupportedException(getClass().getSimpleName()
            + " does not support subcontexts.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Hashtable<?, ?> getEnvironment() throws NamingException {
        return new Hashtable<>();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getNameInNamespace() throws NamingException {
        return EMPTY_STRING;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NameParser getNameParser(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        return getNameParser(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NameParser getNameParser(final String name) throws NamingException {
        return FlatName::new;
    }

    /**
     *
     *
     * @return
     */
    public boolean isClosed() {
        return this.closed.get();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NamingEnumeration<NameClassPair> list(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        return list(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NamingEnumeration<NameClassPair> list(final String name) throws NamingException {
        if (requireNonNullElse(name, EMPTY_STRING).isBlank()) {
            return new FlatNames(this.bindings.keySet().iterator()); // listing this context
        }
        final var target = lookup(name); // perhaps 'name' names a context

        if (target instanceof final Context ctx) {
            return ctx.list(EMPTY_STRING);
        }
        throw new NotContextException(name + " cannot be listed");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NamingEnumeration<Binding> listBindings(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        return listBindings(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NamingEnumeration<Binding> listBindings(final String name) throws NamingException {
        if (EMPTY_STRING.equals(name)) {
            return new FlatBindings(this.bindings.keySet().iterator()); // listing this context
        }
        final var target = lookup(name); // perhaps 'name' names a context

        if (target instanceof final Context ctx) {
            return ctx.listBindings(EMPTY_STRING);
        }
        throw new NotContextException(name + " cannot be listed");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object lookup(final Name name) throws NamingException {
        // flat namespace; no federation; just call string version
        return lookup(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object lookup(final String name) throws NamingException {
        if (requireNonNull(name, "Unable to lookup value for null name").isBlank()) {
            return this; // give a reference to itself
        }
        // else we looking for bindings
        final var binding = this.bindings.get(name);

        if (null == binding) {
            throw new NameNotFoundException(name + " not found");
        }
        return binding;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object lookupLink(final Name name) throws NamingException {
        return lookupLink(valueOf(name)); // flat namespace; no federation; just call string version
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object lookupLink(final String name) throws NamingException {
        return lookup(name); // this flat context does not treat links specially
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void rebind(final Name name, final Object obj) throws NamingException {
        rebind(valueOf(name), obj); // flat namespace; no federation; just call string version
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void rebind(final String name, final Object obj) throws NamingException {
        this.bindings.put(requireNonNull(trim(name), "Unable to rebind value with null or empty name"), obj);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object removeFromEnvironment(final String propName) throws NamingException {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void rename(final Name oldName, final Name newName) throws NamingException {
        rename(valueOf(oldName), valueOf(newName)); // flat namespace; no federation; just call string version
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void rename(final String oldName, final String newName) throws NamingException {
        if (trim(oldName) == null || trim(newName) == null) {
            throw new InvalidNameException("Unable to rename null or empty name");
        }
        // check if new name exists
        if (this.bindings.containsKey(newName)) {
            throw new NameAlreadyBoundException(newName + " is already bound");
        }
        // check if old name is bound
        final var oldBinding = this.bindings.remove(oldName);

        if (oldBinding == null) {
            throw new NameNotFoundException(oldName + " not bound");
        }
        this.bindings.put(newName, oldBinding);
    }

    /**
     * Returns human-readable string representation of this context.
     */
    @Override
    public String toString() {
        return valueOf(this.bindings);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unbind(final Name name) throws NamingException {
        unbind(valueOf(name)); // flat namespace; no federation; just call string version
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unbind(final String name) throws NamingException {
        if (!this.bindings.containsKey(requireNonNull(trim(name), "Unable to unbind null or empty name"))) {
            throw new NameNotFoundException(name + " not bound");
        }
        this.bindings.remove(name);
    }

}