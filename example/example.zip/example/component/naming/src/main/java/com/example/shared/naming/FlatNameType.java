package com.example.shared.naming;

import static java.lang.String.valueOf;

import com.example.shared.core.type.Type;
import com.example.shared.type.AbstractType;

/**
 * The class {@code FlatNameType} is an implementation of the interface {@link Type}. The purpose of this class is to
 * convert specified objects to the {@link FlatName} type.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 *
 * @see     FlatName
 * @see     Type
 */
public final class FlatNameType extends AbstractType<FlatName> {

    /**
     * Creates an instance of class {@code FlatNameType}.
     */
    public FlatNameType() {
        super(FlatName.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected FlatName transform(final Object o) {
        if (!(o instanceof String)) {
            log().warning("TYPE: Specified value [%s] is not a string and may be used as incorrect name.", o);
        }
        return new FlatName(valueOf(o));
    }

}