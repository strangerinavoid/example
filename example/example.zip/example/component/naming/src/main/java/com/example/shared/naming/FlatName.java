package com.example.shared.naming;

import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Objects.compare;
import static java.util.Objects.hash;
import static java.util.Objects.requireNonNull;
import static java.util.Objects.requireNonNullElse;

import static com.example.shared.utils.Strings.EMPTY_STRING;
import static com.example.shared.utils.Strings.trim;

import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.naming.InvalidNameException;
import javax.naming.Name;

/**
 * The {@code FlatName} class is an implementation of the interface {@link Name} which represents a generic name - an
 * ordered sequence of components.
 * <p>
 * The components of a name are numbered. The indexes of a name with N components range from 0 up to, but not including,
 * N. This range may be written as [0,N). The most significant component is at index 0. An empty name has no components.
 * <p>
 * None of the methods in {@code FlatName} accept {@code null} as a valid value for a parameter that is a name or a name
 * component. Likewise, methods that return a name or name component never return {@code null}.
 * <p>
 * A {@code FlatName} instance is not synchronized against concurrent multithreaded access. Multiple threads trying to
 * access and modify a {@code FlatName} should lock the object.
 *
 * @author  Andrey OCHIROV
 * @version 1.0
 */
public final class FlatName implements Name {

    /**
     * The {@code FlatNameEnumerator} class is an internal implementation of the interface {@link Enumeration} that used
     * as enumerator for the {@link Name} components.
     *
     * @author  Andrey OCHIROV
     * @version 1.0
     */
    private final class FlatNameEnumerator implements Enumeration<String> {

        /**
         * The name for enumeration.
         */
        private final String name;

        /**
         * The current position in the enumeration.
         */
        private final AtomicBoolean pos;

        /**
         * Creates an instance of class {@code FlatNameEnumerator}.
         */
        public FlatNameEnumerator(final String name) {
            this.pos = new AtomicBoolean(null == name);
            this.name = name;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean hasMoreElements() {
            return this.pos.compareAndSet(false, false);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String nextElement() {
            if (this.pos.compareAndSet(false, true)) {
                return this.name;
            }
            throw new NoSuchElementException("No more elements in the enumeration.");
        }

    }

    /**
     * An error message for all index out of bounds cases.
     */
    private static final String INDEX_OUT_OF_BOUNDS_MESSAGE =
        "A flat name can only have a single component and component position %d is not admissible.";

    /**
     * An error message for all unsupported operations.
     */
    private static final String UNSUPPORTED_OPERATION_MESSAGE =
        "This instance does not support modification operations because it is an immutable object.";

    /**
     * The class finger print that is set to indicate serialization compatibility with a previous version of the class.
     */
    private static final long serialVersionUID = -433000500839908667L;

    /**
     * The original name that was specified to the constructor.
     */
    private final String name;

    /**
     * Creates an instance of class {@code FlatName}.
     *
     * @see     #FlatName(String)
     */
    public FlatName() {
        this.name = null;
    }

    /**
     * Creates an instance of class {@code FlatName} with specified string as name component. If specified name value if
     * empty or {@code null} this constructor works as {@link #FlatName()}.
     *
     * @see     #FlatName()
     */
    public FlatName(final String name) {
        this.name = requireNonNull(trim(name), "Only not null name can be specified as argument");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name add(final int posn, final String comp) throws InvalidNameException {
        throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_MESSAGE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name add(final String comp) throws InvalidNameException {
        throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_MESSAGE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name addAll(final int posn, final Name comp) throws InvalidNameException {
        throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_MESSAGE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name addAll(final Name comp) throws InvalidNameException {
        throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_MESSAGE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object clone() {
        return new FlatName(this.name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(final Object o) {
        return compare(this.name, valueOf(o), (o1, o2) -> null == o1 ? -1 : o1.compareTo(o2));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean endsWith(final Name name) {
       return !(this.name == null || name == null || name.size() != 1) && this.name.endsWith(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object o) {
        // here we can use `instanceof` because this class is a final class, otherwise we should compare classes
        return this == o || o instanceof final FlatName n && Objects.equals(this.name, n.name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String get(final int posn) {
        if (posn == 0) {
            return this.name;
        }
        throw new ArrayIndexOutOfBoundsException(format(INDEX_OUT_OF_BOUNDS_MESSAGE, posn));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Enumeration<String> getAll() {
        return new FlatNameEnumerator(this.name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name getPrefix(final int posn) {
        if (posn == 0) {
            return new FlatName(this.name);
        }
        throw new ArrayIndexOutOfBoundsException(format(INDEX_OUT_OF_BOUNDS_MESSAGE, posn));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Name getSuffix(final int posn) {
        return getPrefix(posn); // for a single component #getPrefix and #getSuffix are identical
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return hash(this.name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return null == this.name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object remove(final int posn) throws InvalidNameException {
        throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_MESSAGE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return null == this.name ? 0 : 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean startsWith(final Name name) {
        return !(this.name == null || name == null || name.size() != 1) && this.name.startsWith(valueOf(name));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return requireNonNullElse(this.name, EMPTY_STRING);
    }

}